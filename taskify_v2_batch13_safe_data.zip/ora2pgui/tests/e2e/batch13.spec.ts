import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// Batch 13, what users see. Against the real API; test data: dev-tools/testdb/07_batch13.sql.

test('Migrate: object tables are listed, Oracle\'s hidden nested-table storage table is not', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/migrate`);
  await page.getByPlaceholder('Search').fill('B13_');
  test.skip((await page.getByRole('checkbox', { name: 'Select B13_CONF_OBJ', exact: true }).count()) === 0, 'no batch 13 test tables in this schema');
  await expect(page.getByRole('row').filter({ hasText: 'B13_CONF_OBJ' }).getByText('Object table')).toBeVisible();
  await expect(page.getByRole('checkbox', { name: 'Select B13_NESTED', exact: true })).toBeVisible();
  await expect(page.getByRole('checkbox', { name: 'Select B13_NESTED_TAGS', exact: true })).toHaveCount(0);
  await pageIsFine(page);
  expect(errors).toEqual([]);
});

test('Settings: the PostgreSQL version is no longer a choice (it is read from the target)', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/settings`);
  await page.getByRole('tab', { name: /Advanced/ }).click();
  await expect(page.getByText('Client encoding').first()).toBeVisible(); // the other ora2pg options are still there
  await expect(page.getByText('Target PostgreSQL version')).toHaveCount(0);
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
