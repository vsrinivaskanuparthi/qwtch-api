'use strict';

/**
 * End-to-end, batch 13: one real migration of the test data in dev-tools/testdb/07_batch13.sql
 * (plus the object tables of 06_object_tables.sql) into a scratch target schema
 * (DMA_E2E_B13_SCHEMA, default e2e_b13), then checks in PostgreSQL and on the Validation page:
 *   DMA-081 object tables: real column types, composite primary key, unique / check / NOT NULL,
 *           index, foreign keys from and to the object table; Validation shows no gap
 *   DMA-082 nested table column: every list arrives (equal lists, empty list, NULL list, quotes);
 *           Oracle's storage table is not listed; its internal unique index is left out
 *   DMA-083 identity columns continue after the migrated values
 *   DMA-084 text with the NUL character loads; the removal is reported
 *   DMA-091 the source Oracle is not changed (an invalid procedure is not recompiled); the run
 *           config has COMPILE_SCHEMA 0 and DISABLE_UNLOGGED 1
 *   PG_VERSION is the target's own version
 * The project's settings are put back at the end. Needs DMA_E2E_PG_URL and DMA_E2E_STAGING.
 */
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');
const { P, call, apiUp, getSettings, saveSettings, migrate, types, one, loaded } = require('./helpers');

const TARGET = process.env.DMA_E2E_B13_SCHEMA || 'e2e_b13';
const STAGING = process.env.DMA_E2E_STAGING;
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
const maybe = process.env.DMA_E2E_PG_URL ? describe : describe.skip;
jest.setTimeout(20 * 60 * 1000);

const TABLES = ['B13_USER', 'B13_CONF_OBJ', 'B13_MONITOR_OBJ', 'B13_AUDIT', 'B13_NESTED', 'B13_IDENT', 'B13_IDENT_DEF', 'B13_NUL', 'CONTACT_OBJ', 'SITE_OBJ'];

let SCHEMA = ''; // the project's Oracle schema, read in beforeAll
/** Last change time of the invalid test procedure in the source Oracle. */
const ddlTimeSql = () => `SELECT TO_CHAR(last_ddl_time, 'YYYY-MM-DD HH24:MI:SS') FROM dba_objects WHERE owner = '${SCHEMA}' AND object_name = 'B13_INVALID_PROC'`;

/** One value from the source Oracle through the SQL Workbench (read-only). */
async function oracleValue(sql) {
  const r = await call('POST', `${P}/sql`, { target: 'oracle', sql });
  if (r.status !== 200 || !r.data.results[0].rows) throw new Error(`Oracle query failed: ${JSON.stringify(r.data).slice(0, 300)}`);
  return r.data.results[0].rows[0][0];
}

maybe('Batch 13: object tables, nested tables, identity, NUL characters, source Oracle untouched', () => {
  let pg;
  let saved;
  let run;
  let ddlBefore;
  const q = async (sql, params) => (await pg.query(sql, params)).rows;

  beforeAll(async () => {
    await apiUp();
    SCHEMA = (await call('GET', P)).data.project.selectedSchema;
    saved = await getSettings();
    pg = new Client({ connectionString: process.env.DMA_E2E_PG_URL });
    await pg.connect();
    // Snapshot taken with this version (nested storage tables left out, object tables listed).
    const snap = await call('POST', `${P}/snapshot`, {});
    expect([200, 202]).toContain(snap.status);
    for (let i = 0; i < 120; i += 1) {
      await new Promise((r) => setTimeout(r, 2000));
      const s = await call('GET', `${P}/snapshot`);
      if (s.status === 200 && (s.data.tableMetadata || []).some((t) => t.name === 'B13_CONF_OBJ') && !(await call('GET', `${P}/snapshot`)).data.running) break;
    }
    ddlBefore = await oracleValue(ddlTimeSql());
    await saveSettings({ ...saved, targetSchema: TARGET, engine: { ...saved.engine, snapshot: 'off' } });
    run = await migrate(pg, TARGET, TABLES);
  });

  afterAll(async () => {
    if (saved) await saveSettings(saved);
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`).catch(() => {});
      await pg.end();
    }
  });

  test('the run completes and every table is loaded and verified', () => {
    expect(run.status).toBe('COMPLETED');
    for (const t of TABLES) loaded(run, t);
  });

  test('DMA-091: the source Oracle is not changed by the run', async () => {
    const after = await oracleValue(ddlTimeSql());
    expect(after).toBe(ddlBefore);
    expect(await oracleValue(`SELECT status FROM dba_objects WHERE owner = '${SCHEMA}' AND object_name = 'B13_INVALID_PROC'`)).toBe('INVALID');
    if (STAGING) {
      const conf = fs.readFileSync(path.join(STAGING, PROJECT, 'runs', run.runId, 'config', 'ddl.conf'), 'utf8');
      expect(conf).toMatch(/^COMPILE_SCHEMA\s+0\s*$/m);
      expect(conf).toMatch(/^DISABLE_UNLOGGED\s+1\s*$/m);
    }
  });

  test('PG_VERSION is the target\'s own version', async () => {
    const major = Math.floor(Number(await one(pg, "SELECT current_setting('server_version_num')")) / 10000);
    expect(run.pgMajor).toBe(major);
    expect(run.events.map((e) => e.message).join('\n')).toContain(`Target PostgreSQL ${major}`);
    if (STAGING) {
      const conf = fs.readFileSync(path.join(STAGING, PROJECT, 'runs', run.runId, 'config', 'data.conf'), 'utf8');
      expect(conf).toMatch(new RegExp(`^PG_VERSION\\s+${major}\\s*$`, 'm'));
    }
  });

  test('DMA-081: object tables get the column types of their type', async () => {
    expect(await types(pg, TARGET, 'b13_conf_obj')).toEqual({
      user_id: 'bigint', group_name: expect.stringMatching(/^character varying/), property_name: 'character varying(60)',
      prop_value: 'character varying(200)', updated: 'timestamp(0) without time zone', weight: 'numeric(6,2)',
    });
    expect(await types(pg, TARGET, 'b13_monitor_obj')).toMatchObject({ id: 'bigint', name: 'character varying(40)', status: 'character varying(10)' });
    // Not tied to the type any more: an ordinary table.
    expect(Number(await one(pg, `SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = 'b13_conf_obj' AND c.reloftype <> 0`, [TARGET]))).toBe(0);
    // Without its own key in Oracle, SITE_OBJ simply has its four columns.
    expect(Object.keys(await types(pg, TARGET, 'site_obj'))).toEqual(['street', 'city', 'zip', 'country']);
  });

  test('DMA-081: keys, constraints, index and foreign keys of object tables (like CONFIGURATION_FULL / MONITORING_FULL)', async () => {
    const cons = await q(`SELECT conrelid::regclass::text AS t, contype, pg_get_constraintdef(oid) AS def, convalidated FROM pg_constraint
                           WHERE connamespace = $1::regnamespace AND conrelid::regclass::text ~ '(b13_conf_obj|b13_monitor_obj|b13_audit|contact_obj)$'`, [TARGET]);
    const has = (t, re) => cons.some((c) => c.t.endsWith(t) && re.test(c.def));
    expect(has('b13_conf_obj', /^PRIMARY KEY \(user_id, group_name, property_name\)$/)).toBe(true);
    expect(has('b13_conf_obj', /^CHECK .*UI.*MAIL.*SECURITY/)).toBe(true);
    expect(has('b13_conf_obj', /^FOREIGN KEY \(user_id\) REFERENCES .*b13_user\(user_id\)$/)).toBe(true);
    expect(has('b13_audit', /^FOREIGN KEY \(user_id, group_name, property_name\) REFERENCES .*b13_conf_obj/)).toBe(true);
    expect(has('b13_monitor_obj', /^PRIMARY KEY \(id\)$/)).toBe(true);
    expect(has('b13_monitor_obj', /^UNIQUE \(name\)$/)).toBe(true);
    expect(has('contact_obj', /^PRIMARY KEY \(contact_id\)$/)).toBe(true);
    expect(cons.filter((c) => c.contype === 'f').every((c) => c.convalidated)).toBe(true);
    expect(await one(pg, `SELECT is_nullable FROM information_schema.columns WHERE table_schema = $1 AND table_name = 'b13_conf_obj' AND column_name = 'prop_value'`, [TARGET])).toBe('NO');
    expect(Number(await one(pg, `SELECT count(*) FROM pg_indexes WHERE schemaname = $1 AND indexname = 'b13_conf_upd_ix'`, [TARGET]))).toBe(1);
    // Nothing of Oracle's internal object identifier.
    expect(Number(await one(pg, `SELECT count(*) FROM information_schema.columns WHERE table_schema = $1 AND column_name ILIKE 'sys_nc%'`, [TARGET]))).toBe(0);
  });

  test('DMA-081: values of object tables are exact (nested object and list inside)', async () => {
    const r = (await q(`SELECT full_name, credit::text, (address).street AS street, (address).country AS country, phones::text AS phones FROM "${TARGET}".contact_obj WHERE contact_id = 9001`))[0];
    expect(r).toEqual({ full_name: 'O\'Brien, "Jr"', credit: '-0.01', street: 'Line 1\nLine 2', country: 'IE', phones: '({})' });
    expect(await one(pg, `SELECT phones::text FROM "${TARGET}".contact_obj WHERE contact_id = 1`)).toBe('("{""+33 1 000001"",""+33 6 000001""}")');
  });

  test('DMA-082: nested table lists arrive exactly; Oracle\'s storage table is not a table of its own', async () => {
    const rows = await q(`SELECT id, label, tags::text AS tags FROM "${TARGET}".b13_nested ORDER BY id`);
    expect(rows.map((x) => x.tags)).toEqual(['("{red,green}")', '("{red,green}")', '({})', null, '("{""a,b"",""say \\\\""hi\\\\"""",NULL}")']);
    expect(run.tables.B13_NESTED.dataCheck.ok).toBe(true);
    expect(run.events.map((e) => e.message).join('\n')).toMatch(/Oracle-internal indexes of nested table columns left out/);
    const { data } = await call('GET', `${P}/snapshot`);
    expect(data.tableMetadata.map((t) => t.name)).not.toContain('B13_NESTED_TAGS');
  });

  test('DMA-083: identity columns continue after the migrated values', async () => {
    const next = async (t) => Number(await one(pg, `SELECT nextval(pg_get_serial_sequence('"${TARGET}".${t}', 'id'))`));
    expect(await next('b13_ident')).toBeGreaterThan(7);
    expect(await next('b13_ident_def')).toBe(101); // after the explicit 100
    expect(run.events.map((e) => e.message).join('\n')).toMatch(/Identity columns: 2 set to continue after the migrated values/);
  });

  test('DMA-084: text with the NUL character loads, without it, and the run says so', async () => {
    expect((await q(`SELECT txt, ntxt FROM "${TARGET}".b13_nul ORDER BY id`))).toEqual([
      { txt: 'abcdef', ntxt: 'nx' }, { txt: 'ends with nul', ntxt: null }, { txt: 'plain', ntxt: 'plain' }]);
    expect(run.tables.B13_NUL.dataCheck).toMatchObject({ ok: true, nulRemoved: [{ column: 'TXT', rows: 2 }, { column: 'NTXT', rows: 1 }] });
    expect(run.events.map((e) => e.message).join('\n')).toMatch(/B13_NUL: 3 values contained the NUL character/);
  });

  test('Validation: no gap for these tables (row counts, keys, unique, indexes, structure)', async () => {
    const v = (await call('GET', `${P}/validation`)).data;
    const mine = (rows, i = 1) => (rows || []).filter((r) => /^(b13_|contact_obj|site_obj)/i.test(r[i]));
    expect(mine(v.rowCountCheck).every((r) => r[4] === 'yes')).toBe(true);
    expect(mine(v.primaryForeignKeys, 0).length).toBeGreaterThan(10);
    expect(mine(v.primaryForeignKeys, 0).every((r) => r[2] === 'YES')).toBe(true);
    expect(mine(v.uniqueConstraintsCheck).every((r) => r[2] === 'YES')).toBe(true);
    expect((v.uniqueConstraintsCheck || []).some((r) => /^SYS_NC/.test(r[0]))).toBe(false);
    expect(mine(v.indexesCheck).every((r) => r[2] === 'YES')).toBe(true);
    const structure = mine(v.structureCheck, 0);
    expect(structure.length).toBeGreaterThan(20);
    expect(structure.filter((r) => r[5] !== 'yes')).toEqual([]);
  });
});
