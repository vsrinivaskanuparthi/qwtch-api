'use strict';

/**
 * Oracle object tables (CREATE TABLE x OF type_t) must be in the snapshot's table list, so they can be
 * selected and migrated. Oracle's dba_tables leaves them out; dba_all_tables lists them.
 * The real migration of object tables is tested in tests/e2e/objectTables.e2e.test.js.
 */
jest.mock('../../utils/logger', () => ({ info: jest.fn(), warn: jest.fn(), error: jest.fn(), debug: jest.fn() }));

const { getTableMetadata } = require('../../queries/oracle/getTableMetadata');

/** A fake Oracle connection: the table query returns these rows, the foreign key query none. */
function fakeConnection(rows) {
  const queries = [];
  return {
    queries,
    execute: jest.fn(async (sql) => {
      queries.push(sql);
      const data = /estimated_row_count/.test(sql) ? rows : [];
      return { resultSet: { async *[Symbol.asyncIterator]() { yield* data; }, close: jest.fn() } };
    }),
  };
}

describe('Snapshot table list and object tables', () => {
  test('the table list is read from dba_all_tables (object tables included), not dba_tables', async () => {
    const conn = fakeConnection([]);
    await getTableMetadata(conn, 'OBJ_TEST_1');
    const sql = conn.queries.find((q) => /estimated_row_count/.test(q));
    expect(sql).toMatch(/FROM dba_all_tables t\b/);
    expect(sql).not.toMatch(/FROM dba_tables t\b/);
    // The same tables as before stay out: recycle bin, secondary, temporary, MV logs and MV storage tables.
    expect(sql).toMatch(/t\.dropped = 'NO'/);
    expect(sql).toMatch(/t\.secondary = 'N'/);
    expect(sql).toMatch(/t\.temporary = 'N'/);
    expect(sql).toMatch(/MLOG\$/);
    expect(sql).toMatch(/dba_mviews/);
    // Storage tables of nested table columns are Oracle-internal (DMA-082): not listed.
    expect(sql).toMatch(/t\.nested = 'NO'/);
  });

  test('an object table returned by Oracle is in the list like any table', async () => {
    const conn = fakeConnection([
      ['CONTACT_OBJ', 302, 0.13, 0, '2026-11-24', 'NO'],
      ['PLANT', 50, 0.06, 0, '2026-11-24', 'NO'],
    ]);
    const tables = await getTableMetadata(conn, 'OBJ_TEST_2');
    expect(tables.map((t) => t.name)).toEqual(['CONTACT_OBJ', 'PLANT']);
    expect(tables[0]).toMatchObject({ name: 'CONTACT_OBJ', rowCount: 302, partitioned: false });
  });
});
