'use strict';

/**
 * Batch 13 (DMA-081 to DMA-084, DMA-091, PostgreSQL version): the parts that need no database.
 *   - pgLiteral: Oracle values written as PostgreSQL text input for the column type (objects,
 *     nested tables and VARRAYs, ora2pg's one-field list type, the NUL character)
 *   - the run config never lets ora2pg change the source Oracle or leave tables UNLOGGED, and
 *     carries the PostgreSQL version read from the target
 *   - Validation leaves out Oracle-internal columns (SYS_NC_OID$) and counts identity columns as
 *     having a default
 * The real migrations are in tests/e2e/batch13.e2e.test.js.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-b13-'));
process.env.MIGRATION_STAGING_DIR = staging;
jest.mock('../../utils/logger', () => ({ info: jest.fn(), warn: jest.fn(), error: jest.fn(), debug: jest.fn() }));

const { pgLiteral } = require('../../services/migrate');
const settings = require('../../services/settings');
const { buildConfig } = require('../../services/config_modify');
const cacheService = require('../../utils/cache');
const { compareUniqueConstraints } = require('../../queries/pg/compareUniqueConstraints');
const { comparePrimaryForeignKeys } = require('../../queries/pg/comparePrimaryForeignKeys');

afterAll(() => fs.rmSync(staging, { recursive: true, force: true }));

// node-oracledb values: an object (DbObject) and a collection (a "bound DbObject" subclass).
const obj = (attrs) => Object.assign(Object.create({ isCollection: false }), { attributes: Object.fromEntries(Object.keys(attrs).map((k) => [k, {}])) }, attrs);
const coll = (values) => ({ isCollection: true, getValues: () => values });

const scalar = { kind: 'scalar' };
const textArray = { kind: 'array', elem: scalar };
const wrapper = { kind: 'composite', wrapper: true, attrs: [{ name: 'tags_t', type: textArray }] }; // CREATE TYPE tags_t AS (tags_t varchar(20)[])
const address = { kind: 'composite', wrapper: false, attrs: ['street', 'city', 'zip', 'country'].map((name) => ({ name, type: scalar })) };

describe('pgLiteral: Oracle values as PostgreSQL input', () => {
  test('NULL, text, numbers and dates', () => {
    expect(pgLiteral(null)).toBeNull();
    expect(pgLiteral(undefined)).toBeNull();
    expect(pgLiteral('plain')).toBe('plain');
    expect(pgLiteral(12.5)).toBe('12.5');
    expect(pgLiteral(new Date(2024, 1, 29, 23, 59, 58, 7))).toBe('2024-02-29 23:59:58.007');
    expect(pgLiteral(Buffer.from([0xca, 0xfe]))).toBe('\\xcafe');
  });

  test('the NUL character is removed (PostgreSQL cannot store it in text)', () => {
    expect(pgLiteral('abc\u0000def')).toBe('abcdef');
    expect(pgLiteral('ends\u0000')).toBe('ends');
  });

  test('a nested table into ora2pg\'s one-field list type: ("{…}")', () => {
    expect(pgLiteral(coll(['red', 'green']), wrapper)).toBe('("{\\"red\\",\\"green\\"}")');
    expect(pgLiteral(coll([]), wrapper)).toBe('("{}")');
  });

  test('list values with commas, quotes, backslashes and NULL elements stay exact', () => {
    expect(pgLiteral(coll(['a,b', 'say "hi"', 'x\\y', null]), textArray)).toBe('{"a,b","say \\"hi\\"","x\\\\y",NULL}');
  });

  test('a collection into a plain array column, and a JavaScript array (never JSON)', () => {
    expect(pgLiteral(coll(['+33 1', '+33 6']), textArray)).toBe('{"+33 1","+33 6"}');
    expect(pgLiteral(['a', 'b'], textArray)).toBe('{"a","b"}');
  });

  test('an object becomes a composite value, attributes in order, NULL attributes empty', () => {
    expect(pgLiteral(obj({ STREET: 'Line 1\nLine 2', CITY: null, ZIP: '00001', COUNTRY: 'IE' }), address)).toBe('("Line 1\nLine 2",,"00001","IE")');
  });

  test('an object holding a list (contact_t with phones_t): the list is wrapped for its type', () => {
    const contact = { kind: 'composite', wrapper: false, attrs: [{ name: 'name', type: scalar }, { name: 'phones', type: wrapper }] };
    expect(pgLiteral(obj({ NAME: 'Ann', PHONES: coll(['1', '2']) }), contact)).toBe('("Ann","(\\"{\\\\\\"1\\\\\\",\\\\\\"2\\\\\\"}\\")")');
  });
});

describe('Run config (DMA-091 and the PostgreSQL version)', () => {
  const directive = (conf, key) => ((new RegExp(`^${key}[ \\t]+(.*)$`, 'm').exec(conf) || [])[1] || '').trim();
  const oracle = { userUrl: 'oracle-host:1521/ORCLPDB', userUsername: 'migrator', userPassword: 'x' };
  async function conf(extraDirectives = '', options = {}) {
    const { settings: s, error } = settings.validate({ extraDirectives }, settings.defaults());
    if (error) throw new Error(error);
    const outFile = path.join(staging, `c${Date.now()}${Math.random()}.conf`);
    await buildConfig({ outFile, outputDir: staging, oracle, schema: 'APP', options: { ...options, directives: settings.ora2pgDirectives(s) } });
    return fs.readFileSync(outFile, 'utf8');
  }

  test('ora2pg never recompiles code in the source Oracle, and never leaves a table UNLOGGED', async () => {
    const c = await conf();
    expect(directive(c, 'COMPILE_SCHEMA')).toBe('0');
    expect(directive(c, 'DISABLE_UNLOGGED')).toBe('1');
  });

  test('an extra directive in Settings cannot switch them back', async () => {
    const c = await conf('COMPILE_SCHEMA 1\nDISABLE_UNLOGGED 0');
    expect(directive(c, 'COMPILE_SCHEMA')).toBe('0');
    expect(directive(c, 'DISABLE_UNLOGGED')).toBe('1');
  });

  test('PG_VERSION is the version read from the target, not a Settings choice', async () => {
    expect(directive(await conf('', { pgMajor: 14 }), 'PG_VERSION')).toBe('14');
    expect(settings.ORA2PG_OPTIONS.find((o) => o.key === 'PG_VERSION').type).toBe('fixed');
    expect(settings.ora2pgDirectives(settings.defaults()).PG_VERSION).toBeUndefined();
  });
});

describe('Validation leaves out Oracle-internal columns', () => {
  const pgConn = (rows) => ({ pgSchema: 'app', query: jest.fn(async () => ({ rows })) });

  test('the unique constraint on SYS_NC_OID$ of an object table is not reported missing', async () => {
    cacheService.set('fetchUniqueConstraints:B13A', [
      { table_name: 'CONFIGURATION_FULL', column_name: 'SYS_NC_OID$' },
      { table_name: 'MONITOR', column_name: 'NAME' },
    ]);
    const rows = await compareUniqueConstraints(pgConn([{ table_name: 'monitor', column_name: 'name' }]), 'B13A');
    expect(rows).toEqual([['NAME', 'MONITOR', 'YES']]);
  });

  test('primary key columns: hidden SYS_NC… columns are left out, real ones compared', async () => {
    cacheService.set('getPrimaryForeignKeys:B13B', [
      { tableName: 'CONFIGURATION_FULL', columnName: 'USER_ID' },
      { tableName: 'CONFIGURATION_FULL', columnName: 'SYS_NC_OID$' },
      { tableName: 'NESTED', columnName: 'SYS_NC0000300004$' },
    ]);
    const rows = await comparePrimaryForeignKeys(pgConn([{ table_name: 'configuration_full', column_name: 'user_id' }]), 'B13B');
    expect(rows).toEqual([['CONFIGURATION_FULL', 'USER_ID', 'YES']]);
  });

  test('the structure check counts an identity column as having its default', () => {
    const sql = fs.readFileSync(path.join(__dirname, '../../queries/pg/compareStructure.js'), 'utf8');
    expect(sql).toMatch(/column_default IS NOT NULL OR is_identity = 'YES'/);
  });
});
