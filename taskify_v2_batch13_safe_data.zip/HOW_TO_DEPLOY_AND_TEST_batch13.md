# DMA v2: batch 13, safe and correct data

**No `.env` change. No new npm package. `server.js` is not changed. No new screen and no new choice for users.**

Deploy batch 11 and batch 12 first: this batch builds on them.

## What's fixed

| # | Item | Before | After |
|---|---|---|---|
| 1 | **The source Oracle is never changed** (DMA-091) | Every run made ora2pg recompile invalid code **inside the source Oracle** (`COMPILE_SCHEMA 1`, also in v1). Oracle NOLOGGING tables could stay UNLOGGED in PostgreSQL (emptied after a crash) | DMA only reads Oracle. Every migrated table is a normal table |
| 2 | **Object tables complete** (DMA-081) | No primary key, unique / check / NOT NULL, indexes or foreign keys; every column TEXT. Validation showed `SYS_NC_OID$` in red | Created like in Oracle, with real column types. `SYS_NC_OID$` (Oracle-internal) is no longer reported |
| 3 | **Nested table columns** (DMA-082) | The lists arrived **empty** and the table showed as OK. Oracle's hidden storage table was listed on Migrate | Lists arrive exactly. The hidden table is not listed. The data check now also counts object and list values |
| 4 | **Identity columns** (DMA-083) | The counter stayed at 1: the application's first new row failed with "duplicate key" | The counter continues after the highest migrated value (or Oracle's own next value, if higher) |
| 5 | **Text with the NUL character** (DMA-084) | The whole table failed 3 times with wrong advice ("change the type mapping") | The table loads. PostgreSQL cannot store chr(0), so it is removed; the Live monitor says which columns and how many rows |
| 6 | **PostgreSQL version** | A choice in Settings (default 16) | Read from the target at the start of every run. Removed from Settings |

**What users notice:** nothing new to learn. The Live monitor shows a few new lines, for example:
- "Target PostgreSQL 16: ora2pg writes the SQL for this version"
- "Created object table CONFIGURATION_FULL with the columns of its type …"
- "Object tables: keys and constraints: 6 created"
- "Identity columns: 2 set to continue after the migrated values"
- "ORDERS: 3 values contained the NUL character (chr(0)) … it was removed"

**Note on invalid code:** ora2pg no longer recompiles invalid PL/SQL in Oracle. Objects that are INVALID in Oracle stay so (they are listed on Assessment). If you want them in the GenAI package, ask the DBA to recompile the schema in Oracle first (`EXEC DBMS_UTILITY.compile_schema('<SCHEMA>', FALSE);`), or switch on "Export invalid code objects" in Settings.

**Projects migrated with batch 12:** object tables created then as TEXT copies are rebuilt with the real types by the next run of those tables (their data is reloaded anyway).

## Files

| | Files |
|---|---|
| `ora2pgservice/` changed | `services/migrate.js`, `services/config_modify.js`, `services/settings.js`, `services/code.js`, `services/analysis.js`, `utils/postgreClient.js`, `scripts/ora2pg.conf`, `queries/oracle/getTableMetadata.js`, `queries/oracle/fetchUniqueConstraints.js`, `queries/oracle/getPrimaryForeignKeys.js`, `queries/oracle/getNormalIndexes.js`, `queries/pg/compareStructure.js`, `queries/pg/compareUniqueConstraints.js`, `queries/pg/comparePrimaryForeignKeys.js` |
| `ora2pgservice/` tests | new `tests/unit/batch13.test.js`, `tests/e2e/batch13.e2e.test.js`; changed `tests/unit/settingsConfig.test.js`, `tests/unit/objectTables.test.js`, `tests/e2e/objectTables.e2e.test.js` (batch 12 test, now expects real column types) |
| `ora2pgui/` tests | new `tests/e2e/batch13.spec.ts` (no screen code changed) |

`scripts/ora2pg.conf` is DMA's ora2pg template. If your server's copy has local changes, apply only these three lines instead of copying the file: `COMPILE_SCHEMA 0`, `DISABLE_UNLOGGED 1`, `PG_VERSION 16`. DMA also forces the first two itself in every run config.

## Deploy

1. Before copying: keep a copy of your current `ora2pgservice` and `ora2pgui` folders (way back in two minutes).
2. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
3. In `ora2pgservice`, run `npm test`. It should end with **Tests: 129 passed**.
4. No UI build needed (only a test file was added to `ora2pgui`).
5. On RHEL, **when no migration runs**:
   ```bash
   pm2 restart ora2pg-service-prod
   ```
   ```bash
   pm2 restart ora2pg-worker-prod
   ```
6. On each project: **Schema & snapshot → Refresh snapshot** (hidden nested-table storage tables disappear from the list).

## Test on RHEL

- [ ] **Source Oracle untouched:** in SQL Workbench (Oracle) note `SELECT object_name, last_ddl_time FROM all_objects WHERE owner = '<SCHEMA>' AND status = 'INVALID';`. Run a migration. Run the query again: the times are the same.
- [ ] **Object tables** (your project with CONFIGURATION_FULL / MONITORING_FULL): migrate them. **Validation**: "Primary & foreign key columns" shows YES for USER_ID, GROUP_NAME, PROPERTY_NAME and ID; "Unique constraints" no longer lists `SYS_NC_OID$`.
- [ ] **SQL Workbench** (PostgreSQL): `SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'configuration_full';` shows real types, not text.
- [ ] **Identity** (if the schema has identity columns): after the run, the Live monitor says "Identity columns: N set to continue…".
- [ ] **Live monitor** first lines show "Target PostgreSQL" with your version number.

## Tested on the Mac (real databases)

Test data (`dev-tools/testdb/07_batch13.sql`): object tables with a composite primary key, unique, check and NOT NULL constraints, an index and foreign keys in both directions; a nested table column with equal lists, an empty list, a NULL list and values with quotes and commas; identity columns (ALWAYS and BY DEFAULT with an explicit 100); text with chr(0); an invalid procedure.

| Proof | Result |
|---|---|
| Invalid procedure in the source Oracle | Before: recompiled during every run (change time = run time). After: unchanged |
| Object tables | Real types (bigint, varchar(200), numeric(6,2), timestamp(0)); primary key (3 columns), check, NOT NULL, index, both foreign keys validated |
| Validation on these tables | Row counts, keys, unique, indexes and table structure: no gap |
| Nested table | 5 rows: two equal lists, empty, NULL, quotes and commas: all exact; data check 4 lists / 7 items on both sides |
| Identity | Next values 21 (Oracle's own next) and 101 (after the explicit 100) |
| NUL character | Table loaded; "3 values contained the NUL character … removed (TXT: 2 rows, NTXT: 1 rows)" |

Tests on the final code:
- API unit **129** passed (13 new).
- API e2e full suite **70** passed, 0 failed (3 skipped: they need test setups not used here). Includes the 10 new batch 13 tests, the object table, DB link (postgres_fdw and oracle_fdw) and all migration tests.
- UI Vitest **52** passed.
- UI Playwright **31** passed (2 new).
