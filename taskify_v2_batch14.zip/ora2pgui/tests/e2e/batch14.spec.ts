import { expect, test } from '@playwright/test';
import { P, PROJECT, pageIsFine, watchErrors } from './helpers';

// Batch 14 screens against the real API: Copy project (DMA-057), Run details and Compare runs (DMA-077).

test('Projects: "Copy for another schema" offers the other schemas and a name; Cancel creates nothing', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto('/projects');
  const copyButton = page.getByRole('button', { name: `Copy ${PROJECT}`, exact: true });
  test.skip((await copyButton.count()) === 0, 'test project not connected');
  await copyButton.click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.getByText('Copy project for another schema')).toBeVisible();
  await dialog.getByRole('combobox', { name: /Oracle schema/ }).click();
  await expect(page.getByRole('option', { name: /\(this project\)/ })).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(dialog.getByLabel('New project name')).toHaveValue(new RegExp(`^${PROJECT}_`));
  await expect(dialog.getByRole('checkbox', { name: /Copy the settings too/ })).toBeChecked();
  await dialog.getByRole('button', { name: 'Cancel' }).click();
  await expect(dialog).toHaveCount(0);
  await pageIsFine(page);
  expect(errors).toEqual([]);
});

test('Runs: tick two runs, compare them side by side', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/runs`);
  const boxes = page.getByRole('checkbox', { name: /^Compare run / });
  test.skip((await boxes.count()) < 2, 'fewer than two runs in this project');
  const compare = page.getByRole('button', { name: /Tick 2 runs to compare|Compare the 2 runs/ });
  await expect(compare).toBeDisabled();
  await boxes.nth(0).check();
  await boxes.nth(1).check();
  await expect(page.getByRole('button', { name: 'Compare the 2 runs' })).toBeEnabled();
  await page.getByRole('button', { name: 'Compare the 2 runs' }).click();
  await expect(page).toHaveURL(/\/runs\/compare\?a=\d{8}-\d{6}&b=\d{8}-\d{6}$/);
  await expect(page.getByRole('heading', { name: 'Compare runs' })).toBeVisible();
  await expect(page.getByTestId('compare-diff-count')).toBeVisible();
  await page.getByLabel('Show only differences').uncheck();
  await expect(page.getByRole('table', { name: 'Run options' })).toBeVisible();
  await expect(page.getByRole('table', { name: 'Versions' })).toBeVisible();
  await pageIsFine(page);
  expect(errors).toEqual([]);
});

test('Run page: "Run details" shows what the run used', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/runs`);
  const first = page.locator('button.mono').first();
  test.skip((await first.count()) === 0, 'no runs in this project');
  await first.click();
  await page.getByText('Run details', { exact: true }).click();
  await expect(page.getByRole('table', { name: 'Run options' })).toBeVisible();
  await expect(page.getByTestId('detail-targetSchema')).toBeVisible();
  await expect(page.getByTestId('detail-pgMajor')).toBeVisible();
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
