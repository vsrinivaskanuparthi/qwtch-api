'use strict';

/**
 * Batch 14, the parts that need no database:
 *   DMA-075 CPU / memory guard: when the server is overloaded no new work starts, and it continues
 *           when the server recovers (or after the longest wait)
 *   DMA-077 Run details / Compare runs: the lines shown, differences marked, older runs
 *   DMA-085 global temporary tables: ora2pg's statement read correctly
 * Copy project (DMA-057) and the real migrations: tests/e2e/batch14.e2e.test.js.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

process.env.MIGRATION_STAGING_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-b14-'));
jest.mock('../../utils/logger', () => ({ info: jest.fn(), warn: jest.fn(), error: jest.fn(), debug: jest.fn() }));

const { ResourceGuard } = require('../../services/resourceGuard');
const { describeRuns, usedAtStart, NOT_RECORDED } = require('../../services/runCompare');
const { gttDefinition } = require('../../services/migrate');

afterAll(() => fs.rmSync(process.env.MIGRATION_STAGING_DIR, { recursive: true, force: true }));

describe('DMA-075 CPU and memory guard', () => {
  const GB = 1024 * 1024 * 1024;
  function setup({ cpu = 20, free = 8 * GB, maxWaitMs = 60000 } = {}) {
    const host = { cpu, free, cpuPct: () => host.cpu, freeBytes: () => host.free, totalBytes: () => 16 * GB };
    const run = { state: {}, events: [], event(level, message) { this.events.push({ level, message }); }, save: jest.fn() };
    let t = 0;
    const guard = new ResourceGuard({ run, host, sampleMs: 3600000, cpuMax: 95, minFreeMb: 1024, maxWaitMs, testLowMemoryMs: 0, now: () => t });
    guard.start();
    return { guard, host, run, advance: (ms) => { t += ms; } };
  }

  test('a healthy server: work starts at once', async () => {
    const { guard, run } = setup();
    await expect(guard.whenOk('table A')).resolves.toBeUndefined();
    expect(run.state.guard).toMatchObject({ status: 'ok', cpuPct: 20, pauses: 0, cpuMax: 95, minFreeMb: 1024 });
    guard.stop();
  });

  test('CPU full twice in a row: no new work until it drops, then it continues', async () => {
    const { guard, host, run, advance } = setup({ cpu: 99 });
    expect(guard.status).toBe('ok'); // one high measurement is not enough (a short spike)
    guard.sample();
    expect(guard.status).toBe('cpu');
    expect(run.events.at(-1)).toMatchObject({ level: 'error', message: expect.stringMatching(/CPU is full \(99 %\): DMA starts no new work/) });
    let started = false;
    const wait = guard.whenOk('table B').then(() => { started = true; });
    await Promise.resolve();
    expect(started).toBe(false);
    expect(run.state.guard).toMatchObject({ status: 'cpu', pauses: 1 });
    host.cpu = 40;
    advance(30000);
    guard.sample();
    await wait;
    expect(started).toBe(true);
    expect(run.events.at(-1).message).toMatch(/back to normal .*new work starts again/);
    expect(run.state.guard).toMatchObject({ status: 'ok', pausedSeconds: 30 });
    guard.stop();
  });

  test('memory short: paused at once (no second measurement needed)', () => {
    const { guard, run } = setup({ free: 300 * 1024 * 1024 });
    expect(guard.status).toBe('memory');
    expect(run.events[0].message).toMatch(/memory is short \(300 MB free, needs 1,024 MB\)/);
    guard.stop();
  });

  test('a run never hangs: after the longest wait the next step starts anyway, and says so', async () => {
    jest.useFakeTimers();
    try {
      const { guard, run } = setup({ free: 0, maxWaitMs: 5000 });
      let started = false;
      guard.whenOk('index ix_orders').then(() => { started = true; });
      jest.advanceTimersByTime(4999);
      await Promise.resolve();
      expect(started).toBe(false);
      jest.advanceTimersByTime(2);
      await Promise.resolve();
      expect(started).toBe(true);
      expect(run.events.at(-1).message).toMatch(/still busy after .*index ix_orders starts anyway/);
      guard.stop();
    } finally {
      jest.useRealTimers();
    }
  });

  test('stopping the run releases whatever was waiting', async () => {
    const { guard } = setup({ free: 0 });
    const wait = guard.whenOk('x');
    guard.stop();
    await expect(wait).resolves.toBeUndefined();
  });

  test('test switch: memory reported short for the first seconds only', () => {
    const host = { cpuPct: () => 10, freeBytes: () => 8 * GB, totalBytes: () => 16 * GB };
    const run = { state: {}, event: jest.fn(), save: jest.fn() };
    let t = 0;
    const guard = new ResourceGuard({ run, host, sampleMs: 3600000, testLowMemoryMs: 20000, now: () => t }).start();
    expect(guard.status).toBe('memory');
    t = 21000;
    guard.sample();
    expect(guard.status).toBe('ok');
    guard.stop();
  });
});

describe('DMA-077 Run details and Compare runs', () => {
  const settings = { ora2pg: { DEFAULT_NUMERIC: 'numeric', PRESERVE_CASE: false }, lob: { blobAs: 'bytea' }, extraDirectives: '', access: { readRoles: 'app_read', writeRoles: '' } };
  const state = (over = {}) => ({
    runId: '20261127-100000', status: 'COMPLETED', schema: 'APP', targetSchema: 'app', attempt: 1,
    createdAt: '2026-11-27T10:00:00.000Z', startedAt: '2026-11-27T10:00:00.000Z', finishedAt: '2026-11-27T10:05:30.000Z',
    options: { loadMode: 'direct', parallelTables: 4, maxAttempts: 3, verifyData: 'all', snapshot: 'on' },
    used: usedAtStart({ settings, meta: { snapshotAt: '2026-11-27T09:00:00.000Z' }, dmaVersion: '2.0.0' }),
    ora2pgVersion: '25.0', pgMajor: 16,
    phases: [{ key: 'data', status: 'done', startedAt: '2026-11-27T10:01:00.000Z', finishedAt: '2026-11-27T10:04:00.000Z' }],
    tables: { ORDERS: { status: 'done', rowsDone: 1000, pgRows: 1000, sizeMb: 10, attempts: 1, startedAt: '2026-11-27T10:01:00.000Z', finishedAt: '2026-11-27T10:02:00.000Z' } },
    ...over,
  });
  const row = (d, key) => d.sections.flatMap((s) => s.rows).find((r) => r.key === key);

  test('one run: every section, with what the run used', () => {
    const d = describeRuns([state()]);
    expect(d.sections.map((s) => s.title)).toEqual(['Run', 'Source and target', 'Versions', 'Run options', 'Migration decisions', 'Time per phase']);
    expect(row(d, 'duration').values).toEqual(['5 min 30 s']);
    expect(row(d, 'tables').values).toEqual(['1 of 1 done']);
    expect(row(d, 'rows').values).toEqual(['1,000']);
    expect(row(d, 'dmaVersion').values).toEqual(['2.0.0']);
    expect(row(d, 'ora2pgVersion').values).toEqual(['25.0']);
    expect(row(d, 'pgMajor').values).toEqual(['16']);
    expect(row(d, 'opt.parallelTables').values).toEqual(['4']);
    expect(row(d, 'opt.snapshot').values).toEqual(['on']);
    expect(row(d, 'dec.DEFAULT_NUMERIC').values).toEqual(['numeric']);
    expect(row(d, 'dec.readRoles').values).toEqual(['app_read']);
    expect(row(d, 'phase.data').values).toEqual(['3 min 0 s']);
    expect(row(d, 'gtt').values).toEqual(['none']);
    expect(d.sections.flatMap((s) => s.rows).some((r) => r.diff)).toBe(false);
  });

  test('two runs: the lines that differ are marked; times are not counted as differences', () => {
    const b = state({
      runId: '20261127-110000', startedAt: '2026-11-27T11:00:00.000Z', finishedAt: '2026-11-27T11:02:00.000Z',
      options: { loadMode: 'direct', parallelTables: 8, maxAttempts: 3, verifyData: 'all', snapshot: 'on' },
      used: usedAtStart({ settings: { ...settings, ora2pg: { ...settings.ora2pg, DEFAULT_NUMERIC: 'bigint' } }, meta: {}, dmaVersion: '2.0.0' }),
      tables: { ORDERS: { status: 'done', rowsDone: 1000, pgRows: 1000, attempts: 2 }, ITEMS: { status: 'failed', rowsDone: 0, attempts: 3 } },
    });
    const d = describeRuns([state(), b]);
    expect(d.runs.map((r) => r.runId)).toEqual(['20261127-100000', '20261127-110000']);
    expect(row(d, 'opt.parallelTables')).toMatchObject({ values: ['4', '8'], diff: true });
    expect(row(d, 'dec.DEFAULT_NUMERIC')).toMatchObject({ values: ['numeric', 'bigint'], diff: true });
    expect(row(d, 'opt.loadMode').diff).toBe(false);
    expect(row(d, 'startedAt').diff).toBe(false);
    expect(row(d, 'duration').diff).toBe(true);
    expect(d.tables.find((t) => t.name === 'ITEMS')).toMatchObject({ values: [null, { status: 'failed' }], diff: true });
    expect(d.tables.find((t) => t.name === 'ORDERS')).toMatchObject({ diff: false });
  });

  test('a run from before this version: its settings are "not recorded", nothing breaks', () => {
    const old = state({ used: undefined, ora2pgVersion: undefined, ora2pgMajor: 25, pgMajor: undefined });
    const d = describeRuns([old]);
    expect(row(d, 'dec.DEFAULT_NUMERIC').values).toEqual([NOT_RECORDED]);
    expect(row(d, 'dmaVersion').values).toEqual([NOT_RECORDED]);
    expect(row(d, 'ora2pgVersion').values).toEqual(['25']);
    expect(row(d, 'pgMajor').values).toEqual([NOT_RECORDED]);
  });

  test('global temporary tables of the run are listed', () => {
    const d = describeRuns([state({ gtt: { mode: 'template', schema: 'app_gtt', tables: [{ name: 'tmp', ok: true }], failed: [] } })]);
    expect(row(d, 'gtt').values).toEqual(['1 ready (templates in app_gtt)']);
  });
});

describe('DMA-085 global temporary tables: ora2pg\'s statement', () => {
  test('rows deleted at commit', () => {
    expect(gttDefinition('CREATE  /*GLOBAL*/ TEMPORARY TABLE tmp_calc (\n\tcalc_id numeric,\n\tresult numeric\n) ON COMMIT DELETE ROWS ;'))
      .toMatchObject({ name: 'tmp_calc', onCommit: 'DELETE', columns: expect.stringContaining('calc_id numeric') });
  });

  test('rows kept until the session ends, quoted name, schema prefix', () => {
    expect(gttDefinition('CREATE /*GLOBAL*/ TEMPORARY TABLE app."Work_Rows" (k varchar(40) NOT NULL, step smallint DEFAULT 1) ON COMMIT PRESERVE ROWS;'))
      .toMatchObject({ name: 'Work_Rows', onCommit: 'PRESERVE', columns: 'k varchar(40) NOT NULL, step smallint DEFAULT 1' });
  });

  test('other statements are not table definitions', () => {
    expect(gttDefinition("LOAD '$libdir/plugins/pgtt'")).toBeNull();
    expect(gttDefinition('CREATE TABLE normal (a int)')).toBeNull();
  });
});

describe('Simple screens for normal users', () => {
  test('"Where did the time go?" starts switched off (an admin can switch it on in My preferences)', async () => {
    const prefs = require('../../services/preferences');
    expect((await prefs.getPreferences({ id: 'b14fresh' })).monitor.timeReport).toBe(false);
    await prefs.savePreferences({ id: 'b14admin' }, { monitor: { timeReport: true } });
    expect((await prefs.getPreferences({ id: 'b14admin' })).monitor.timeReport).toBe(true);
  });
});
