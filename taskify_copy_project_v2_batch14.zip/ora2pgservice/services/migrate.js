'use strict';

/**
 * Migration engine (v2).
 *
 * What changed from v1, and why (target: 1 TB schemas without manual rescue):
 *  - Data is streamed by ora2pg straight into PostgreSQL (LOAD_MODE=direct). v1 wrote every table
 *    to a .sql file and then loaded it with psql, which needed the full schema size in free disk
 *    and read everything twice. LOAD_MODE=file keeps the v1 style for servers without DBD::Pg,
 *    but deletes each file as soon as it is loaded.
 *  - Tables are loaded in parallel (PARALLEL_TABLES), biggest first; huge tables also use several
 *    Oracle readers (-J) and PostgreSQL writers (-j).
 *  - Every table is a unit of work with its own status, attempts, rows, speed and log. A failed
 *    table is retried automatically (MAX_ATTEMPTS); the target table is truncated first, so a
 *    retry never duplicates rows. Other tables keep going.
 *  - Each loaded table is verified (row count in Oracle vs PostgreSQL) before it is marked done.
 *  - Indexes, constraints and foreign keys are created after the data (much faster), in parallel.
 *  - Sequence values are taken from Oracle after the load (v1 never reset sequences).
 *  - The whole run state is saved to runs/<runId>/state.json. If the server stops, the run is
 *    marked INTERRUPTED and "Resume" continues with only the work that is not done.
 *  - Progress is pushed to the browser with Server-Sent Events (services/events.js).
 *  - A failed run is reported as failed (v1 reported COMPLETED even when steps failed).
 */

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const pLimit = require('p-limit');
const oracledb = require('oracledb');

const logger = require('../utils/logger');
const { CONSTANTS } = require('../utils/constants');
const { runWithProject } = require('../utils/context');
const oracleClient = require('../utils/oracleClient');
const pgClient = require('../utils/postgreClient');
const { createRunLogger, executeAndLog, killProcessTree } = require('../errorHandling/error');
const { buildConfig } = require('./config_modify');
const { usedAtStart } = require('./runCompare');
const { ResourceGuard } = require('./resourceGuard');
const DMA_VERSION = require('../package.json').version;
const { ora2pgMajor } = require('../utils/ora2pgVersion');
const { RunNotifier } = require('./notify');
const settingsSvc = require('./settings');
const code = require('./code');
const { runSqlFile, splitSqlFile } = require('./sqlRunner');
const store = require('./projectStore');
const events = require('./events');
const runLock = require('./runLock');
const guards = require('./runGuards');
const cacheService = require('../utils/cache');
const { samplerFor } = require('./timeSplit');
const { Gate, SpeedTuner, readerRange } = require('./autoTune');

const PHASES = [
  { key: 'prepare', label: 'Prepare workspace & configuration' },
  { key: 'ddl', label: 'Export schema definitions from Oracle' },
  { key: 'tables', label: 'Create schema, types, sequences & tables' },
  { key: 'data', label: 'Load table data' },
  { key: 'indexes', label: 'Create indexes & constraints' },
  { key: 'fkeys', label: 'Create foreign keys' },
  { key: 'sequences', label: 'Set sequence values' },
  { key: 'code', label: 'Apply converted code objects (GenAI package) and DB links' },
  { key: 'finalize', label: 'Analyze tables & finalize' },
];

// Phases whose work is fully recorded on disk and is not repeated on resume.
const KEEP_ON_RESUME = new Set(['ddl']);


const TERMINAL = new Set(['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'EXPORTED']);
// Phases that only make sense once the data is in PostgreSQL: skipped by an export-only run, run on import.
const AFTER_LOAD = new Set(['indexes', 'fkeys', 'sequences', 'code', 'finalize']);

const active = new Map(); // projectName -> Run

// DMA_WORKER=on: migrations run in the worker process (worker.js), not in the API.
const IN_WORKER = process.env.DMA_ROLE === 'worker';
const RUNS_ELSEWHERE = CONSTANTS.WORKER && !IN_WORKER;

/**
 * Running child processes of a run. Their ids are also saved in state.json, so that after a
 * server crash the leftover ora2pg / psql processes can be stopped before the run is resumed
 * (otherwise they would keep writing into tables that the resume truncates and reloads).
 */
class ChildRegistry {
  constructor(run) {
    this.run = run;
    this.set = new Set();
  }

  add(child) {
    this.set.add(child);
    if (child.pid) {
      this.run.state.pids = [...new Set([...(this.run.state.pids || []), child.pid])];
      this.run.save(true);
    }
  }

  delete(child) {
    this.set.delete(child);
    if (child.pid) this.run.state.pids = (this.run.state.pids || []).filter((p) => p !== child.pid);
  }

  [Symbol.iterator]() {
    return this.set[Symbol.iterator]();
  }
}

class CancelledError extends Error {}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const qi = (s) => `"${String(s).replace(/"/g, '""')}"`;
const nowIso = () => new Date().toISOString();
const runDirOf = (projectName, runId) => path.join(store.runsDir(projectName), runId);

class Run {
  constructor(projectName, state) {
    this.projectName = projectName;
    this.state = state;
    this.dir = runDirOf(projectName, state.runId);
    this.children = new ChildRegistry(this);
    this.cancelRequested = false;
    this.lastTableEmit = new Map();
    this.saveTimer = null;
    this.tickTimer = null;
    this.gate = new Gate(); // readers at once: no limit unless auto-tune runs (phase_data)
    this.tuneMax = 0;
  }

  // ---------- state, persistence, events ----------

  summary() {
    const { tables, ...rest } = this.state;
    return { ...rest, totals: this.totals() };
  }

  totals() {
    const list = Object.values(this.state.tables);
    const t = { tables: list.length, done: 0, failed: 0, running: 0, pending: 0, estRows: 0, rowsDone: 0, sizeMb: 0, rate: 0 };
    for (const x of list) {
      // A table waiting for a free load slot (auto-tune) counts as waiting, not loading.
      const st = x.status === 'running' && x.waiting ? 'pending' : x.status;
      t[st] = (t[st] || 0) + 1;
      t.estRows += x.estRows || 0;
      t.rowsDone += x.status === 'done' ? Math.max(x.rowsDone || 0, x.pgRows || 0) : (x.rowsDone || 0);
      t.sizeMb += x.sizeMb || 0;
      if (x.status === 'running') t.rate += x.rate || 0;
    }
    return t;
  }

  save(immediate = false) {
    const write = () => {
      this.saveTimer = null;
      try {
        store.writeJsonAtomicSync(path.join(this.dir, 'state.json'), this.state);
      } catch (err) {
        logger.error(`Could not save run state ${this.state.runId}: ${err.message}`);
      }
    };
    if (immediate) {
      if (this.saveTimer) clearTimeout(this.saveTimer);
      write();
    } else if (!this.saveTimer) {
      this.saveTimer = setTimeout(write, 2000);
    }
  }

  emitRun() {
    events.publish(this.projectName, 'run', this.summary());
  }

  emitTable(name, force = false) {
    const last = this.lastTableEmit.get(name) || 0;
    if (!force && Date.now() - last < 1000) return; // at most one update per table per second
    this.lastTableEmit.set(name, Date.now());
    events.publish(this.projectName, 'table', { runId: this.state.runId, table: publicTable(this.state.tables[name]) });
  }

  /** ref ties an entry to a phase or table so the UI can pair "started" with "finished". */
  event(level, message, ref) {
    const entry = ref ? { at: nowIso(), level, message, ref } : { at: nowIso(), level, message };
    this.state.events.push(entry);
    if (this.state.events.length > 300) this.state.events.splice(0, this.state.events.length - 300);
    if (level === 'error') this.log.error(message);
    else this.log.info(message);
    events.publish(this.projectName, 'log', { runId: this.state.runId, ...entry });
  }

  setStatus(status, error) {
    this.state.status = status;
    if (error !== undefined) this.state.error = error;
    if (TERMINAL.has(status)) this.state.finishedAt = nowIso();
    this.save(true);
    this.emitRun();
  }

  phase(key) {
    return this.state.phases.find((p) => p.key === key);
  }

  updatePhase(key, patch) {
    Object.assign(this.phase(key), patch);
    this.save();
    this.emitRun();
  }

  updateTable(name, patch, force = false) {
    Object.assign(this.state.tables[name], patch);
    this.save();
    this.emitTable(name, force || patch.status !== undefined);
  }

  checkCancelled() {
    if (this.cancelRequested) throw new CancelledError('Run cancelled by user');
  }

  cancel() {
    this.cancelRequested = true;
    for (const child of this.children) killProcessTree(child);
  }

  // ---------- main loop ----------

  async execute() {
    this.log = createRunLogger(this.dir);
    this.state.startedAt = this.state.startedAt || nowIso();
    this.state.resumedAt = this.state.attempt > 1 ? nowIso() : undefined;
    this.setStatus('RUNNING', null);
    this.event('info', this.state.attempt > 1
      ? (this.state.autoResumedAt
        ? `Resumed automatically after a server restart (attempt ${this.state.attempt}; automatic resume ${this.state.autoResumes} of ${guards.autoResumeSettings().max}) (DMA-ENG-201)`
        : `Resuming run (attempt ${this.state.attempt})`)
      : `Migration started for schema ${this.state.schema} (${Object.keys(this.state.tables).length} tables)`);
    // Live totals (rows, speed) to the browser every 2 seconds while running.
    this.tickTimer = setInterval(() => this.emitRun(), 2000);
    // Staging disk watched during the run (services/runGuards.js).
    this.diskTimer = setInterval(() => { this.checkDisk().catch(() => {}); }, guards.diskLimits().everySeconds * 1000);
    // DMA-075: CPU and memory of this server watched in every phase; no new work starts while it is overloaded.
    this.guard = new ResourceGuard({ run: this }).start();
    // The worker lives for weeks: metadata cached by an earlier run may be older than the latest snapshot.
    if (IN_WORKER) cacheService.clearProject();
    this.notifier = new RunNotifier(this.projectName, this.state.runId, this.state.notifyEmails || []);
    this.notifier.started(this.state);
    await this.checkDisk().catch(() => {});

    try {
      for (const p of PHASES) {
        this.checkCancelled();
        const ph = this.phase(p.key);
        if (ph.status === 'done' || ph.status === 'skipped') continue;
        if (this.state.options.loadMode === 'export' && AFTER_LOAD.has(p.key)) {
          this.updatePhase(p.key, { status: 'skipped', detail: 'Export only: runs when the files are imported' });
          continue;
        }
        this.updatePhase(p.key, { status: 'running', startedAt: nowIso(), finishedAt: null, detail: null, progress: 0 });
        this.event('info', `Phase started: ${p.label}`, { type: 'phase', key: p.key, state: 'start' });
        try {
          await this[`phase_${p.key}`]();
          const after = this.phase(p.key);
          const status = after.skipped ? 'skipped' : after.warnings ? 'warning' : 'done';
          this.updatePhase(p.key, { status, finishedAt: nowIso(), progress: 100 });
          this.event('info', `Phase ${status === 'skipped' ? 'skipped' : 'finished'}: ${p.label}${after.warnings ? ` (${after.warnings} warnings)` : ''}`, { type: 'phase', key: p.key, state: status });
        } catch (err) {
          if (err instanceof CancelledError) throw err;
          this.updatePhase(p.key, { status: 'failed', finishedAt: nowIso(), detail: err.message });
          throw err;
        }
      }
      const t = this.totals();
      if (t.failed > 0) {
        this.setStatus('COMPLETED_WITH_ERRORS', `${t.failed} of ${t.tables} tables failed. Fix the cause and press Resume to retry only those tables.`);
        this.event('error', `Run finished with ${t.failed} failed tables`);
      } else if (this.state.options.loadMode === 'export') {
        this.setStatus('EXPORTED', `All ${t.tables} tables are exported to files in this run's data folder. Press "Import exported files" to load them into PostgreSQL.`);
        this.event('info', `Export completed: ${t.tables} tables, ${t.rowsDone.toLocaleString()} rows in files`);
      } else {
        this.setStatus('COMPLETED');
        this.event('info', `Migration completed: ${t.done} tables, ${t.rowsDone.toLocaleString()} rows`);
      }
    } catch (err) {
      if (this.shutdownRequested) {
        this.resetRunningTables('Server stopped');
        // Marked as stopped by the server: it resumes by itself when the server is back (unless switched off).
        this.state.interruptedBy = 'server';
        this.setStatus('INTERRUPTED', guards.autoResumeSettings().on
          ? 'The server was stopped while this run was in progress. It resumes by itself when the server is back; you can also press Resume.'
          : 'The server was stopped while this run was in progress. Press Resume to continue where it stopped.');
        this.event('error', 'Run interrupted by a server shutdown');
      } else if (this.stopReason) {
        this.resetRunningTables('Stopped: staging disk almost full');
        this.setStatus('FAILED', this.stopReason);
        this.event('error', 'Run stopped safely: staging disk almost full (DMA-SYS-202)');
      } else if (err instanceof CancelledError || this.cancelRequested) {
        this.resetRunningTables('Cancelled');
        this.setStatus('CANCELLED', 'Cancelled by user. Press Resume to continue.');
        this.event('info', 'Run cancelled');
      } else {
        logger.error(`Run ${this.state.runId} failed: ${err.stack}`);
        this.resetRunningTables(err.message);
        this.setStatus('FAILED', err.message);
        this.event('error', `Run failed: ${err.message}`);
      }
    } finally {
      clearInterval(this.tickTimer);
      clearInterval(this.diskTimer);
      if (this.guard) this.guard.stop();
      if (this.sampler) this.sampler.stop();
      this.save(true);
      this.emitRun();
      this.log.close();
      active.delete(this.projectName);
      try { runLock.release(this.projectName); } catch (err) { logger.error(`Run lock of ${this.projectName}: ${err.message}`); }
      if (IN_WORKER) {
        // Connections are opened again from the saved details by the next run (they may have changed in between).
        await oracleClient.closeOraclePool(this.projectName).catch(() => {});
        await pgClient.closePostgresPool(this.projectName).catch(() => {});
      }
      this.notifier.finished(this.state, this.totals());
      const projectStatus = await overallStatus(this.projectName, this.state).catch(() => this.state.status);
      await store.updateMeta(this.projectName, (m) => ({
        ...m,
        migrationStatus: projectStatus,
        lastMigrationDate: this.state.finishedAt,
        currentMigrationId: this.state.runId,
      })).catch(() => {});
    }
  }

  /** Disk watch: warning once below DISK_WARN_GB free, safe stop below DISK_STOP_GB (Resume continues). */
  async checkDisk() {
    if (this.stopReason || this.cancelRequested) return;
    const limits = guards.diskLimits();
    const space = await guards.diskSpace(CONSTANTS.STAGING_DIR);
    if (!space) return;
    const level = guards.diskLevel(space.free, limits);
    if (level === 'ok') { this.diskWarned = false; return; }
    if (level === 'warn') {
      if (this.diskWarned) return;
      this.diskWarned = true;
      const msg = `Staging disk is running low: ${guards.fmtGb(space.free)} free. Below ${limits.stopGb} GB the run stops safely. Free some space (old runs, export files). (DMA-SYS-201)`;
      this.event('error', msg);
      if (this.notifier) this.notifier.attention(`• ${msg}`);
      return;
    }
    this.stopReason = `Stopped safely: the staging disk is almost full (${guards.fmtGb(space.free)} free, limit ${limits.stopGb} GB). Free disk space, then press Resume to continue where it stopped. (DMA-SYS-202)`;
    this.event('error', this.stopReason);
    if (this.notifier) this.notifier.attention(`• ${this.stopReason}`);
    this.cancel();
  }

  resetRunningTables(reason) {
    for (const t of Object.values(this.state.tables)) {
      if (t.status === 'running') Object.assign(t, { status: 'pending', rate: 0, error: reason, waiting: false });
      (t.chunks || []).forEach((c) => { if (c.status === 'running' || c.status === 'queued') Object.assign(c, { status: 'pending', rate: 0 }); });
      // An open Live monitor sees the stop right away, not only after a reload.
      if (Array.isArray(t.chunks) && t.chunks.length) this.updateChunkInfo(t);
      this.emitTable(t.name, true);
    }
    for (const p of this.state.phases) if (p.status === 'running') p.status = 'pending';
  }

  // ---------- helpers ----------

  get schemaDir() { return path.join(this.dir, 'schema'); }
  get pgSchema() { return this.state.targetSchema; }

  /** Table / column name in PostgreSQL (lower case unless the project preserves case). */
  pgName(name) { return this.state.preserveCase ? name : name.toLowerCase(); }

  ora2pg(args, label, extra = {}) {
    return executeAndLog({
      cmd: CONSTANTS.ORA2PG_BIN,
      args,
      // Direct load: ora2pg's own PostgreSQL sessions (DBD::Pg reads PGOPTIONS) do not wait for the
      // WAL flush at each commit either. Safe here: every table is counted and checked afterwards.
      cwd: this.dir,
      log: this.log,
      children: this.children,
      label,
      ...extra,
      env: { PGOPTIONS: '-c synchronous_commit=off', ...(extra.env || {}) },
    });
  }

  psqlEnv() {
    return {
      PGPASSWORD: this.pg.password,
      PGSSLMODE: CONSTANTS.PG_SSLMODE,
      // Bulk load: commits do not wait for the WAL flush (ora2pg does the same for its own loads).
      PGOPTIONS: `-c search_path=${this.pgSchema},public -c synchronous_commit=off`,
    };
  }

  psqlArgs(extra) {
    return ['--host', this.pg.hostip, '--port', String(this.pg.port), '--dbname', this.pg.dbname, '--username', this.pg.username, '--no-psqlrc', ...extra];
  }

  psqlFile(file, label, { stopOnError = false, out } = {}) {
    if (!fs.existsSync(file)) {
      this.log.info(`${label}: nothing to apply (${path.relative(this.dir, file)} not generated)`);
      return Promise.resolve({ code: 0, skipped: true });
    }
    return executeAndLog({
      cmd: CONSTANTS.PSQL_BIN,
      args: this.psqlArgs(['-v', `ON_ERROR_STOP=${stopOnError ? 1 : 0}`, '-f', file]),
      env: this.psqlEnv(),
      cwd: this.dir,
      log: this.log,
      out,
      children: this.children,
      label,
    });
  }

  async pgTableExists(name) {
    const { rows } = await pgClient.pgQuery(
      'SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2 AND c.relkind IN (\'r\',\'p\')',
      [this.pgSchema, this.pgName(name)],
      this.projectName,
    );
    return rows.length > 0;
  }

  // ---------- phases ----------

  async phase_prepare() {
    const meta = await store.readMeta(this.projectName);
    this.oracle = store.oracleCredentials(meta);
    this.pg = store.postgresCredentials(meta);
    if (!this.oracle) throw new Error('Oracle source is not connected for this project.');
    if (!this.pg) throw new Error('PostgreSQL target is not connected for this project.');

    await oracleClient.ensureOraclePool(this.oracle, this.projectName);
    await pgClient.ensurePostgresPool(this.pg, this.projectName);

    const replaceCols = (meta.columnRenames || []).length
      ? Object.entries((meta.columnRenames || []).reduce((acc, c) => {
        (acc[c.tableName] = acc[c.tableName] || []).push(`${c.oldName}:${c.name}`);
        return acc;
      }, {})).map(([t, cols]) => `${t}(${cols.join(',')})`).join(' ')
      : null;

    const opts = this.state.options;
    this.settings = settingsSvc.resolve(meta);
    const directives = settingsSvc.ora2pgDirectives(this.settings);
    // ora2pg writes the SQL for this PostgreSQL version (identity, procedures, partitions…).
    try {
      this.state.pgMajor = await pgClient.serverMajor(this.projectName);
    } catch (err) {
      this.state.pgMajor = null;
      this.log.error(`PostgreSQL version could not be read, ora2pg default used: ${err.message}`);
    }
    await this.keyColumnTypes(directives);
    const base = {
      oracle: this.oracle,
      schema: this.state.schema,
      options: { dataLimit: opts.dataLimit, blobLimit: opts.blobLimit, replaceCols, pgSchema: this.pgSchema, directives, pgMajor: this.state.pgMajor },
    };
    // ddl.conf: exports to files. data.conf: streams rows into PostgreSQL (direct mode).
    this.ddlConf = await buildConfig({ ...base, outFile: path.join(this.dir, 'config', 'ddl.conf'), outputDir: this.schemaDir });
    this.dataConf = await buildConfig({
      ...base,
      options: { ...base.options, forData: true },
      outFile: path.join(this.dir, 'config', 'data.conf'),
      outputDir: path.join(this.dir, 'data'),
      postgres: opts.loadMode === 'direct' ? this.pg : null,
    });

    // Config for loads that go through a file even in direct mode (ROWID chunks, see copyTable).
    this.fileConf = opts.loadMode === 'direct'
      ? await buildConfig({ ...base, options: { ...base.options, forData: true }, outFile: path.join(this.dir, 'config', 'data_file.conf'), outputDir: path.join(this.dir, 'data'), postgres: null })
      : this.dataConf;
    this.columnRenames = meta.columnRenames || [];

    // Table definitions only for the selected tables (ALLOW list in its own config).
    const allTables = this.state.allTablesSelected;
    let tableConf = await fsp.readFile(this.ddlConf, 'utf8');
    if (!allTables) {
      const names = Object.keys(this.state.tables).map((n) => n.replace(/\$/g, '\\$'));
      tableConf = tableConf.replace(/^#?\s*ALLOW\s.*$/m, '') + `\nALLOW\t${names.join(' ')}\n`;
    }
    this.tableConf = path.join(this.dir, 'config', 'ddl_tables.conf');
    await fsp.writeFile(this.tableConf, tableConf, { mode: 0o600 });

    for (const d of ['data', 'schema']) await fsp.mkdir(path.join(this.dir, d), { recursive: true });

    const check = await executeAndLog({ cmd: CONSTANTS.ORA2PG_BIN, args: ['--version'], log: this.log, label: 'Check ora2pg', captureStdout: true });
    if (check.code !== 0) throw new Error(`ora2pg is not available (${CONSTANTS.ORA2PG_BIN}). ${check.errorTail}`);
    this.state.ora2pgMajor = ora2pgMajor(check.stdout);
    this.state.ora2pgVersion = ((/v?(\d+\.\d+)/.exec(check.stdout || '') || [])[1]) || null;
    if (this.state.ora2pgMajor && this.state.ora2pgMajor < 24) throw new Error(`ora2pg ${this.state.ora2pgMajor} is too old: version 24 or newer is needed.`);
    const psql = await executeAndLog({ cmd: CONSTANTS.PSQL_BIN, args: ['--version'], log: this.log, label: 'Check psql' });
    if (psql.code !== 0) throw new Error(`psql is not available (${CONSTANTS.PSQL_BIN}). ${psql.errorTail}`);

    if (this.state.pgMajor) this.event('info', `Target PostgreSQL ${this.state.pgMajor}: ora2pg writes the SQL for this version`);
    this.event('info', `Load mode: ${opts.loadMode}, ${opts.parallelTables} tables in parallel, huge tables ≥ ${opts.hugeTableRows.toLocaleString()} rows use ${opts.oracleCopies} Oracle readers / ${opts.pgJobs} writers`);
    await this.chooseSnapshot();
  }

  /**
   * With "NUMBER without precision → numeric" (exact, keeps decimals), the columns that cannot hold
   * decimals still become bigint (agreed rule: IDs and keys are BIGINT): primary / foreign key
   * columns declared NUMBER, and NUMBER(*,0) / INTEGER columns. Added to MODIFY_TYPE; a column the
   * user already lists there keeps the user's type. The data check still verifies every value.
   */
  async keyColumnTypes(directives) {
    const o = this.settings.ora2pg;
    if (!o.PG_INTEGER_TYPE || o.DEFAULT_NUMERIC !== 'numeric') return;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(
        `SELECT DISTINCT c.table_name, c.column_name FROM dba_tab_columns c
          WHERE c.owner = :o AND c.data_type = 'NUMBER' AND c.data_precision IS NULL
            AND (c.data_scale = 0 OR (c.data_scale IS NULL AND EXISTS (
              SELECT 1 FROM dba_cons_columns cc JOIN dba_constraints k ON k.owner = cc.owner AND k.constraint_name = cc.constraint_name
               WHERE cc.owner = c.owner AND cc.table_name = c.table_name AND cc.column_name = c.column_name AND k.constraint_type IN ('P', 'R'))))`,
        { o: this.state.schema });
      const own = new Set(String(directives.MODIFY_TYPE || '').split(',').map((x) => x.split(':').slice(0, 2).join(':').trim().toUpperCase()).filter(Boolean));
      const add = r.rows.filter(([t, c]) => !own.has(`${t}:${c}`.toUpperCase()) && !/[,:\s]/.test(t + c)).map(([t, c]) => `${t}:${c}:bigint`);
      if (!add.length) return;
      directives.MODIFY_TYPE = [directives.MODIFY_TYPE, ...add].filter(Boolean).join(',');
      this.event('info', `Key and whole-number columns declared NUMBER without precision become bigint: ${add.length} column${add.length === 1 ? '' : 's'}`);
    } catch (err) {
      this.log.error(`Key column types: ${err.message}`);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /**
   * ora2pg 25 reads every table AS OF SCN by default (ora2pg 24 only when given --scn), which needs the FLASHBACK privilege; without it every
   * load fails with ORA-41900. With the privilege the run uses ONE SCN for all tables, chunks,
   * retries and row-count checks: a consistent point in time even if the application keeps writing.
   * Without it, data is read as it is now (--no_start_scn) and the application must be stopped.
   * A resumed run keeps its SCN; if Oracle's undo no longer reaches back that far, see snapshotTooOld().
   */
  async chooseSnapshot() {
    const prev = this.state.snapshot;
    if (this.state.options.snapshot === 'off') {
      this.state.snapshot = { mode: 'current', reason: 'turned off in the run settings', at: nowIso() };
      this.event('info', prev && prev.mode === 'scn'
        ? `Snapshot turned off for this resume: the remaining tables are read as they are now (tables already loaded keep SCN ${prev.scn}). Keep the application stopped.`
        : 'Snapshot off: tables are read as they are now. Keep the application stopped during the load.');
      this.save(true);
      return;
    }
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const scn = prev && prev.mode === 'scn' ? prev.scn : String((await conn.execute('SELECT current_scn FROM v$database')).rows[0][0]);
      const probe = Object.keys(this.state.tables)[0];
      if (probe) await conn.execute(`SELECT 1 FROM ${qi(this.state.schema)}.${qi(probe)} AS OF SCN ${scn} WHERE ROWNUM = 1`);
      this.state.snapshot = { mode: 'scn', scn, at: prev && prev.mode === 'scn' ? prev.at : nowIso() };
      if (!prev || prev.mode !== 'scn') this.event('info', `Consistent snapshot: all tables are read as of Oracle SCN ${scn}`);
    } catch (err) {
      const reason = /ORA-41900|ORA-01031|ORA-00942/.test(err.message) ? 'the migration user has no FLASHBACK privilege' : err.message.split('\n')[0];
      if (prev && prev.mode === 'scn' && /ORA-01555|ORA-08180|ORA-08181/.test(err.message)) {
        throw new Error(`The run's snapshot (SCN ${prev.scn}) is older than Oracle's undo retention (${err.message.split('\n')[0]}). Start a new run, or raise UNDO_RETENTION.`);
      }
      this.state.snapshot = { mode: 'current', reason, at: nowIso() };
      this.event('error', `No consistent snapshot (${reason}): tables are read as they are now. Keep the application stopped during the load, or grant FLASHBACK ANY TABLE to the migration user.`);
    } finally {
      await conn.close().catch(() => {});
    }
    this.save(true);
  }

  /**
   * ora2pg arguments for the run's snapshot. --scn works in ora2pg 24 and 25. Without a snapshot,
   * ora2pg 25 must be told --no_start_scn (it reads AS OF the current SCN by default, which needs
   * FLASHBACK); ora2pg 24 reads current data by default and does not know that option.
   */
  snapshotArgs() {
    if (this.state.snapshot && this.state.snapshot.mode === 'scn') return ['--scn', this.state.snapshot.scn];
    return this.state.ora2pgMajor && this.state.ora2pgMajor < 25 ? [] : ['--no_start_scn'];
  }

  /** Identifies the data an export file holds: a file is only re-imported for the same snapshot. */
  snapshotKey() {
    const snap = this.state.snapshot && this.state.snapshot.mode === 'scn' ? `scn:${this.state.snapshot.scn}` : 'current';
    return `${snap}|${this.state.decisionsHash || ''}`;
  }

  asOf() {
    return this.state.snapshot && this.state.snapshot.mode === 'scn' ? ` AS OF SCN ${this.state.snapshot.scn}` : '';
  }

  /** Selected tables that are partitioned in Oracle, or null when the dictionary cannot be read. */
  async partitionedTables() {
    let conn;
    try {
      conn = await oracleClient.getOracleConnection(this.projectName);
      const r = await conn.execute(`SELECT table_name FROM dba_tables WHERE owner = :owner AND partitioned = 'YES'`, { owner: this.state.schema });
      const names = r.rows.map((row) => row[0]);
      return this.state.allTablesSelected ? names : names.filter((n) => this.state.tables[n]);
    } catch (err) {
      this.log.info(`Partitioned tables could not be listed (${err.message.split('\n')[0]}): partitions are exported`);
      return null;
    } finally {
      if (conn) await conn.close().catch(() => {});
    }
  }

  async phase_ddl() {
    const exportType = (type, dir, file, conf, required) => async () => {
      this.checkCancelled();
      await fsp.mkdir(path.join(this.schemaDir, dir), { recursive: true });
      const res = await this.ora2pg(['-p', '-t', type, '-c', conf, '-b', path.join(this.schemaDir, dir), '-o', file], `Export ${type}`);
      if (res.code !== 0) {
        if (required) throw new Error(`ora2pg could not export ${type}: ${res.errorTail || 'see master.log'}`);
        this.phase('ddl').warnings = (this.phase('ddl').warnings || 0) + 1;
        this.event('error', `Export ${type} failed (not blocking): ${res.errorTail.split('\n')[0] || 'see log'}`);
      }
      done += 1;
      this.updatePhase('ddl', { progress: Math.round((done / total) * 100), detail: `Exported ${type}` });
    };

    // DMA-085: Oracle global temporary tables (structure only), exported by ora2pg in its pgtt form.
    const gtts = await this.globalTempTables();
    let gttConf = null;
    if (gtts.length) {
      gttConf = path.join(this.dir, 'config', 'ddl_gtt.conf');
      const base = await fsp.readFile(this.ddlConf, 'utf8');
      await fsp.writeFile(gttConf, `${base.replace(/^#?\s*ALLOW\s.*$/m, '').replace(/^#?\s*EXPORT_GTT\s.*$/m, '')}\nEXPORT_GTT\t1\nPGTT_NOSUPERUSER\t1\nALLOW\t${gtts.map((g) => g.name.replace(/\$/g, '\\$')).join(' ')}\n`, { mode: 0o600 });
    }
    const jobs = [
      ...(gttConf ? [exportType('TABLE', 'gtt', 'gtt.sql', gttConf, false)] : []),
      exportType('TABLE', 'tables', 'table.sql', this.tableConf, true),
      exportType('SEQUENCE', 'sequences', 'sequence.sql', this.ddlConf, true),
      exportType('TYPE', 'types', 'type.sql', this.ddlConf, false),
    ];
    // Partitions of partitioned tables: without them PostgreSQL has a partitioned table that accepts no rows.
    // ora2pg's PARTITION export reads the indexes and keys of the whole schema, which is slow on a large
    // one, so it only runs when a selected table is partitioned.
    const parted = await this.partitionedTables();
    if (!parted || parted.length) jobs.push(exportType('PARTITION', 'partitions', 'partition.sql', this.tableConf, false));
    else this.event('info', 'No partitioned tables selected: partition export skipped');
    // Views, PL/SQL, triggers, DB links… are exported separately as the GenAI package
    // (Code objects page) and applied by the "code" phase when a converted package is chosen.
    let done = 0;
    const total = jobs.length;
    await Promise.all(jobs.map((j) => j()));

    // v1 helper scripts: remove duplicate sequences, convert Oracle Text indexes on LOBs.
    const seqDir = path.join(this.schemaDir, 'sequences');
    if (fs.existsSync(path.join(seqDir, 'sequence.sql'))) {
      await executeAndLog({ cmd: 'bash', args: [path.join(CONSTANTS.SCRIPTS_DIR, 'sequence.sh'), 'sequence.sql', 'modified_sequence.sql'], cwd: seqDir, log: this.log, label: 'Remove duplicate sequences' });
    }
    const tblDir = path.join(this.schemaDir, 'tables');
    if (fs.existsSync(path.join(tblDir, 'INDEXES_table.sql'))) {
      // Oracle Text indexes on LOBs become a text column + GIN index. v1 had two variants of the
      // helper: fts_bytea.sh (BLOB stored as bytea) and fts_oid.sh (BLOB stored as large object).
      const oid = this.settings.lob.blobAs === 'oid';
      await executeAndLog({
        cmd: 'bash',
        args: oid
          ? [path.join(CONSTANTS.SCRIPTS_DIR, 'fts_oid.sh'), 'INDEXES_table.sql']
          : [path.join(CONSTANTS.SCRIPTS_DIR, 'fts_bytea.sh'), 'INDEXES_table.sql', 'modified_INDEXES_table.sql'],
        cwd: tblDir,
        log: this.log,
        label: 'Prepare full-text indexes',
      });
    }
  }

  async phase_tables() {
    await pgClient.pgQuery(`CREATE SCHEMA IF NOT EXISTS ${qi(this.pgSchema)}`, [], this.projectName);
    const out = this.log.tableLog('_ddl');
    const seqFile = fs.existsSync(path.join(this.schemaDir, 'sequences', 'modified_sequence.sql'))
      ? path.join(this.schemaDir, 'sequences', 'modified_sequence.sql')
      : path.join(this.schemaDir, 'sequences', 'sequence.sql');

    this.updatePhase('tables', { detail: 'Creating types', progress: 10 });
    await this.psqlFile(await this.pgTypesFile(), 'Create types', { out });
    await this.fixTypeLengths(out);
    this.updatePhase('tables', { detail: 'Creating sequences', progress: 30 });
    await this.psqlFile(await this.noStopCopy(seqFile), 'Create sequences', { out });
    this.checkCancelled();
    this.updatePhase('tables', { detail: 'Creating tables', progress: 50 });
    // A new run rebuilds the tables whose definition changed (e.g. a new type mapping in Settings).
    if ((this.state.attempt || 1) === 1) await this.rebuildChangedTables(out);
    // Existing tables (from an earlier run) only produce "already exists" errors; their data is
    // truncated before loading, so re-running is safe.
    await this.psqlFile(await this.noStopCopy(path.join(this.schemaDir, 'tables', 'table.sql'), this.state.preserveCase ? quoteGeneratedColumns : undefined), 'Create tables', { out });
    this.updatePhase('tables', { detail: 'Creating partitions', progress: 70 });
    await this.psqlFile(await this.noStopCopy(path.join(this.schemaDir, 'partitions', 'partition.sql')), 'Create partitions', { out });
    await this.ensureDefaultPartitions(out);
    out.end();

    // Oracle object tables: ora2pg does not create them. The engine creates them from their type.
    for (const t of Object.values(this.state.tables).filter((x) => x.kind === 'object' && x.status !== 'done')) {
      await this.createObjectTable(t);
    }

    // DMA-085: global temporary tables (structure only; they hold no data to migrate).
    await this.createGlobalTempTables().catch((err) => {
      this.phase('tables').warnings = (this.phase('tables').warnings || 0) + 1;
      this.event('error', `Global temporary tables could not be created: ${err.message}`);
    });

    // Every selected table must now exist in PostgreSQL.
    let missing = 0;
    for (const t of Object.values(this.state.tables)) {
      if (t.status === 'done') continue;
      if (!(await this.pgTableExists(t.name))) {
        missing += 1;
        this.updateTable(t.name, { status: 'failed', error: 'Table definition could not be created in PostgreSQL (see the _ddl table log)' }, true);
      }
    }
    if (missing) {
      this.phase('tables').warnings = missing;
      this.event('error', `${missing} tables could not be created; their data load is skipped`);
    }
  }

  /**
   * Tables that already exist in the target but would now be created differently (other column
   * types or columns, e.g. after "NUMBER without precision" changed from bigint to numeric) are
   * dropped, so this run creates them with the new definition: "already exists" would otherwise
   * keep the old types. The new definitions are created in a scratch schema and compared column by
   * column; the scratch schema is removed afterwards. Foreign keys pointing at a rebuilt table are
   * re-created by the foreign key phase; views using it are named in the log (apply the code again).
   */
  async rebuildChangedTables(out) {
    const file = path.join(this.schemaDir, 'tables', 'table.sql');
    if (!fs.existsSync(file)) return;
    const todo = Object.values(this.state.tables).filter((t) => t.status !== 'done').map((t) => this.pgName(t.name));
    if (!todo.length) return;
    const { rows: existing } = await pgClient.pgQuery(
      `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = $1 AND c.relkind IN ('r', 'p') AND c.relname = ANY($2)`, [this.pgSchema, todo], this.projectName);
    if (!existing.length) return;
    const scratch = `dma_check_${String(this.state.runId).replace(/\D/g, '')}`;
    const columns = async (schema) => {
      const { rows } = await pgClient.pgQuery(
        `SELECT c.relname, a.attname, format_type(a.atttypid, a.atttypmod) AS type, a.attgenerated
           FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relkind IN ('r', 'p') AND c.relname = ANY($2) AND a.attnum > 0 AND NOT a.attisdropped`,
        [schema, existing.map((r) => r.relname)], this.projectName);
      const m = new Map();
      for (const r of rows) {
        if (!m.has(r.relname)) m.set(r.relname, []);
        m.get(r.relname).push(`${r.attname} ${r.type}${r.attgenerated ? ' generated' : ''}`);
      }
      for (const v of m.values()) v.sort();
      return m;
    };
    let changed = [];
    try {
      await pgClient.pgQuery(`DROP SCHEMA IF EXISTS ${qi(scratch)} CASCADE`, [], this.projectName);
      await pgClient.pgQuery(`CREATE SCHEMA ${qi(scratch)}`, [], this.projectName);
      const copy = path.join(this.schemaDir, 'tables', 'table_check.sql');
      const text = (await fsp.readFile(file, 'utf8'))
        .replace(/^\s*\\set\s+ON_ERROR_STOP\s+ON\s*$/gim, '')
        .replace(/^\s*SET\s+search_path\s*=[^;]*;/gim, `SET search_path = ${qi(scratch)},${qi(this.pgSchema)},public;`);
      await fsp.writeFile(copy, this.state.preserveCase ? quoteGeneratedColumns(text) : text);
      await this.psqlFile(copy, 'Compare table definitions (scratch copy)', { out });
      const [now, next] = [await columns(this.pgSchema), await columns(scratch)];
      changed = [...now.keys()].filter((t) => next.has(t) && now.get(t).join('|') !== next.get(t).join('|'));
    } catch (err) {
      this.log.error(`Table definition check: ${err.message}`);
    } finally {
      await pgClient.pgQuery(`DROP SCHEMA IF EXISTS ${qi(scratch)} CASCADE`, [], this.projectName).catch(() => {});
    }
    for (const rel of changed) {
      const name = Object.keys(this.state.tables).find((n) => this.pgName(n) === rel) || rel;
      try {
      const { rows: views } = await pgClient.pgQuery(
        `SELECT DISTINCT v.relname FROM pg_depend d JOIN pg_rewrite w ON w.oid = d.objid JOIN pg_class v ON v.oid = w.ev_class
          WHERE d.refobjid = (SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2)
            AND v.relname <> $2`, [this.pgSchema, rel], this.projectName).catch(() => ({ rows: [] }));
      await this.dropReferencingFks(name);
      await pgClient.pgQuery(`DROP TABLE ${qi(this.pgSchema)}.${qi(rel)} CASCADE`, [], this.projectName);
      this.event('info', `Table ${name} is rebuilt: its definition changed since it was created (e.g. a new type mapping)${views.length ? `. Views that used it were dropped: ${views.map((v) => v.relname).join(', ')}: apply the converted code again` : ''}`);
      } catch (err) {
        // The table keeps its old definition; its data check will say so if the values do not fit.
        this.event('error', `Table ${name} could not be rebuilt with its new definition: ${err.message.split('\n')[0]}`);
      }
    }
  }

  /** DMA-085: the schema's Oracle global temporary tables: [{ name, onCommit: 'DELETE' | 'PRESERVE' }]. */
  async globalTempTables() {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(
        `SELECT table_name, duration FROM dba_tables WHERE owner = :o AND temporary = 'Y' AND secondary = 'N' AND nested = 'NO'
            AND table_name NOT LIKE 'SYS\\_TEMP%' ESCAPE '\\' ORDER BY table_name`, { o: this.state.schema });
      this.state.gttNames = r.rows.map(([name]) => name);
      return r.rows.map(([name, duration]) => ({ name, onCommit: duration === 'SYS$SESSION' ? 'PRESERVE' : 'DELETE' }));
    } catch (err) {
      this.log.error(`Global temporary tables could not be listed: ${err.message}`);
      return [];
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /**
   * DMA-085: creates the Oracle global temporary tables in PostgreSQL, from ora2pg's export
   * (schema/gtt/gtt.sql: CREATE /*GLOBAL*\/ TEMPORARY TABLE t (...) ON COMMIT DELETE|PRESERVE ROWS).
   *   - pgtt ready (extension created in the target database, loadable by DMA's user, CREATE on
   *     pgtt_schema): real global temporary tables, kept by pgtt in pgtt_schema. Each session sees
   *     only its own rows; the application's sessions must load pgtt (the DBA sets
   *     session_preload_libraries) and have pgtt_schema in their search_path. No code change.
   *   - otherwise (or DMA_GTT_PGTT=off on the server): each table's structure as a template in the
   *     schema <target>_gtt, plus <target>_gtt.dma_gtt_use('t'), which gives the calling session its
   *     own temporary copy (CREATE TEMP TABLE … (LIKE template) ON COMMIT …). Code calls it once per
   *     session before using the table; the GenAI conversion instructions say so.
   * Existing ones are kept (a new run never drops a temporary table definition). Result in state.gtt.
   */
  async createGlobalTempTables() {
    const file = path.join(this.schemaDir, 'gtt', 'gtt.sql');
    if (!fs.existsSync(file)) return;
    const defs = splitSqlFile(file).statements.map(gttDefinition).filter(Boolean);
    if (!defs.length) return;
    const roles = settingsSvc.appRoles(this.settings);
    const client = await pgClient.getPostgresConnection(this.projectName);
    let destroy = false;
    const out = { mode: 'template', schema: null, tables: [], created: 0, existing: 0, failed: [] };
    try {
      let pgtt = false;
      if (process.env.DMA_GTT_PGTT !== 'off' && (await client.query(`SELECT 1 FROM pg_extension WHERE extname = 'pgtt'`)).rowCount) {
        for (const lib of ['$libdir/plugins/pgtt', 'pgtt']) {
          try {
            await client.query(`LOAD '${lib}'`);
            pgtt = true;
            destroy = true; // this pooled session now has pgtt loaded: not given back to the pool
            break;
          } catch { /* not loadable this way */ }
        }
        if (pgtt) pgtt = (await client.query(`SELECT has_schema_privilege('pgtt_schema', 'CREATE') AS ok`)).rows[0].ok;
        if (!pgtt) this.log.info('pgtt is installed but cannot be used by DMA\'s user (loadable from $libdir/plugins and CREATE on pgtt_schema): templates are used');
      }
      const exists = async (schema, name) => (await client.query(
        `SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2`, [schema, name])).rowCount > 0;
      if (pgtt) {
        out.mode = 'pgtt';
        out.schema = 'pgtt_schema';
        await client.query(`SET search_path = ${qi(this.pgSchema)}, public`);
        for (const d of defs) {
          try {
            if (await exists('pgtt_schema', d.name)) out.existing += 1;
            else { await client.query(d.stmt.replace(/;\s*$/, '')); out.created += 1; }
            for (const role of roles) await client.query(`GRANT SELECT, INSERT, UPDATE, DELETE ON pgtt_schema.${qi(d.name)} TO ${qi(role)}`).catch(() => {});
            out.tables.push({ name: d.name, onCommit: d.onCommit, ok: true });
          } catch (err) {
            out.failed.push({ name: d.name, error: err.message });
            out.tables.push({ name: d.name, onCommit: d.onCommit, ok: false });
          }
        }
        await this.gttKeys(client, 'pgtt_schema', out);
      } else {
        const schema = `${this.pgSchema}_gtt`;
        const sch = qi(schema);
        out.schema = schema;
        await client.query(`CREATE SCHEMA IF NOT EXISTS ${sch}`);
        for (const d of defs) {
          try {
            if (await exists(schema, d.name)) out.existing += 1;
            else {
              await client.query(`CREATE TABLE ${sch}.${qi(d.name)} (${d.columns})`);
              out.created += 1;
            }
            await client.query(`COMMENT ON TABLE ${sch}.${qi(d.name)} IS 'Template of Oracle global temporary table ${d.name} (ON COMMIT ${d.onCommit} ROWS). Each session calls ${schema}.dma_gtt_use(''${d.name}'') once, then uses ${d.name}.'`);
            out.tables.push({ name: d.name, onCommit: d.onCommit, ok: true });
          } catch (err) {
            out.failed.push({ name: d.name, error: err.message });
            out.tables.push({ name: d.name, onCommit: d.onCommit, ok: false });
          }
        }
        await this.gttKeys(client, schema, out);
        await client.query(`CREATE OR REPLACE FUNCTION ${sch}.dma_gtt_use(p_table text) RETURNS void LANGUAGE plpgsql AS $fn$
DECLARE
  v_comment text;
BEGIN
  -- This session's own copy of an Oracle global temporary table (created by DMA from its template).
  IF to_regclass('pg_temp.' || quote_ident(p_table)) IS NOT NULL THEN
    RETURN;
  END IF;
  SELECT obj_description(c.oid, 'pg_class') INTO v_comment
    FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
   WHERE n.nspname = ${pgLiteralSql(schema)} AND c.relname = p_table;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'No global temporary table %', p_table;
  END IF;
  EXECUTE format('CREATE TEMP TABLE %I (LIKE %I.%I INCLUDING DEFAULTS INCLUDING CONSTRAINTS INCLUDING INDEXES) ON COMMIT %s',
    p_table, ${pgLiteralSql(schema)}, p_table, CASE WHEN v_comment LIKE '%PRESERVE ROWS%' THEN 'PRESERVE ROWS' ELSE 'DELETE ROWS' END);
END
$fn$`);
        for (const role of roles) {
          await client.query(`GRANT USAGE ON SCHEMA ${sch} TO ${qi(role)}`).catch(() => {});
          await client.query(`GRANT SELECT ON ALL TABLES IN SCHEMA ${sch} TO ${qi(role)}`).catch(() => {});
          await client.query(`GRANT EXECUTE ON FUNCTION ${sch}.dma_gtt_use(text) TO ${qi(role)}`).catch(() => {});
        }
      }
    } finally {
      client.release(destroy);
    }
    this.state.gtt = out;
    const n = out.created + out.existing;
    if (out.failed.length) {
      this.phase('tables').warnings = (this.phase('tables').warnings || 0) + out.failed.length;
      this.event('error', `Global temporary tables: ${out.failed.length} could not be created (${out.failed.slice(0, 3).map((f) => `${f.name}: ${f.error}`).join('; ')})`);
    }
    if (n) {
      this.event('info', out.mode === 'pgtt'
        ? `Global temporary tables: ${n} ready with the pgtt extension (${out.created} created, ${out.existing} already there). Each session sees only its own rows; no code change needed.`
        : `Global temporary tables: ${n} ready as templates in schema ${out.schema} (${out.created} created, ${out.existing} already there; pgtt not available). Code calls ${out.schema}.dma_gtt_use('<table>') once per session before using one.`);
    }
  }

  /**
   * Primary / unique keys, NOT NULL, checks and indexes of the global temporary tables (ora2pg's
   * schema/gtt/CONSTRAINTS_gtt.sql and INDEXES_gtt.sql), added to their definition in `schema`
   * (pgtt_schema, or the template schema) right after creation: every session's copy then has them.
   */
  async gttKeys(client, schema, out) {
    out.keys = { created: 0, existing: 0, failed: 0 };
    for (const f of ['CONSTRAINTS_gtt.sql', 'INDEXES_gtt.sql']) {
      const file = path.join(this.schemaDir, 'gtt', f);
      if (!fs.existsSync(file)) continue;
      await client.query(`SET search_path = ${qi(schema)}, public`);
      for (const stmt of splitSqlFile(file).statements) {
        if (/^\s*(LOAD|SET)\b/i.test(stmt)) continue;
        try {
          await client.query(stmt.replace(/;\s*$/, ''));
          out.keys.created += 1;
        } catch (err) {
          if (/already exists|multiple primary keys/i.test(err.message)) out.keys.existing += 1;
          else {
            out.keys.failed += 1;
            out.failed.push({ name: stmt.slice(0, 80), error: err.message });
          }
        }
      }
    }
    await client.query(`SET search_path = ${qi(this.pgSchema)}, public`);
  }

  /**
   * An Oracle object table (CREATE TABLE x OF type_t) becomes a normal PostgreSQL table with the
   * columns and types of its type: created OF the composite type ora2pg made for type_t (so the
   * column types follow the Settings decisions and the type length fix), then detached (NOT OF) so
   * it is an ordinary table. Keys, constraints and indexes come later (objectTableDdl). Without a
   * usable type (XMLTYPE tables, a type from another schema) it falls back to TEXT columns, as v1 did.
   * A TEXT copy left by an earlier DMA version is rebuilt with the real types (its data is reloaded).
   */
  async createObjectTable(t) {
    const pgTable = `${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`;
    let typeName = null;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute('SELECT table_type_owner, table_type FROM dba_object_tables WHERE owner = :o AND table_name = :t', { o: this.state.schema, t: t.name });
      if (r.rows.length && r.rows[0][0] === this.state.schema) typeName = this.pgName(r.rows[0][1]);
    } finally {
      await conn.close().catch(() => {});
    }
    let typeExists = false;
    if (typeName) {
      const { rows } = await pgClient.pgQuery(
        `SELECT 1 FROM pg_type ty JOIN pg_namespace n ON n.oid = ty.typnamespace WHERE n.nspname = $1 AND ty.typname = $2 AND ty.typtype = 'c'`,
        [this.pgSchema, typeName], this.projectName);
      typeExists = rows.length > 0;
    }
    if (await this.pgTableExists(t.name)) {
      if (!typeExists) return;
      const { rows } = await pgClient.pgQuery(
        `SELECT bool_and(format_type(a.atttypid, a.atttypmod) = 'text') AS all_text FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relname = $2 AND a.attnum > 0 AND NOT a.attisdropped`, [this.pgSchema, this.pgName(t.name)], this.projectName);
      if (!rows[0].all_text) return;
      try {
        await pgClient.pgQuery(`DROP TABLE ${pgTable}`, [], this.projectName);
        this.event('info', `Object table ${t.name}: the TEXT copy from an earlier run is rebuilt with the column types of ${typeName}`);
      } catch (err) {
        this.event('error', `Object table ${t.name} stays a TEXT copy: ${err.message}`);
        t.textFallback = true;
        return;
      }
    }
    if (typeExists) {
      try {
        await pgClient.pgQuery(`CREATE TABLE ${pgTable} OF ${qi(this.pgSchema)}.${qi(typeName)}`, [], this.projectName);
        await pgClient.pgQuery(`ALTER TABLE ${pgTable} NOT OF`, [], this.projectName);
        t.textFallback = false;
        this.event('info', `Created object table ${t.name} with the columns of its type ${typeName}`);
        return;
      } catch (err) {
        this.log.error(`Object table ${t.name} from type ${typeName} failed, TEXT copy used: ${err.message}`);
      }
    }
    t.textFallback = true;
    await this.createObjectTableFallback(t.name);
  }

  async createObjectTableFallback(table) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(
        'SELECT column_name FROM all_tab_columns WHERE owner = :o AND table_name = :t ORDER BY column_id',
        { o: this.state.schema, t: table },
      );
      const cols = r.rows.map((x) => `${qi(this.pgName(x[0]))} TEXT`);
      if (!cols.length) return;
      await pgClient.pgQuery(`CREATE TABLE IF NOT EXISTS ${qi(this.pgSchema)}.${qi(this.pgName(table))} (${cols.join(', ')})`, [], this.projectName);
      this.event('info', `Created TEXT fallback table for Oracle object table ${table}`);
    } finally {
      await conn.close();
    }
  }

  /**
   * ora2pg 25 gives every VARCHAR2 attribute of an object type the length of the last one
   * (ADDRESS_T(street varchar2(80), …, country varchar2(2)) became four varchar(2)), so the data does
   * not fit. The real lengths come from DBA_TYPE_ATTRS; shorter attributes in PostgreSQL are widened
   * (CASCADE also fixes tables that already use the type, e.g. on resume).
   */
  /**
   * A copy of an ora2pg DDL file without its "\set ON_ERROR_STOP ON": one statement PostgreSQL
   * rejects (on a re-run usually "already exists") must not stop every statement after it, such as
   * a new table further down. The error is still logged; the existence check after the DDL
   * reports any table that really could not be created.
   */
  async noStopCopy(file, transform = (text) => text) {
    if (!fs.existsSync(file)) return file;
    const dst = file.replace(/\.sql$/, '_pg.sql');
    const text = (await fsp.readFile(file, 'utf8')).replace(/^\s*\\set\s+ON_ERROR_STOP\s+ON\s*$/gim, '');
    await fsp.writeFile(dst, transform(text));
    return dst;
  }

  /** type.sql as PostgreSQL can run it: Oracle type changes (ALTER TYPE ... MODIFY / ADD / DROP ATTRIBUTE) rewritten. */
  pgTypesFile() {
    return this.noStopCopy(path.join(this.schemaDir, 'types', 'type.sql'), pgTypeSql);
  }

  async fixTypeLengths(out) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    let attrs;
    try {
      attrs = (await conn.execute(
        `SELECT a.type_name, a.attr_name, a.attr_type_name, a.length
           FROM dba_type_attrs a JOIN dba_types t ON t.owner = a.owner AND t.type_name = a.type_name
          WHERE a.owner = :o AND t.typecode = 'OBJECT' AND a.attr_type_name IN ('VARCHAR2', 'NVARCHAR2', 'VARCHAR', 'CHAR', 'NCHAR') AND a.length > 0`,
        { o: this.state.schema })).rows;
    } catch (err) {
      this.log.error(`Object type lengths: ${err.message}`);
      return;
    } finally {
      await conn.close().catch(() => {});
    }
    if (!attrs.length) return;
    const pg = new Map((await pgClient.pgQuery(
      `SELECT t.typname, a.attname, a.atttypmod - 4 AS len
         FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace JOIN pg_attribute a ON a.attrelid = t.typrelid
        WHERE n.nspname = $1 AND t.typtype = 'c' AND a.attnum > 0 AND a.atttypmod > 4`,
      [this.pgSchema], this.projectName)).rows.map((r) => [`${r.typname}.${r.attname}`, Number(r.len)]));
    const wrong = attrs.filter(([type, attr, , len]) => {
      const key = `${this.pgName(type)}.${this.pgName(attr)}`;
      return pg.has(key) && pg.get(key) < Number(len);
    });
    for (const type of [...new Set(wrong.map((w) => w[0]))]) {
      const pgType = `${qi(this.pgSchema)}.${qi(this.pgName(type))}`;
      // PostgreSQL cannot alter a composite type that a table column uses (resumed runs): those
      // columns go to text and back around the change, keeping their data.
      const users = (await pgClient.pgQuery(
        `SELECT n.nspname, c.relname, a.attname FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE a.atttypid = $1::regtype AND c.relkind IN ('r', 'p') AND NOT a.attisdropped`, [pgType], this.projectName)).rows;
      const statements = [
        ...users.map((u) => `ALTER TABLE ${qi(u.nspname)}.${qi(u.relname)} ALTER COLUMN ${qi(u.attname)} TYPE text USING ${qi(u.attname)}::text`),
        ...wrong.filter((w) => w[0] === type).map(([, attr, , len]) => `ALTER TYPE ${pgType} ALTER ATTRIBUTE ${qi(this.pgName(attr))} TYPE varchar(${Number(len)})`),
        ...users.map((u) => `ALTER TABLE ${qi(u.nspname)}.${qi(u.relname)} ALTER COLUMN ${qi(u.attname)} TYPE ${pgType} USING ${qi(u.attname)}::${pgType}`),
      ];
      const client = await pgClient.getPostgresConnection(this.projectName);
      try {
        await client.query('BEGIN');
        for (const sql of statements) await client.query(sql);
        await client.query('COMMIT');
        statements.forEach((sql) => out.write(`${sql};\n`));
        this.log.info(`Fixed attribute lengths of ${type} (ora2pg exported them too short)`);
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        this.log.error(`Fixing attribute lengths of ${type}: ${err.message}`);
      } finally {
        client.release();
      }
    }
  }

  /**
   * A partitioned table with no partition that fits a row rejects it. Oracle INTERVAL partitioning
   * creates partitions on the fly; PostgreSQL does not, so every partitioned table gets a DEFAULT
   * partition: rows of periods that had no partition yet still load (split later with pg_partman).
   */
  async ensureDefaultPartitions(out) {
    const { rows } = await pgClient.pgQuery(
      `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = $1 AND c.relkind = 'p'
          AND NOT EXISTS (SELECT 1 FROM pg_inherits i JOIN pg_class d ON d.oid = i.inhrelid
                           WHERE i.inhparent = c.oid AND pg_get_expr(d.relpartbound, d.oid) = 'DEFAULT')`,
      [this.pgSchema], this.projectName);
    for (const { relname } of rows) {
      const sql = `CREATE TABLE IF NOT EXISTS ${qi(this.pgSchema)}.${qi(`${relname}_default`)} PARTITION OF ${qi(this.pgSchema)}.${qi(relname)} DEFAULT`;
      await pgClient.pgQuery(sql, [], this.projectName)
        .then(() => out.write(`${sql};\n`))
        .catch((err) => this.log.error(`Default partition for ${relname}: ${err.message}`));
    }
  }

  async phase_data() {
    const opts = this.state.options;
    const todo = Object.values(this.state.tables)
      .filter((t) => t.status !== 'done' && !(opts.loadMode === 'export' && t.status === 'exported') && !(t.status === 'failed' && /could not be created/.test(t.error || '')))
      .sort((a, b) => (b.sizeMb || 0) - (a.sizeMb || 0) || (b.estRows || 0) - (a.estRows || 0));

    const total = Object.keys(this.state.tables).length;
    // Auto-tune: up to the most readers allowed may be started, the gate lets the tuned number run.
    const tune = opts.autoTune === 'on' && todo.length > 0;
    this.tuneMax = tune ? readerRange(opts).max : 0;
    const limit = pLimit(Math.max(1, tune ? this.tuneMax : opts.parallelTables));
    const updateProgress = () => {
      const t = this.totals();
      this.updatePhase('data', {
        progress: Math.round(((t.done + (t.exported || 0) + t.failed) / Math.max(1, total)) * 100),
        detail: opts.loadMode === 'export'
          ? `${t.exported || 0} exported, ${t.running} exporting, ${t.failed} failed of ${total} tables`
          : `${t.done} done, ${t.running} loading, ${t.failed} failed of ${total} tables`,
      });
    };

    // "Where did the time go?": what Oracle, the network, ora2pg and PostgreSQL do while tables load.
    if (process.env.TIME_SAMPLING !== 'off') {
      this.sampler = samplerFor(this, oracleClient, pgClient);
      this.sampler.start();
    }
    if (tune) {
      this.tuner = new SpeedTuner({ run: this, gate: this.gate });
      this.tuner.start();
    }
    try {
      await Promise.all(todo.map((t) => limit(async () => {
        if (this.cancelRequested) return;
        await this.whenServerOk(`table ${t.name}`);
        if (this.cancelRequested) return;
        await this.loadTableWithRetry(t.name);
        updateProgress();
      })));
    } finally {
      if (this.sampler) this.sampler.stop();
      if (this.tuner) this.tuner.stop();
      this.tuner = null;
    }
    this.checkCancelled();
    updateProgress();
    const failed = this.totals().failed;
    if (failed) this.phase('data').warnings = failed;
  }

  async loadTableWithRetry(name) {
    const maxAttempts = this.state.options.maxAttempts;
    const t = this.state.tables[name];
    t.attempts = 0;
    if (t.udt === undefined && t.kind !== 'object') {
      // Columns of user-defined object types: ora2pg writes them in a format PostgreSQL misreads,
      // so these tables are loaded by the engine's own reader (loadObjectTable).
      const conn = await oracleClient.getOracleConnection(this.projectName);
      try {
        const r = await conn.execute(
          `SELECT COUNT(*) FROM dba_tab_columns WHERE owner = :o AND table_name = :t
              AND data_type_owner IS NOT NULL AND data_type_owner NOT IN ('SYS', 'PUBLIC', 'MDSYS')`, { o: this.state.schema, t: name });
        t.udt = Number(r.rows[0][0]) > 0;
      } catch (err) {
        t.udt = false;
        this.log.error(`Object type check for ${name}: ${err.message}`);
      } finally {
        await conn.close().catch(() => {});
      }
    }
    if (t.kind === 'lob' && t.lobPlan === undefined) {
      await this.planLobs(t).catch((err) => {
        t.lobPlan = null;
        this.log.error(`LOB plan for ${name} failed, using LOB locators: ${err.message}`);
      });
    }
    if (!t.udt && this.shouldChunk(t) && t.chunks === undefined) {
      await this.planChunks(t).catch((err) => {
        t.chunks = null;
        this.log.error(`Chunk plan for ${name} failed, loading it in one piece: ${err.message}`);
      });
    }
    while (t.attempts < maxAttempts) {
      this.checkCancelled();
      t.attempts += 1;
      const chunked = Array.isArray(t.chunks) && t.chunks.length > 0;
      this.updateTable(name, { status: 'running', startedAt: t.startedAt && chunked ? t.startedAt : nowIso(), finishedAt: null, rowsDone: chunked ? t.rowsDone : 0, rate: 0, error: null }, true);
      this.event('info', `Loading table ${name}${t.attempts > 1 ? ` (attempt ${t.attempts})` : ''}`, { type: 'table', name, state: 'start' });
      try {
        if (chunked) await this.loadChunked(t);
        else await this.loadTable(t);
        const exported = this.state.options.loadMode === 'export';
        if (!exported) await this.bulkFinish(t);
        this.updateTable(name, { status: exported ? 'exported' : 'done', finishedAt: nowIso(), rate: 0, error: null }, true);
        this.event('info', `Table ${name} ${exported ? 'exported' : 'loaded'}: ${(exported ? t.rowsDone : (t.pgRows ?? t.rowsDone)).toLocaleString()} rows${t.attempts > 1 ? ` (attempt ${t.attempts})` : ''}`, { type: 'table', name, state: 'done' });
        return;
      } catch (err) {
        if (err instanceof CancelledError || this.cancelRequested) throw new CancelledError();
        // A data checksum difference is a mapping problem (e.g. decimals into an integer column): reloading won't fix it.
        if (/ORA-01555|ORA-08180|ORA-08181|snapshot too old/i.test(err.message) && this.state.snapshot && this.state.snapshot.mode === 'scn') {
          // Retrying reads the same SCN, which Oracle's undo no longer reaches: say what to do instead.
          err.message = `Oracle's undo no longer reaches the run's snapshot (SCN ${this.state.snapshot.scn}): ${firstError(err.message)}. `
            + 'Resume with "Consistent snapshot" off (keep the application stopped), or raise UNDO_RETENTION and start a new run.';
          err.noRetry = true;
        }
        const last = t.attempts >= maxAttempts || !!err.noRetry;
        if (last) {
          await this.emptyFailedTable(t);
          if (this.state.options.loadMode !== 'export') err.message += err.typeMapping ? ' The table was emptied, so it is never left half loaded.' : ' The table was emptied, so it is never left half loaded: Resume loads it again.';
        }
        this.updateTable(name, { status: last ? 'failed' : 'running', error: err.message, failedParts: last ? err.failedParts || null : null, rate: 0, rowsDone: last && this.state.options.loadMode !== 'export' ? 0 : t.rowsDone, finishedAt: last ? nowIso() : null }, true);
        this.event('error', `Table ${name} attempt ${t.attempts}/${maxAttempts} failed: ${err.message}`, { type: 'table', name, state: 'failed' });
        if (last) this.notifier.attention(`• Table ${name} failed after ${t.attempts} attempt(s): ${firstError(err.message).slice(0, 300)}`);
        else if (isStalled(err)) this.notifier.attention(`• Table ${name}: hung load stopped (no progress for ${this.state.options.stallMinutes} min), retrying`);
        if (last) return;
        await sleep(Math.min(60000, 10000 * t.attempts));
      }
    }
  }

  /** Empties the target table so a (re)load never duplicates rows. */
  async prepareTarget(name) {
    await this.dropReferencingFks(name);
    // Without ONLY: PostgreSQL refuses TRUNCATE ONLY on a partitioned table, and its partitions must be emptied too.
    await pgClient.pgQuery(`TRUNCATE TABLE ${qi(this.pgSchema)}.${qi(this.pgName(name))}`, [], this.projectName);
    await this.bulkPrepare(this.state.tables[name]);
  }

  /** The table and, for a partitioned table, its partitions (leaf tables hold the data). */
  async pgRelations(name) {
    const { rows } = await pgClient.pgQuery(
      `WITH RECURSIVE r AS (
         SELECT c.oid, c.relname, c.relkind, c.relpersistence, false AS part
           FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2
         UNION ALL
         SELECT c.oid, c.relname, c.relkind, c.relpersistence, true FROM pg_inherits i JOIN r ON i.inhparent = r.oid JOIN pg_class c ON c.oid = i.inhrelid)
       SELECT relname, relkind, relpersistence, part FROM r`,
      [this.pgSchema, this.pgName(name)],
      this.projectName,
    );
    return rows;
  }

  /**
   * Bulk-load mode, on the empty table: autovacuum is switched off while the table is loaded (it
   * would scan the table again and again during a long load), and with "Unlogged load" a plain
   * table is made UNLOGGED: its rows are written without WAL. bulkFinish() undoes both once the
   * table is verified. An unlogged table is emptied by a PostgreSQL crash: the row count check
   * then fails and the table is reloaded, so a table is only marked done once it is permanent.
   */
  async bulkPrepare(t) {
    if (!t || this.state.options.loadMode === 'export') return;
    const sch = qi(this.pgSchema);
    const rels = await this.pgRelations(t.name).catch(() => []);
    for (const r of rels.filter((x) => x.relkind === 'r')) {
      await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} SET (autovacuum_enabled = false, toast.autovacuum_enabled = false)`, [], this.projectName)
        .catch(() => pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} SET (autovacuum_enabled = false)`, [], this.projectName).catch(() => {}));
    }
    t.autovacuumOff = true;
    const plain = rels.length === 1 && rels[0].relkind === 'r';
    if (this.state.options.bulkLoad === 'unlogged' && plain) {
      try {
        await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(this.pgName(t.name))} SET UNLOGGED`, [], this.projectName);
        t.unlogged = true;
      } catch (err) {
        this.log.info(`${t.name}: loaded as a normal table (${err.message.split('\n')[0]})`);
      }
    } else if (this.state.options.bulkLoad === 'unlogged' && !plain) {
      this.log.info(`${t.name}: partitioned, loaded as a normal table`);
    }
    this.save(true);
  }

  /** After a verified load: the table becomes permanent again (SET LOGGED writes it to WAL once) and autovacuum is back on. */
  async bulkFinish(t) {
    const sch = qi(this.pgSchema);
    if (!(await this.pgRelations(t.name).catch(() => [])).length) {
      // The table is not in PostgreSQL (dropped, or never created): nothing to switch back.
      Object.assign(t, { unlogged: false, autovacuumOff: false });
      return;
    }
    if (t.unlogged) {
      this.updateTable(t.name, { rate: 0 });
      this.event('info', `Making ${t.name} permanent (writes it to the WAL once)`);
      const started = Date.now();
      await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(this.pgName(t.name))} SET LOGGED`, [], this.projectName);
      t.unlogged = false;
      this.log.info(`${t.name}: SET LOGGED in ${Math.round((Date.now() - started) / 1000)}s`);
    }
    if (t.autovacuumOff) {
      const rels = await this.pgRelations(t.name).catch(() => []);
      for (const r of rels.filter((x) => x.relkind === 'r')) {
        await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} RESET (autovacuum_enabled, toast.autovacuum_enabled)`, [], this.projectName)
          .catch(() => pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} RESET (autovacuum_enabled)`, [], this.projectName).catch(() => {}));
      }
      t.autovacuumOff = false;
    }
    this.save(true);
  }

  async dropReferencingFks(name) {
    const pgName = this.pgName(name);
    // Foreign keys pointing at this table would block TRUNCATE; they are dropped here and
    // re-created by the foreign key phase.
    const { rows } = await pgClient.pgQuery(
      `SELECT con.conname, cn.nspname AS sch, cl.relname AS tbl
         FROM pg_constraint con
         JOIN pg_class cl ON cl.oid = con.conrelid
         JOIN pg_namespace cn ON cn.oid = cl.relnamespace
        WHERE con.contype = 'f'
          -- On a partitioned table only the parent's key: its partitions' copies go with it (dropping one alone is refused).
          AND con.conparentid = 0
          AND con.confrelid = (SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2)`,
      [this.pgSchema, pgName],
      this.projectName,
    );
    for (const fk of rows) {
      await pgClient.pgQuery(`ALTER TABLE ${qi(fk.sch)}.${qi(fk.tbl)} DROP CONSTRAINT IF EXISTS ${qi(fk.conname)}`, [], this.projectName);
      this.log.info(`Dropped FK ${fk.conname} on ${fk.tbl} to reload ${name} (re-created in the foreign key phase)`);
      this.phase('fkeys').status = 'pending';
    }
  }

  async loadTable(t) {
    const opts = this.state.options;
    if (opts.loadMode === 'export') return this.exportTable(t);
    await this.prepareTarget(t.name);
    this.checkCancelled();

    const out = this.log.tableLog(t.name);
    out.write(`\n===== ${nowIso()} attempt ${t.attempts} =====\n`);
    try {
      if (t.kind === 'object' || t.udt) {
        await this.loadObjectTable(t, out);
      } else {
        await this.copyTable(t, { out, huge: t.kind === 'huge', onRows: (rows, rate) => this.updateTable(t.name, { rowsDone: rows, rate }) });
      }
    } finally {
      out.end();
    }
    await this.verifyTable(t);
    await this.verifyData(t);
  }

  /** Export-only run: the table goes to a file, checked against Oracle's count, and stays there for the import. */
  async exportTable(t) {
    if (t.kind === 'object' || t.udt) {
      this.log.info(`${t.name}: has object types, read directly from Oracle when the files are imported`);
      return;
    }
    const out = this.log.tableLog(t.name);
    out.write(`\n===== ${nowIso()} export attempt ${t.attempts} =====\n`);
    try {
      const rows = await this.copyTable(t, { out, huge: t.kind === 'huge', onRows: (r, rate) => this.updateTable(t.name, { rowsDone: r, rate }) });
      const expected = await this.oracleCount(t);
      if (rows !== expected) {
        await this.dropExport(t);
        throw new Error(`export has ${rows} rows, Oracle has ${expected}: exported again on the next attempt`);
      }
      this.updateTable(t.name, { rowsDone: rows, oracleRows: expected });
    } finally {
      out.end();
    }
  }

  dataFile(t, fileTag) {
    return path.join(this.dir, 'data', `${t.name}${fileTag ? `_${fileTag}` : ''}_data.sql`);
  }

  async dropExport(t, fileTag) {
    const f = this.dataFile(t, fileTag);
    await fsp.unlink(f).catch(() => {});
    await fsp.unlink(`${f}.done.json`).catch(() => {});
  }

  /** Exact Oracle row count (of a WHERE range), at the run's snapshot. */
  async oracleCount(t, where) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ COUNT(*) FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t${where ? ` WHERE ${where}` : ''}`);
      return Number(r.rows[0][0]);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /**
   * Runs ora2pg -t COPY for one table (or one PK range of it with `where`). In file mode the data
   * file is loaded with psql and deleted. Returns the number of rows ora2pg reported.
   * Takes one reader of the gate (a big table read with -J takes that many) while it runs.
   */
  async copyTable(t, args) {
    const g = this.gate;
    // A big table read with several Oracle readers (-J) asks for "parts at a time" readers but takes
    // the ones free at its turn (flex): it never makes the loads queued behind it wait for all of them.
    const weight = args.huge ? this.state.options.oracleCopies : 1;
    const flex = !!args.huge;
    const queued = g.wouldWait(weight, { flex });
    // Forced: the "waiting" flag comes right after the table's start and must not be dropped by the once-a-second limit.
    if (queued && !args.where) this.updateTable(t.name, { waiting: true }, true);
    const release = await g.acquire(weight, { flex });
    // Its time starts when it really starts reading.
    if (queued && !args.where) this.updateTable(t.name, { waiting: false, startedAt: nowIso() }, true);
    if (args.onStart) args.onStart();
    try {
      this.checkCancelled();
      return await this.copyTableNow(t, { ...args, readers: Number.isFinite(release.granted) ? release.granted : weight });
    } finally {
      release();
    }
  }

  async copyTableNow(t, { out, huge, where, fileTag, onRows, viaFile, readers }) {
    const opts = this.state.options;
    // Through a file: file / export runs, and ROWID chunks (whose load must be all-or-nothing, see loadChunked).
    const useFile = opts.loadMode !== 'direct' || !!viaFile;
    const conf = t.lobPlan && t.lobPlan.inline ? await this.inlineLobConf(useFile ? this.fileConf : this.dataConf, t.lobPlan) : (useFile ? this.fileConf : this.dataConf);
    const args = ['-t', 'COPY', '-c', conf, '-a', t.name.replace(/\$/g, '\\$'), ...this.snapshotArgs()];
    if (huge) args.push('-J', String(readers || opts.oracleCopies), '-j', String(Math.min(opts.pgJobs, readers || opts.pgJobs)));
    if (where) args.push('-W', where);
    if (t.kind === 'lob') args.push('-L', String(t.lobPlan && t.lobPlan.inline ? t.lobPlan.batch : opts.blobLimit));
    const label = `${t.name}${fileTag ? ` ${fileTag}` : ''}`;

    let dataFile = null;
    let marker = null;
    let rows = null;
    if (useFile) {
      dataFile = this.dataFile(t, fileTag);
      marker = `${dataFile}.done.json`;
      // A complete export of the same snapshot is re-imported instead of reading Oracle again.
      const m = await store.readJson(marker);
      if (m && m.snapshot === this.snapshotKey() && fs.existsSync(dataFile)) {
        rows = m.rows;
        if (out) out.write(`Re-using the export from ${m.at} (${rows} rows): Oracle is not read again\n`);
        this.log.info(`${label}: re-importing existing export (${rows} rows)`);
        if (onRows) onRows(rows, 0);
      } else {
        await this.dropExport(t, fileTag);
        args.push('-b', path.dirname(dataFile), '-o', path.basename(dataFile));
      }
    }

    if (rows === null) {
      let lastRows = 0;
      const res = await this.ora2pg(args, `${useFile ? 'Export' : 'Load'} ${label}`, {
        out,
        idleTimeoutMs: opts.stallMinutes ? opts.stallMinutes * 60000 : 0,
        onLine: (line) => {
          // Single reader:  [=====>   ] 120000/500000 rows (24.0%) Table EMPLOYEES (10000 recs/sec)
          // Parallel (-J):  [=>       ] 150000/2500000 total rows (6.0%) - (6 sec., avg: 25000 recs/sec), ORDERS in progress.
          const m = line.match(/(\d+)\/(\d+)\s+rows\s+\([\d.]+%\)\s+Table\s+(\S+).*?(\d+)\s+recs\/sec/)
            || line.match(/(\d+)\/(\d+)\s+total rows.*?avg:\s+(\d+)\s+recs\/sec\),\s+(\S+)\s+in progress/);
          if (!m) return;
          const isTotal = m[0].includes('total rows');
          const tableName = isTotal ? m[4] : m[3];
          if (tableName.toUpperCase().startsWith(t.name.toUpperCase())) {
            lastRows = Math.max(lastRows, Number(m[1]));
            if (onRows) onRows(lastRows, Number(isTotal ? m[3] : m[4]));
          }
        },
      });
      this.checkCancelled();
      if (res.stalled) throw new Error(`No progress for ${opts.stallMinutes} min: stopped as hung (network?), retried`);
      if (res.code !== 0) throw new Error(firstError(res.errorTail) || `ora2pg exited with code ${res.code}`);
      if (res.errorTail) throw new Error(firstError(res.errorTail));
      rows = lastRows;
      if (dataFile) {
        if (!fs.existsSync(dataFile)) throw new Error('ora2pg produced no data file');
        await store.writeJsonAtomic(marker, { rows, snapshot: this.snapshotKey(), at: nowIso() });
      }
    }

    if (dataFile && opts.loadMode !== 'export') {
      // ora2pg wraps the file in one BEGIN ... COMMIT: a failed load leaves no rows behind, and the file
      // is kept so the retry only re-imports it.
      const load = await this.psqlFile(dataFile, `psql load ${label}`, { stopOnError: true, out });
      if (load.code !== 0) {
        const msg = firstError(load.errorTail) || 'psql load failed';
        // Bad values fail the same way every time: no retries, say what to fix. The file is kept either way.
        const dataError = /invalid input syntax|out of range|value too long|violates|invalid byte sequence|null value in column/i.test(msg);
        const err = new Error(dataError
          ? `${msg}. The data does not fit the target column: fix the mapping in Migration decisions and start a new run (it rebuilds the table with the new type).`
          : `${msg} (export kept: the retry re-imports it without reading Oracle again)`);
        err.noRetry = dataError;
        throw err;
      }
      await this.dropExport(t, fileTag);
    }
    return rows;
  }

  /**
   * Huge tables with a single-column numeric primary key are split into PK ranges of about
   * CHUNK_ROWS rows. Each chunk is its own ora2pg run (WHERE pk BETWEEN lo AND hi), several run at
   * once, and each one is verified against an Oracle count of its range. A failed chunk is
   * deleted and reloaded on its own: a network drop at 90% of a 300 GB table costs one chunk,
   * not the whole table. Shorter Oracle queries also avoid ORA-01555 (snapshot too old).
   */
  /**
   * LOB tables are the slowest part of a migration. With LOB locators (ora2pg's safe default) every
   * LOB costs extra round trips; measured on a CLOB table it is ~10x slower than fetching the LOBs
   * inline. Inline needs LONGREADLEN >= the largest LOB and reserves that much per row and LOB
   * column in each batch, so the largest LOB is measured first and the batch is sized to a memory
   * budget. Tables with LOBs over 16 MB, or LONG / XMLTYPE / BFILE columns, keep the locators.
   */
  async planLobs(t) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const cols = (await conn.execute(
        `SELECT column_name, data_type FROM dba_tab_columns WHERE owner = :o AND table_name = :t
            AND data_type IN ('BLOB', 'CLOB', 'NCLOB', 'LONG', 'LONG RAW', 'XMLTYPE', 'BFILE')`,
        { o: this.state.schema, t: t.name })).rows;
      if (!cols.length || cols.some(([, type]) => !['BLOB', 'CLOB', 'NCLOB'].includes(type))) { t.lobPlan = { inline: false }; return; }
      const r = await conn.execute(`SELECT ${cols.map(([c]) => `NVL(MAX(DBMS_LOB.GETLENGTH(${qi(c)})), 0)`).join(', ')} FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()}`);
      // CLOB lengths are in characters: up to 4 bytes each in UTF-8.
      const maxBytes = Math.max(1, ...cols.map(([, type], i) => Number(r.rows[0][i]) * (type === 'BLOB' ? 1 : 4)));
      const limit = 16 * 1024 * 1024;
      if (maxBytes > limit) { t.lobPlan = { inline: false, maxBytes }; return; }
      let longReadLen = 65536;
      while (longReadLen < maxBytes) longReadLen *= 2;
      const budget = CONSTANTS.LOB_MEMORY_MB * 1024 * 1024;
      const batch = Math.max(1, Math.min(this.state.options.dataLimit, Math.floor(budget / (longReadLen * cols.length))));
      t.lobPlan = { inline: true, maxBytes, longReadLen, batch };
      this.event('info', `${t.name}: LOBs up to ${(maxBytes / 1048576).toFixed(1)} MB, fetched inline in batches of ${batch} rows`);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /** A copy of a data config that fetches LOBs inline (one per LONGREADLEN size). */
  async inlineLobConf(base, plan) {
    const file = base.replace(/\.conf$/, `_lob${plan.longReadLen}.conf`);
    if (!fs.existsSync(file)) {
      const c = (await fsp.readFile(base, 'utf8'))
        .replace(/^\s*(USE_LOB_LOCATOR|NO_LOB_LOCATOR|LONGREADLEN)\s.*$/gm, '')
        .concat(`\nUSE_LOB_LOCATOR\t0\nLONGREADLEN\t${plan.longReadLen}\n`);
      await fsp.writeFile(file, c, { mode: 0o600 });
    }
    return file;
  }

  /** Big by rows or by size (LOB tables are big in GB with few rows): loaded in chunks. */
  shouldChunk(t) {
    const o = this.state.options;
    return o.chunkRows > 0 && t.kind !== 'object' && ((t.estRows || 0) >= o.hugeTableRows || (t.sizeMb || 0) >= o.chunkMb);
  }

  /**
   * Splits a big table into chunks of about chunkRows rows / chunkMb MB:
   *  - single numeric primary key: key ranges (first/last open-ended);
   *  - anything else (GUID key, no key, LOB tables): ROWID ranges built from the table's extents,
   *    so every table can be split, even one without any key.
   */
  async planChunks(t) {
    const o = this.state.options;
    const n = Math.max(Math.ceil((t.estRows || 0) / o.chunkRows), Math.ceil((t.sizeMb || 0) / o.chunkMb));
    if (n < 2) { t.chunks = null; return; }
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const pk = await conn.execute(
        `SELECT cc.column_name, tc.data_type
           FROM dba_constraints c
           JOIN dba_cons_columns cc ON cc.owner = c.owner AND cc.constraint_name = c.constraint_name
           JOIN dba_tab_columns tc ON tc.owner = cc.owner AND tc.table_name = cc.table_name AND tc.column_name = cc.column_name
          WHERE c.owner = :o AND c.table_name = :t AND c.constraint_type = 'P'`,
        { o: this.state.schema, t: t.name },
      );
      if (pk.rows.length === 1 && ['NUMBER', 'INTEGER', 'FLOAT'].includes(pk.rows[0][1])) {
        const col = pk.rows[0][0];
        const mm = await conn.execute(`SELECT MIN(${qi(col)}), MAX(${qi(col)}) FROM ${qi(this.state.schema)}.${qi(t.name)}`);
        const [min, max] = mm.rows[0].map(Number);
        if (Number.isFinite(min) && Number.isFinite(max)) {
          const width = Math.ceil((max - min + 1) / n);
          t.chunkKind = 'pk';
          t.chunkKey = col;
          t.chunks = [];
          for (let lo = Math.floor(min), i = 0; lo <= max; lo += width, i += 1) {
            t.chunks.push({ i, lo, hi: Math.min(lo + width - 1, Math.ceil(max)), status: 'pending', rows: 0, attempts: 0 });
          }
          // The first and last chunk are open-ended so rows outside MIN/MAX are never missed.
          t.chunks[0].open = 'low';
          t.chunks[t.chunks.length - 1].open = t.chunks.length === 1 ? 'both' : 'high';
          this.event('info', `${t.name}: ${t.chunks.length} chunks on ${col}`);
          this.save(true);
          return;
        }
      }
      // ROWID ranges: extents in ROWID order (object, file, block), grouped into n chunks of ~equal blocks.
      const ext = await conn.execute(
        `SELECT ROWIDTOCHAR(DBMS_ROWID.ROWID_CREATE(1, o.data_object_id, e.relative_fno, e.block_id, 0)),
                ROWIDTOCHAR(DBMS_ROWID.ROWID_CREATE(1, o.data_object_id, e.relative_fno, e.block_id + e.blocks - 1, 32767)),
                e.blocks
           FROM dba_extents e
           JOIN dba_objects o ON o.owner = e.owner AND o.object_name = e.segment_name
                             AND NVL(o.subobject_name, '#') = NVL(e.partition_name, '#') AND o.object_type LIKE 'TABLE%'
          WHERE e.owner = :o AND e.segment_name = :t AND e.segment_type LIKE 'TABLE%'
          ORDER BY o.data_object_id, e.relative_fno, e.block_id`,
        { o: this.state.schema, t: t.name },
      );
      if (ext.rows.length < 2) { t.chunks = null; return; }
      const total = ext.rows.reduce((sum, r) => sum + Number(r[2]), 0);
      const per = total / Math.min(n, ext.rows.length);
      const chunks = [];
      let cur = null;
      let acc = 0;
      for (const [lo, hi, blocks] of ext.rows) {
        if (!cur) cur = { i: chunks.length, lo, hi, blocks: 0, status: 'pending', rows: 0, attempts: 0 };
        cur.hi = hi;
        cur.blocks += Number(blocks);
        acc += Number(blocks);
        if (acc >= per * (chunks.length + 1) - 1e-9) { chunks.push(cur); cur = null; }
      }
      if (cur) chunks.push(cur);
      t.chunkKind = 'rowid';
      t.chunkKey = 'ROWID';
      t.chunks = chunks;
      this.event('info', `${t.name}: ${chunks.length} ROWID-range chunks (no single numeric key)`);
      this.save(true);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /** A part's rows in words, e.g. "ORDER_ID 5000001 to 10000000", for messages people read. */
  partRange(t, c) {
    if (t.chunkKind === 'rowid') return `${Number(c.blocks || 0).toLocaleString()} Oracle blocks by ROWID`;
    if (c.open === 'both') return 'all rows';
    if (c.open === 'low') return `${t.chunkKey} up to ${c.hi}`;
    if (c.open === 'high') return `${t.chunkKey} from ${c.lo}`;
    return `${t.chunkKey} ${c.lo} to ${c.hi}`;
  }

  /**
   * A table that finally failed is emptied: PostgreSQL never keeps half a table, and a chunked
   * table's parts all start again on Resume (the error names the parts that failed).
   */
  async emptyFailedTable(t) {
    if (this.state.options.loadMode === 'export') return;
    try {
      await pgClient.pgQuery(`TRUNCATE TABLE ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName);
    } catch (err) {
      this.log.error(`${t.name}: could not empty the failed table: ${err.message}`);
      return;
    }
    if (Array.isArray(t.chunks)) t.chunks.forEach((c) => Object.assign(c, { status: 'pending', dirty: false, rows: 0, rate: 0 }));
    t.rowsDone = 0;
    this.log.info(`${t.name}: emptied after the failure, so it is never left half loaded`);
  }

  /** WHERE clause of a chunk (quote = Oracle or PostgreSQL identifier quoting). */
  chunkWhere(t, c, quote) {
    if (t.chunkKind === 'rowid') return `ROWID BETWEEN CHARTOROWID('${c.lo}') AND CHARTOROWID('${c.hi}')`;
    const col = quote(t.chunkKey);
    if (c.open === 'both') return '1=1';
    if (c.open === 'low') return `${col} <= ${c.hi}`;
    if (c.open === 'high') return `${col} >= ${c.lo}`;
    return `${col} >= ${c.lo} AND ${col} <= ${c.hi}`;
  }

  updateChunkInfo(t) {
    const info = { total: t.chunks.length, done: 0, running: 0, queued: 0, failed: 0 };
    let rows = 0;
    let rate = 0;
    for (const c of t.chunks) {
      if (c.status === 'done' || c.status === 'exported') info.done += 1;
      if (c.status === 'running') { info.running += 1; rate += c.rate || 0; }
      if (c.status === 'queued') info.queued += 1;
      if (c.status === 'failed') info.failed += 1;
      rows += c.rows || 0;
    }
    // A part starting, waiting or ending is sent at once; row progress at most once a second.
    const prev = t.chunkInfo || {};
    const changed = ['done', 'running', 'queued', 'failed'].some((k) => prev[k] !== info[k]);
    this.updateTable(t.name, { chunkInfo: info, rowsDone: rows, rate }, changed);
  }

  async loadChunked(t) {
    const opts = this.state.options;
    const pgCol = (c) => qi(this.pgName(c));
    const exportOnly = opts.loadMode === 'export';
    const finished = exportOnly ? 'exported' : 'done';
    const rowid = t.chunkKind === 'rowid';
    if (!exportOnly) {
      if (!t.chunks.some((c) => c.status === 'done')) await this.prepareTarget(t.name);
      else await this.dropReferencingFks(t.name);
    }
    this.checkCancelled();

    const out = this.log.tableLog(t.name);
    out.write(`\n===== ${nowIso()} attempt ${t.attempts} (chunked on ${t.chunkKey}) =====\n`);
    const limit = pLimit(Math.max(1, this.tuneMax || opts.oracleCopies));
    try {
      await Promise.all(t.chunks.filter((c) => c.status !== finished).map((c) => limit(async () => {
        if (this.cancelRequested) return;
        await this.whenServerOk(`the next part of ${t.name}`);
        if (this.cancelRequested) return;
        c.attempts += 1;
        // A key-range chunk that was started before (crash, failure) is deleted first: never duplicated.
        // ROWID chunks need no delete: each one is loaded from a file in a single transaction.
        if (c.dirty && !rowid && !exportOnly) {
          await pgClient.pgQuery(`DELETE FROM ${qi(this.pgSchema)}.${qi(this.pgName(t.name))} WHERE ${this.chunkWhere(t, c, pgCol)}`, [], this.projectName);
        }
        // 'queued' until a reader is free (auto-tune), then 'running'.
        Object.assign(c, { status: 'queued', dirty: true, rows: 0, rate: 0, error: null });
        this.save(true);
        this.updateChunkInfo(t);
        try {
          const rows = await this.copyTable(t, {
            onStart: () => { c.status = 'running'; this.updateChunkInfo(t); },
            out,
            where: this.chunkWhere(t, c, qi),
            fileTag: `c${c.i}`,
            viaFile: rowid,
            onRows: (r, rate) => { c.rows = r; c.rate = rate; this.updateChunkInfo(t); },
          });
          const expected = await this.oracleCount(t, this.chunkWhere(t, c, qi));
          if (rows !== expected) {
            if (exportOnly) await this.dropExport(t, `c${c.i}`);
            throw new Error(`chunk ${c.i}: ora2pg ${exportOnly ? 'exported' : 'loaded'} ${rows} rows, Oracle has ${expected}`);
          }
          Object.assign(c, { status: finished, rows, rate: 0, dirty: false });
        } catch (err) {
          if (this.cancelRequested) { c.status = 'pending'; return; }
          Object.assign(c, { status: 'failed', rate: 0, error: err.message });
          this.log.error(`${t.name} chunk ${c.i} (${c.lo}..${c.hi}) failed: ${err.message}`);
        } finally {
          this.save(true);
          this.updateChunkInfo(t);
        }
      })));
    } finally {
      out.end();
    }
    this.checkCancelled();
    const failed = t.chunks.filter((c) => c.status !== finished);
    if (failed.length) {
      failed.forEach((c) => { if (c.status === 'failed') c.status = 'pending'; });
      const err = new Error(`Part${failed.length === 1 ? '' : 's'} ${failed.slice(0, 5).map((c) => c.i + 1).join(', ')}${failed.length > 5 ? ', …' : ''} of ${t.chunks.length} failed (${this.partRange(t, failed[0])}): ${failed[0].error || 'see table log'}`);
      err.failedParts = failed.map((c) => ({ part: c.i + 1, of: t.chunks.length, rows: this.partRange(t, c), error: c.error || null }));
      throw err;
    }
    if (exportOnly) return;
    try {
      await this.verifyTable(t);
    } catch (err) {
      // Should not happen (every chunk was verified); reload everything on the next attempt.
      t.chunks.forEach((c) => Object.assign(c, { status: 'pending', dirty: false, rows: 0 }));
      throw err;
    }
    await this.verifyData(t);
  }

  /**
   * Tables ora2pg cannot copy correctly, read by the engine itself and loaded with \copy:
   *  - Oracle object tables (kind 'object'): each row goes into the TEXT-column fallback table;
   *  - tables with columns of user-defined object types (t.udt): object values are written as
   *    PostgreSQL composite literals "(street,city,…)", collections as arrays "{…}".
   * DATE / TIMESTAMP values are written as the wall-clock time Oracle holds (no timezone shift).
   */
  async loadObjectTable(t, out) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    const csv = path.join(this.dir, 'data', `${t.name}.csv`);
    const cell = (v, type) => {
      const text = pgLiteral(v, type);
      return text === null ? '' : `"${text.replace(/"/g, '""')}"`;
    };
    try {
      let select = '*';
      let pgCols = null;
      let target = `${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`;
      if (t.kind !== 'object') {
        // Explicit columns, in order, without calculated (virtual) columns: they are generated columns in
        // PostgreSQL. Oracle also marks nested table columns virtual (the list is stored in another
        // table): those are read like any column.
        const cols = (await conn.execute(
          `SELECT column_name FROM dba_tab_cols WHERE owner = :o AND table_name = :t AND hidden_column = 'NO'
              AND (virtual_column = 'NO' OR (data_type_owner IS NOT NULL AND data_type_owner NOT IN ('SYS', 'PUBLIC', 'MDSYS')))
            ORDER BY column_id`,
          { o: this.state.schema, t: t.name })).rows.map((r) => r[0]);
        const renames = new Map((this.columnRenames || []).filter((r) => r.tableName === t.name).map((r) => [r.oldName, r.name]));
        select = cols.map((c) => qi(c)).join(', ');
        pgCols = cols.map((c) => renames.get(c) || this.pgName(c));
        target += ` (${pgCols.map((c) => qi(c)).join(', ')})`;
      }
      // The PostgreSQL type of every column, so each value is written exactly as that type reads it
      // (composite "(a,b)", array "{a,b}", a list wrapped in ora2pg's one-field type "("{a,b}")").
      const types = await pgColumnTypes(this.projectName, this.pgSchema, this.pgName(t.name));
      const r = await conn.execute(`SELECT ${select} FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()}`, [], { resultSet: true, outFormat: oracledb.OUT_FORMAT_ARRAY });
      const colTypes = pgCols ? pgCols.map((c) => (types.find((x) => x.name === c) || {}).type) : types.map((x) => x.type);
      const ws = fs.createWriteStream(csv);
      let rows = 0;
      let batch;
      while ((batch = await r.resultSet.getRows(5000)).length) {
        this.checkCancelled();
        const chunk = batch.map((row) => row.map((v, i) => cell(v, colTypes[i])).join(',')).join('\n') + '\n';
        if (!ws.write(chunk)) await new Promise((res) => ws.once('drain', res));
        rows += batch.length;
        this.updateTable(t.name, { rowsDone: rows });
      }
      await r.resultSet.close();
      await new Promise((res) => ws.end(res));
      const res = await executeAndLog({
        cmd: CONSTANTS.PSQL_BIN,
        args: this.psqlArgs(['-v', 'ON_ERROR_STOP=1', '-c', `\\copy ${target} FROM '${csv.replace(/'/g, "''")}' WITH (FORMAT csv)`]),
        env: this.psqlEnv(),
        log: this.log,
        out,
        children: this.children,
        label: `Copy ${t.kind === 'object' ? 'object table' : 'table with object types'} ${t.name}`,
      });
      if (res.code !== 0) throw new Error(firstError(res.errorTail) || 'psql \\copy failed');
    } finally {
      await conn.close().catch(() => {});
      await fsp.unlink(csv).catch(() => {});
    }
  }

  /** Compares the exact row count in Oracle and PostgreSQL. */
  async verifyTable(t) {
    const { rows } = await pgClient.pgQuery(`SELECT count(*)::bigint AS n FROM ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName);
    const pgRows = Number(rows[0].n);
    t.pgRows = pgRows;
    t.rowsDone = Math.max(t.rowsDone || 0, pgRows);
    if (!this.state.options.verifyRowCounts) return;

    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ COUNT(*) FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t`);
      t.oracleRows = Number(r.rows[0][0]);
    } finally {
      await conn.close().catch(() => {});
    }
    this.updateTable(t.name, { pgRows, oracleRows: t.oracleRows });
    if (t.oracleRows !== pgRows) {
      throw new Error(`Row count mismatch: Oracle ${t.oracleRows.toLocaleString()}, PostgreSQL ${pgRows.toLocaleString()}`);
    }
  }

  /**
   * Column checksums after the row count: per column, Oracle and PostgreSQL must agree on
   *   numbers:  SUM(column)                     (catches decimals cut by an integer mapping, booleans that were not 0/1)
   *   strings:  SUM(LENGTH(column))             (catches truncation, stripped or broken characters)
   *   LOBs:     SUM(DBMS_LOB.GETLENGTH(column)) (catches cut or empty LOBs)
   * Both sides read the same snapshot. CHAR (padding), dates (time zones) and floats are not compared.
   * Calculated (virtual) columns are compared too: PostgreSQL calculates them again with its own
   * types, so a NUMBER mapped to an integer type would round them.
   * A difference is a mapping problem, not a transient error: the table is failed without reloading.
   */
  async verifyData(t) {
    // A TEXT copy of an object table (no usable type) has nothing comparable.
    if (this.state.options.verifyData === 'off' || (t.kind === 'object' && t.textFallback !== false)) return;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    let oraCols;
    try {
      oraCols = (await conn.execute(
        `SELECT column_name, data_type FROM dba_tab_cols
          WHERE owner = :o AND table_name = :t AND hidden_column = 'NO'
            AND data_type IN ('NUMBER', 'VARCHAR2', 'NVARCHAR2', 'CLOB', 'NCLOB', 'BLOB')
          ORDER BY column_id`, { o: this.state.schema, t: t.name })).rows;
      const pgTypes = new Map((await pgClient.pgQuery(
        `SELECT a.attname, format_type(a.atttypid, a.atttypmod) AS typ
           FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relname = $2 AND a.attnum > 0 AND NOT a.attisdropped`,
        [this.pgSchema, this.pgName(t.name)], this.projectName)).rows.map((r) => [r.attname, r.typ]));
      const renames = new Map((this.columnRenames || []).filter((r) => r.tableName === t.name).map((r) => [r.oldName, r.name]));
      const pairs = [];
      for (const [col, otype] of oraCols) {
        const pgCol = renames.get(col) || this.pgName(col);
        const typ = pgTypes.get(pgCol);
        if (!typ) continue;
        const ora = otype === 'NUMBER' ? `SUM(${qi(col)})` : /LOB$/.test(otype) ? `SUM(DBMS_LOB.GETLENGTH(${qi(col)}))` : `SUM(LENGTH(${qi(col)}))`;
        let pg;
        if (typ === 'boolean') pg = `sum(${qi(pgCol)}::int)`;
        else if (typ === 'bytea') pg = `sum(octet_length(${qi(pgCol)}))`;
        else if (/^(text|character varying)/.test(typ)) pg = otype === 'NUMBER' ? null : `sum(length(${qi(pgCol)}))`;
        else if (/^(numeric|bigint|integer|smallint)/.test(typ)) pg = `sum(${qi(pgCol)}::numeric)`;
        else if (/^(real|double precision)/.test(typ)) pg = `sum(${qi(pgCol)}::numeric)`;
        else pg = null;
        if (pg) pairs.push({ col, otype, pgCol, typ, ora, pg, float: /^(real|double)/.test(typ) });
      }
      // Columns of object types and collections: how many rows have a value, and for nested tables
      // how many list items in total (a list that arrived empty or NULL is caught here).
      const udt = (await conn.execute(
        `SELECT c.column_name, ct.coll_type FROM dba_tab_cols c
           LEFT JOIN dba_coll_types ct ON ct.owner = c.data_type_owner AND ct.type_name = c.data_type
          WHERE c.owner = :o AND c.table_name = :t AND c.hidden_column = 'NO'
            AND c.data_type_owner IS NOT NULL AND c.data_type_owner NOT IN ('SYS', 'PUBLIC', 'MDSYS')
          ORDER BY c.column_id`, { o: this.state.schema, t: t.name })).rows;
      if (udt.length) {
        const types = await pgColumnTypes(this.projectName, this.pgSchema, this.pgName(t.name));
        for (const [col, coll] of udt) {
          const pgCol = renames.get(col) || this.pgName(col);
          const pt = (types.find((x) => x.name === pgCol) || {}).type;
          if (!pt) continue;
          pairs.push({ col, otype: 'OBJECT', pgCol, typ: 'values filled in', ora: `SUM(CASE WHEN ${qi(col)} IS NULL THEN 0 ELSE 1 END)`, pg: `count(${qi(pgCol)})` });
          const list = pt.kind === 'array' ? qi(pgCol) : pt.kind === 'composite' && pt.wrapper ? `(${qi(pgCol)}).${qi(pt.attrs[0].name)}` : null;
          if (coll === 'TABLE' && list) pairs.push({ col, otype: 'OBJECT', pgCol, typ: 'list items', ora: `SUM(CARDINALITY(${qi(col)}))`, pg: `sum(cardinality(${list}))` });
        }
      }
      const diffs = [];
      for (let i = 0; i < pairs.length; i += 40) {
        const batch = pairs.slice(i, i + 40);
        const o = (await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ ${batch.map((p) => `TO_CHAR(${p.ora})`).join(', ')} FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t`)).rows[0];
        const g = (await pgClient.pgQuery(`SELECT ${batch.map((p, k) => `(${p.pg})::text AS c${k}`).join(', ')} FROM ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName)).rows[0];
        batch.forEach((p, k) => {
          const a = normDecimal(o[k]);
          const b = normDecimal(g[`c${k}`]);
          const same = p.float ? Math.abs(Number(a) - Number(b)) <= 1e-9 * Math.max(1, Math.abs(Number(a))) : a === b;
          if (!same) diffs.push({ column: p.col, oracle: a, postgres: b, type: p.typ });
        });
      }
      // PostgreSQL cannot store the NUL character (chr(0)) in text: it is removed on the way. A text
      // column whose only difference is the removed NUL characters is correct, and reported.
      const nul = [];
      for (const d of diffs.filter((x) => /CHAR|CLOB/.test(pairs.find((p) => p.col === x.column).otype))) {
        const lob = /LOB$/.test(pairs.find((p) => p.col === d.column).otype);
        const c = qi(d.column);
        const r = (await conn.execute(lob
          ? `SELECT TO_CHAR(SUM(DBMS_LOB.GETLENGTH(${c}) - DBMS_LOB.GETLENGTH(REPLACE(${c}, CHR(0))))), COUNT(CASE WHEN DBMS_LOB.INSTR(${c}, CHR(0)) > 0 THEN 1 END) FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t`
          : `SELECT TO_CHAR(SUM(LENGTH(${c}) - NVL(LENGTH(REPLACE(${c}, CHR(0))), 0))), COUNT(CASE WHEN INSTR(${c}, CHR(0)) > 0 THEN 1 END) FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t`)).rows[0];
        const chars = Number(r[0]) || 0;
        if (chars > 0 && Number(d.oracle) - chars === Number(d.postgres)) nul.push({ column: d.column, rows: Number(r[1]), chars });
      }
      if (nul.length) {
        diffs.splice(0, diffs.length, ...diffs.filter((d) => !nul.some((n) => n.column === d.column)));
        t.nulRemoved = nul;
        this.event('error', `${t.name}: ${nul.reduce((a, n) => a + n.rows, 0)} values contained the NUL character (chr(0)), which PostgreSQL cannot store; it was removed (${nul.map((n) => `${n.column}: ${n.rows} rows`).join(', ')}). All other characters are identical.`);
      }
      t.dataCheck = { columns: pairs.length, ok: diffs.length === 0, diffs: diffs.slice(0, 10), ...(nul.length ? { nulRemoved: nul } : {}) };
      this.updateTable(t.name, { dataCheck: t.dataCheck }, true);
      if (diffs.length) {
        const d = diffs[0];
        const objectCol = /^(values filled in|list items)$/.test(d.type);
        const err = new Error(objectCol
          ? `Data check failed on ${diffs.length} column(s), e.g. ${d.column} (${d.type}): Oracle ${d.oracle}, PostgreSQL ${d.postgres}. The values of this object or list column did not arrive completely; see the table log and report it to the DMA team.`
          : `Data check failed on ${diffs.length} column(s), e.g. ${d.column} (${d.type}): Oracle ${d.oracle}, PostgreSQL ${d.postgres}. The column type cannot hold these values: change the type mapping in Settings → Migration decisions, then start a new run of this table (it is rebuilt with the new types).`);
        err.noRetry = true;
        err.typeMapping = !objectCol;
        throw err;
      }
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /** DMA-075: waits while the server's CPU or memory is overloaded (services/resourceGuard.js). */
  whenServerOk(what) {
    return this.guard ? this.guard.whenOk(what) : Promise.resolve();
  }

  async runDdlPhase(key, files, { transform } = {}) {
    let warnings = 0;
    const failures = [];
    for (const [label, file] of files) {
      this.checkCancelled();
      this.updatePhase(key, { detail: label });
      const r = await runSqlFile({
        file,
        schema: this.pgSchema,
        parallel: this.state.options.ddlParallel,
        maintenanceWorkMem: this.state.options.maintenanceWorkMem,
        transform,
        log: this.log,
        label,
        shouldStop: () => this.cancelRequested,
        beforeEach: () => this.whenServerOk(label.toLowerCase()),
        onProgress: (d, total) => this.updatePhase(key, { detail: `${label}: ${d}/${total}`, progress: Math.round((d / total) * 100) }),
      });
      warnings += r.failed.length;
      failures.push(...r.failed.map((f) => ({ step: label, ...f })));
      if (r.total) this.event(r.failed.length ? 'error' : 'info', `${label}: ${r.ok} created, ${r.skipped} already present, ${r.failed.length} failed`);
    }
    this.checkCancelled();
    this.state.ddlFailures = [...(this.state.ddlFailures || []).filter((f) => !files.some(([l]) => l === f.step)), ...failures].slice(-500);
    this.phase(key).warnings = warnings || undefined;
  }

  async phase_indexes() {
    if (this.settings.lob.blobAs === 'oid') await this.convertBlobsToOid();
    const dir = path.join(this.schemaDir, 'tables');
    const idx = fs.existsSync(path.join(dir, 'modified_INDEXES_table.sql')) ? 'modified_INDEXES_table.sql' : 'INDEXES_table.sql';
    const skip = skipList(this.settings);
    // Oracle's internal unique index on a nested table column (its hidden SETID column) is written by
    // ora2pg as a unique index on the list itself: two rows with the same list would then fail.
    const internal = await this.nestedTableIndexes();
    let leftOut = 0;
    const transform = (stmt) => {
      const m = /^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:CONCURRENTLY\s+)?(?:IF\s+NOT\s+EXISTS\s+)?"?([^\s"(]+)"?/i.exec(stmt);
      if (m && internal.has(m[1].toLowerCase())) { leftOut += 1; return null; }
      return skipStatement(stmt, skip) ? null : stmt;
    };
    const obj = await this.objectTableDdl();
    await this.runDdlPhase('indexes', [
      ['Constraints (primary, unique, check)', path.join(dir, 'CONSTRAINTS_table.sql')],
      ['Indexes', path.join(dir, idx)],
      ...(obj.constraints ? [['Object tables: keys and constraints', obj.constraints]] : []),
      ...(obj.indexes ? [['Object tables: indexes', obj.indexes]] : []),
    ], { transform });
    if (leftOut) this.event('info', `${leftOut} Oracle-internal indexes of nested table columns left out (not needed in PostgreSQL)`);
  }

  /** Names (lower case) of the indexes Oracle keeps on nested table columns of the selected tables. */
  async nestedTableIndexes() {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(
        `SELECT ic.table_name, ic.index_name FROM dba_ind_columns ic
           JOIN dba_tab_cols c ON c.owner = ic.table_owner AND c.table_name = ic.table_name AND c.column_name = ic.column_name
           JOIN dba_coll_types ct ON ct.owner = c.data_type_owner AND ct.type_name = c.data_type
          WHERE ic.table_owner = :o AND ct.coll_type = 'TABLE'`, { o: this.state.schema });
      return new Set(r.rows.filter(([table]) => this.state.tables[table]).map(([, index]) => this.pgName(index).toLowerCase()));
    } catch (err) {
      this.log.error(`Nested table indexes could not be read: ${err.message}`);
      return new Set();
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /**
   * Keys, constraints, indexes and foreign keys of the Oracle object tables in this run, read from
   * Oracle's dictionary (ora2pg exports none of them for object tables). Written once per run into
   * schema/tables/OBJECT_*.sql; the indexes phase runs the constraints and indexes, the foreign key
   * phase the foreign keys (both with the usual skip list and failure report). Left out: Oracle's
   * internal ones on hidden columns (SYS_NC_OID$…), disabled constraints (reported), function-based
   * indexes (reported; they need converted expressions). NOT NULL checks become SET NOT NULL.
   * Foreign keys from normal tables TO an object table are in ora2pg's own file and now find the key.
   */
  async objectTableDdl() {
    if (this.objDdl) return this.objDdl;
    const dir = path.join(this.schemaDir, 'tables');
    const files = { constraints: path.join(dir, 'OBJECT_CONSTRAINTS.sql'), indexes: path.join(dir, 'OBJECT_INDEXES.sql'), fkeys: path.join(dir, 'OBJECT_FKEYS.sql') };
    const objects = Object.values(this.state.tables).filter((t) => t.kind === 'object').map((t) => t.name);
    this.objDdl = {};
    if (!objects.length) return this.objDdl;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    const sql = { constraints: [], indexes: [], fkeys: [] };
    const notes = [];
    try {
      const o = this.state.schema;
      const inList = objects.map((_, i) => `:t${i}`).join(', ');
      const binds = Object.fromEntries(objects.map((n, i) => [`t${i}`, n]));
      const hidden = new Set((await conn.execute(
        `SELECT table_name || '.' || column_name FROM dba_tab_cols WHERE owner = :o AND table_name IN (${inList}) AND hidden_column = 'YES'`, { o, ...binds })).rows.map((r) => r[0]));
      const colsOf = new Map();
      for (const [cname, col] of (await conn.execute(
        `SELECT constraint_name, column_name FROM dba_cons_columns WHERE owner = :o AND table_name IN (${inList}) ORDER BY constraint_name, position`, { o, ...binds })).rows) {
        if (!colsOf.has(cname)) colsOf.set(cname, []);
        colsOf.get(cname).push(col);
      }
      const cons = (await conn.execute(
        `SELECT table_name, constraint_name, constraint_type, search_condition, status, deferrable, deferred, delete_rule, r_owner, r_constraint_name
           FROM dba_constraints WHERE owner = :o AND table_name IN (${inList}) AND constraint_type IN ('P', 'U', 'C', 'R')`, { o, ...binds })).rows;
      const tbl = (n) => `${qi(this.pgSchema)}.${qi(this.pgName(n))}`;
      const col = (c) => qi(this.pgName(c));
      const defer = (d, dd) => (d === 'DEFERRABLE' ? ` DEFERRABLE INITIALLY ${dd === 'DEFERRED' ? 'DEFERRED' : 'IMMEDIATE'}` : '');
      for (const [table, name, type, cond, status, deferrable, deferred, deleteRule, rOwner, rName] of cons) {
        const cols = colsOf.get(name) || [];
        if (cols.some((c) => hidden.has(`${table}.${c}`))) continue; // Oracle-internal (SYS_NC_OID$…)
        if (status !== 'ENABLED') { notes.push(`${table}.${name} (disabled in Oracle)`); continue; }
        if (type === 'P') sql.constraints.push(`ALTER TABLE ${tbl(table)} ADD PRIMARY KEY (${cols.map(col).join(', ')})${defer(deferrable, deferred)};`);
        else if (type === 'U') sql.constraints.push(`ALTER TABLE ${tbl(table)} ADD CONSTRAINT ${qi(this.pgName(name))} UNIQUE (${cols.map(col).join(', ')})${defer(deferrable, deferred)};`);
        else if (type === 'C') {
          const nn = /^\s*"?([A-Za-z0-9_$#]+)"?\s+IS\s+NOT\s+NULL\s*$/i.exec(cond || '');
          if (nn) sql.constraints.push(`ALTER TABLE ${tbl(table)} ALTER COLUMN ${col(nn[1])} SET NOT NULL;`);
          else if (cond) {
            const expr = this.state.preserveCase ? cond : cond.replace(/"([A-Z0-9_$#]+)"/g, (_, c) => qi(this.pgName(c)));
            sql.constraints.push(`ALTER TABLE ${tbl(table)} ADD CONSTRAINT ${qi(this.pgName(name))} CHECK (${expr});`);
          }
        } else if (type === 'R') {
          const ref = (await conn.execute('SELECT table_name FROM dba_constraints WHERE owner = :o AND constraint_name = :c', { o: rOwner, c: rName })).rows[0];
          const refCols = (await conn.execute('SELECT column_name FROM dba_cons_columns WHERE owner = :o AND constraint_name = :c ORDER BY position', { o: rOwner, c: rName })).rows.map((r) => r[0]);
          if (!ref || rOwner !== o) { notes.push(`${table}.${name} (refers to another schema)`); continue; }
          const onDelete = deleteRule === 'CASCADE' ? ' ON DELETE CASCADE' : deleteRule === 'SET NULL' ? ' ON DELETE SET NULL' : '';
          sql.fkeys.push(`ALTER TABLE ${tbl(table)} ADD CONSTRAINT ${qi(this.pgName(name))} FOREIGN KEY (${cols.map(col).join(', ')}) REFERENCES ${tbl(ref[0])} (${refCols.map(col).join(', ')})${onDelete}${defer(deferrable, deferred)};`);
        }
      }
      const idx = (await conn.execute(
        `SELECT i.table_name, i.index_name, i.uniqueness, i.index_type, ic.column_name, ic.descend
           FROM dba_indexes i JOIN dba_ind_columns ic ON ic.index_owner = i.owner AND ic.index_name = i.index_name
          WHERE i.table_owner = :o AND i.table_name IN (${inList})
            AND NOT EXISTS (SELECT 1 FROM dba_constraints c WHERE c.owner = i.table_owner AND c.index_name = i.index_name AND c.constraint_type IN ('P', 'U'))
          ORDER BY i.index_name, ic.column_position`, { o, ...binds })).rows;
      const byIndex = new Map();
      for (const [table, name, uniq, itype, c, desc] of idx) {
        if (!byIndex.has(name)) byIndex.set(name, { table, uniq, itype, cols: [] });
        byIndex.get(name).cols.push({ c, desc });
      }
      for (const [name, ix] of byIndex) {
        if (/FUNCTION-BASED/.test(ix.itype)) { notes.push(`${ix.table}.${name} (function-based index)`); continue; }
        if (ix.cols.some((x) => hidden.has(`${ix.table}.${x.c}`))) continue;
        sql.indexes.push(`CREATE ${ix.uniq === 'UNIQUE' ? 'UNIQUE ' : ''}INDEX ${qi(this.pgName(name))} ON ${tbl(ix.table)} (${ix.cols.map((x) => `${col(x.c)}${x.desc === 'DESC' ? ' DESC' : ''}`).join(', ')});`);
      }
    } finally {
      await conn.close().catch(() => {});
    }
    await fsp.mkdir(dir, { recursive: true });
    for (const k of Object.keys(files)) {
      if (!sql[k].length) continue;
      await fsp.writeFile(files[k], `${sql[k].join('\n')}\n`);
      this.objDdl[k] = files[k];
    }
    if (notes.length) this.event('info', `Object tables: not created automatically: ${notes.slice(0, 10).join(', ')}${notes.length > 10 ? ` and ${notes.length - 10} more` : ''}`);
    return this.objDdl;
  }

  /**
   * Foreign keys in two steps, like EDB's loader: ADD ... NOT VALID is instant (no table scan, so
   * keys on the same parent do not wait for each other), then VALIDATE CONSTRAINT checks the
   * existing rows, in parallel, without blocking reads or writes. A key whose rows do not match
   * stays in place as NOT VALID (new rows are checked) and is reported with the reason.
   * Keys on partitioned tables are added in one step (PostgreSQL has no NOT VALID for them).
   */
  async phase_fkeys() {
    // PostgreSQL refuses NOT VALID keys on partitioned tables: those are added (and checked) in one step.
    const { rows: parts } = await pgClient.pgQuery(
      `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relkind = 'p'`,
      [this.pgSchema], this.projectName,
    );
    const partitioned = new Set(parts.map((r) => r.relname));
    const tableOf = (stmt) => {
      const m = /^ALTER\s+TABLE\s+(?:ONLY\s+)?(?:(?:"[^"]+"|[\w$]+)\.)?("([^"]+)"|[\w$]+)/i.exec(stmt);
      return m ? (m[2] || m[1].toLowerCase()) : null;
    };
    const notValid = (stmt) => (/FOREIGN\s+KEY/i.test(stmt) && !/NOT\s+VALID/i.test(stmt) && !partitioned.has(tableOf(stmt))
      ? stmt.replace(/;\s*$/, ' NOT VALID;') : stmt);
    const skip = skipList(this.settings);
    const obj = await this.objectTableDdl();
    await this.runDdlPhase('fkeys', [
      ['Foreign keys', path.join(this.schemaDir, 'tables', 'FKEYS_table.sql')],
      ...(obj.fkeys ? [['Object tables: foreign keys', obj.fkeys]] : []),
    ], { transform: (stmt) => (skipStatement(stmt, skip) ? null : notValid(stmt)) });
    this.checkCancelled();

    const tables = new Set(Object.keys(this.state.tables).map((n) => this.pgName(n)));
    const { rows } = await pgClient.pgQuery(
      `SELECT con.conname, cl.relname FROM pg_constraint con
         JOIN pg_class cl ON cl.oid = con.conrelid JOIN pg_namespace n ON n.oid = cl.relnamespace
        WHERE n.nspname = $1 AND con.contype = 'f' AND NOT con.convalidated AND con.conparentid = 0`,
      [this.pgSchema], this.projectName,
    );
    const todo = rows.filter((r) => tables.has(r.relname));
    const failures = [];
    let n = 0;
    const limit = pLimit(Math.max(1, this.state.options.ddlParallel));
    await Promise.all(todo.map((r) => limit(async () => {
      if (this.cancelRequested) return;
      const sql = `ALTER TABLE ${qi(this.pgSchema)}.${qi(r.relname)} VALIDATE CONSTRAINT ${qi(r.conname)}`;
      try {
        await pgClient.pgQuery(sql, [], this.projectName);
      } catch (err) {
        failures.push({ step: 'Validate foreign keys', statement: sql, error: err.message });
        this.log.error(`Validate foreign keys: ${err.message}\n    SQL: ${sql}`);
      }
      n += 1;
      this.updatePhase('fkeys', { detail: `Validating foreign keys ${n}/${todo.length}`, progress: Math.round((n / todo.length) * 100) });
    })));
    this.checkCancelled();
    if (todo.length) {
      this.event(failures.length ? 'error' : 'info', `Foreign keys validated: ${todo.length - failures.length} of ${todo.length}${failures.length ? `; ${failures.length} kept as NOT VALID because existing rows do not match (see the DDL failures)` : ''}`);
    }
    this.state.ddlFailures = [...(this.state.ddlFailures || []).filter((f) => f.step !== 'Validate foreign keys'), ...failures].slice(-500);
    if (failures.length) this.phase('fkeys').warnings = (this.phase('fkeys').warnings || 0) + failures.length;
  }

  async phase_sequences() {
    // Exported now (after the data load) so the values match the data that was copied.
    const dir = path.join(this.schemaDir, 'sequence_values');
    await fsp.mkdir(dir, { recursive: true });
    const res = await this.ora2pg(['-t', 'SEQUENCE_VALUES', '-c', this.ddlConf, '-b', dir, '-o', 'sequence_value.sql'], 'Export sequence values');
    if (res.code !== 0) {
      this.phase('sequences').warnings = 1;
      this.event('error', `Sequence values could not be exported: ${firstError(res.errorTail)}`);
      await this.setIdentityValues();
      return;
    }
    await this.runDdlPhase('sequences', [['Sequence values', path.join(dir, 'sequence_value.sql')]]);
    await this.setIdentityValues();
  }

  /**
   * Identity columns (GENERATED AS IDENTITY): ora2pg creates them but their sequence stays at 1,
   * so the first new row would collide with a migrated one. Each loaded table's identity continues
   * after the highest value: the larger of max(column) + 1 and Oracle's own next value (Oracle may
   * have used values that were deleted since).
   */
  async setIdentityValues() {
    const loaded = new Set(Object.values(this.state.tables).filter((t) => t.status === 'done').map((t) => this.pgName(t.name)));
    if (!loaded.size) return;
    const { rows } = await pgClient.pgQuery(
      `SELECT c.relname, a.attname FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = $1 AND a.attidentity IN ('a', 'd') AND NOT a.attisdropped`, [this.pgSchema], this.projectName);
    const todo = rows.filter((r) => loaded.has(r.relname));
    if (!todo.length) return;
    const oracleNext = new Map();
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(
        `SELECT i.table_name, i.column_name, s.last_number FROM dba_tab_identity_cols i
           JOIN dba_sequences s ON s.sequence_owner = i.owner AND s.sequence_name = i.sequence_name
          WHERE i.owner = :o`, { o: this.state.schema });
      for (const [table, column, next] of r.rows) oracleNext.set(`${this.pgName(table)}.${this.pgName(column)}`, Number(next) || 1);
    } catch (err) {
      this.log.error(`Oracle identity values could not be read (max + 1 is used): ${err.message}`);
    } finally {
      await conn.close().catch(() => {});
    }
    let ok = 0;
    const failures = [];
    for (const { relname, attname } of todo) {
      const tbl = `${qi(this.pgSchema)}.${qi(relname)}`;
      const sql = `SELECT setval(pg_get_serial_sequence($1, $2), GREATEST(COALESCE((SELECT max(${qi(attname)}) FROM ${tbl}), 0) + 1, $3::bigint), false)`;
      try {
        await pgClient.pgQuery(sql, [tbl, attname, oracleNext.get(`${relname}.${attname}`) || 1], this.projectName);
        ok += 1;
      } catch (err) {
        failures.push({ step: 'Identity values', statement: `${relname}.${attname}`, error: err.message });
        this.log.error(`Identity value for ${relname}.${attname}: ${err.message}`);
      }
    }
    this.event(failures.length ? 'error' : 'info', `Identity columns: ${ok} set to continue after the migrated values${failures.length ? `, ${failures.length} failed` : ''}`);
    if (failures.length) {
      this.phase('sequences').warnings = (this.phase('sequences').warnings || 0) + failures.length;
      this.state.ddlFailures = [...(this.state.ddlFailures || []), ...failures].slice(-500);
    }
  }

  /**
   * Optional (Settings → BLOB storage = large objects): BLOB columns are loaded as bytea (fast,
   * streamed with COPY) and then converted in PostgreSQL with lo_from_bytea, so v1's lo_import
   * shell scripts (blob.sh) are not needed. Runs before the indexes so the full-text index helper
   * (fts_oid.sh) finds oid columns.
   */
  async convertBlobsToOid() {
    const loaded = Object.values(this.state.tables).filter((t) => t.status === 'done').map((t) => t.name);
    if (!loaded.length) return;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    let cols;
    try {
      const r = await conn.execute(`SELECT table_name, column_name FROM dba_tab_columns WHERE owner = :o AND data_type = 'BLOB'`, { o: this.state.schema });
      cols = r.rows.filter((x) => loaded.includes(x[0]));
    } finally {
      await conn.close().catch(() => {});
    }
    let n = 0;
    for (const [table, column] of cols) {
      this.checkCancelled();
      this.updatePhase('indexes', { detail: `BLOB → large object: ${table}.${column}` });
      const { rows } = await pgClient.pgQuery(
        `SELECT format_type(a.atttypid, a.atttypmod) AS t FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relname = $2 AND a.attname = $3`,
        [this.pgSchema, this.pgName(table), this.pgName(column)], this.projectName);
      if (!rows.length || rows[0].t !== 'bytea') continue; // already converted (resume) or renamed
      try {
        await pgClient.pgQuery(`ALTER TABLE ${qi(this.pgSchema)}.${qi(this.pgName(table))} ALTER COLUMN ${qi(this.pgName(column))} TYPE oid USING lo_from_bytea(0, ${qi(this.pgName(column))})`, [], this.projectName);
        n += 1;
      } catch (err) {
        this.phase('indexes').warnings = (this.phase('indexes').warnings || 0) + 1;
        this.event('error', `BLOB → oid failed for ${table}.${column}: ${err.message}`);
      }
    }
    if (n) this.event('info', `${n} BLOB columns stored as large objects (oid)`);
  }

  /** Applies the converted GenAI package chosen for this run (Code objects page). */
  async phase_code() {
    if (!this.state.codePackageId && this.state.createDbLinks) {
      // DMA-079: the saved DB links on their own (a package, when chosen, creates them itself).
      this.updatePhase('code', { detail: 'Creating the saved DB links' });
      const r = await code.createDbLinks(this.projectName);
      const dbLinks = r.failed ? r.links.filter((l) => !l.ok).map((l) => `${l.name}: ${l.message}`).join(' ') : 'ok';
      this.state.codeResult = { packageId: null, applied: 0, existing: 0, failed: [], dbLinks, links: r.links.map(({ name, ok, action, tables }) => ({ name, ok, action, tables })) };
      if (r.failed) this.phase('code').warnings = r.failed;
      this.event(r.failed ? 'error' : 'info', r.links.length
        ? `DB links: ${r.created} created${r.failed ? `, ${r.failed} FAILED: ${dbLinks}` : ''} (no converted package chosen: apply it later from Code objects)`
        : 'DB links: none saved (Code objects page)');
      this.updatePhase('code', { detail: r.links.length ? `DB links: ${r.created} created${r.failed ? `, ${r.failed} failed` : ''}` : 'No DB links saved' });
      return;
    }
    if (!this.state.codePackageId) {
      this.phase('code').skipped = true;
      this.updatePhase('code', { detail: 'No converted package chosen: apply it later from Code objects' });
      return;
    }
    const r = await code.applyPackage(this.projectName, this.state.codePackageId, {
      pg: this.pg,
      pgSchema: this.pgSchema,
      log: this.log,
      children: this.children,
      runId: this.state.runId,
      shouldStop: () => this.cancelRequested,
      onProgress: (applied, total, pass) => this.updatePhase('code', { detail: `${applied}/${total} files applied (pass ${pass})`, progress: Math.round((applied / Math.max(1, total)) * 100) }),
    });
    this.state.codeResult = { packageId: this.state.codePackageId, applied: r.applied, existing: r.existing || 0, failed: r.failed.slice(0, 200), dbLinks: r.dbLinks };
    const linkFailed = !!r.dbLinks && r.dbLinks !== 'ok';
    if (r.failed.length || linkFailed) this.phase('code').warnings = r.failed.length + (linkFailed ? 1 : 0);
    this.event(r.failed.length || linkFailed ? 'error' : 'info', `Converted code: ${r.applied} files applied, ${r.failed.length} failed${r.dbLinks ? `, DB links: ${linkFailed ? `FAILED: ${r.dbLinks}` : 'created'}` : ''}`);
  }

  async phase_finalize() {
    // Safety net for bulk-load mode: no table is left unlogged or without autovacuum.
    for (const t of Object.values(this.state.tables).filter((x) => x.unlogged || x.autovacuumOff)) {
      await this.bulkFinish(t).catch((err) => {
        this.phase('finalize').warnings = (this.phase('finalize').warnings || 0) + 1;
        this.event('error', `${t.name}: could not be made permanent / autovacuum switched back on: ${err.message}`);
      });
    }
    const loaded = Object.values(this.state.tables).filter((t) => t.status === 'done');
    const limit = pLimit(Math.max(1, this.state.options.ddlParallel));
    let n = 0;
    await Promise.all(loaded.map((t) => limit(async () => {
      if (this.cancelRequested) return;
      await pgClient.pgQuery(`ANALYZE ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName)
        .catch((err) => this.log.error(`ANALYZE ${t.name}: ${err.message}`));
      n += 1;
      this.updatePhase('finalize', { detail: `ANALYZE ${n}/${loaded.length}`, progress: Math.round((n / Math.max(1, loaded.length)) * 100) });
    })));
    this.checkCancelled();
    // Application access (Settings → decisions): grants for the app roles and the optional DUAL view.
    const access = settingsSvc.accessSql(this.settings, this.pgSchema);
    let failed = 0;
    for (const sql of access) {
      await pgClient.pgQuery(sql, [], this.projectName).catch((err) => { failed += 1; this.log.error(`${sql}: ${err.message}`); });
    }
    if (access.length) {
      this.event(failed ? 'error' : 'info', `Application access: ${access.length - failed} grants applied${failed ? `, ${failed} failed (does the role exist?)` : ''}`);
      if (failed) this.phase('finalize').warnings = failed;
    }
    await store.writeJsonAtomic(path.join(this.dir, 'summary.json'), { ...this.summary(), tables: this.state.tables });
  }
}

/** A table as sent to the browser: the chunk list is replaced by its summary. */
/**
 * PostgreSQL type tree of a table's columns: [{ name, type }] where type is
 * { kind: 'scalar' } | { kind: 'array', elem } | { kind: 'composite', attrs: [{ name, type }], wrapper }.
 * wrapper: ora2pg's one-field type around an array (CREATE TYPE tags_t AS (tags_t varchar(20)[])),
 * which it creates for Oracle nested tables and VARRAYs.
 */
async function pgColumnTypes(projectName, schema, table) {
  const cache = new Map();
  const typeOf = async (oid, depth = 0) => {
    if (cache.has(oid)) return cache.get(oid);
    const { rows } = await pgClient.pgQuery('SELECT typtype, typcategory, typelem, typrelid FROM pg_type WHERE oid = $1', [oid], projectName);
    let type = { kind: 'scalar' };
    const tp = rows[0];
    if (tp && depth < 8) {
      if (tp.typcategory === 'A' && Number(tp.typelem)) type = { kind: 'array', elem: await typeOf(tp.typelem, depth + 1) };
      else if (tp.typtype === 'c') {
        const { rows: at } = await pgClient.pgQuery(
          'SELECT attname, atttypid FROM pg_attribute WHERE attrelid = $1 AND attnum > 0 AND NOT attisdropped ORDER BY attnum', [tp.typrelid], projectName);
        const attrs = [];
        for (const a of at) attrs.push({ name: a.attname, type: await typeOf(a.atttypid, depth + 1) });
        type = { kind: 'composite', attrs, wrapper: attrs.length === 1 && attrs[0].type.kind === 'array' };
      }
    }
    cache.set(oid, type);
    return type;
  };
  const { rows } = await pgClient.pgQuery(
    `SELECT a.attname, a.atttypid FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = $1 AND c.relname = $2 AND a.attnum > 0 AND NOT a.attisdropped ORDER BY a.attnum`, [schema, table], projectName);
  const out = [];
  for (const r of rows) out.push({ name: r.attname, type: await typeOf(r.atttypid) });
  return out;
}

/**
 * One ora2pg global temporary table statement (EXPORT_GTT form) → { stmt, name, columns, onCommit },
 * or null for any other statement (LOAD, SET, comments).
 *   CREATE /*GLOBAL*\/ TEMPORARY TABLE tmp_calc (calc_id numeric, result numeric) ON COMMIT DELETE ROWS ;
 */
function gttDefinition(stmt) {
  const m = /CREATE\s+(?:\/\*GLOBAL\*\/\s+)?TEMPORARY\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?((?:"[^"]+"|[\w$#]+)\.)?("[^"]+"|[\w$#]+)\s*\(([\s\S]*)\)\s*ON\s+COMMIT\s+(DELETE|PRESERVE)\s+ROWS/i.exec(stmt);
  return m ? { stmt, name: m[2].replace(/"/g, ''), columns: m[3], onCommit: m[4].toUpperCase() } : null;
}

/** A text as a SQL string literal ('it''s'). */
const pgLiteralSql = (x) => `'${String(x).replace(/'/g, "''")}'`;

const pad2 = (n, w = 2) => String(n).padStart(w, '0');
/** Oracle DATE / TIMESTAMP as the wall-clock time Oracle holds (no time zone shift). */
const wallClock = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}.${pad2(d.getMilliseconds(), 3)}`;
/** Quoted element of a composite "(…)" or array "{…}" literal. */
const quoteElem = (x) => `"${x.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
/** An Oracle object or collection from node-oracledb (collections are a subclass: "bound DbObject"). */
const isDbObject = (v) => v && typeof v === 'object' && typeof v.isCollection === 'boolean';

/**
 * One Oracle value as PostgreSQL text input for the column type (from pgColumnTypes), or null.
 *   object      → composite "(a,b,…)", attributes in type order
 *   collection  → array "{a,b}"; for ora2pg's one-field wrapper type → "("{a,b}")"
 * The NUL character (chr(0)) cannot be stored by PostgreSQL in text and is removed (the data check
 * then reports it).
 */
function pgLiteral(v, type = { kind: 'scalar' }) {
  if (v === null || v === undefined) return null;
  if (v instanceof Date) return wallClock(v);
  if (Buffer.isBuffer(v)) return `\\x${v.toString('hex')}`;
  if (typeof v === 'string') return v.replace(/\u0000/g, '');
  const list = Array.isArray(v) ? v : isDbObject(v) && v.isCollection ? v.getValues() : null;
  if (list) {
    const elemType = type.kind === 'array' ? type.elem : type.kind === 'composite' && type.wrapper ? type.attrs[0].type.elem : { kind: 'scalar' };
    const arr = `{${list.map((e) => {
      const x = pgLiteral(e, elemType);
      return x === null ? 'NULL' : quoteElem(x);
    }).join(',')}}`;
    return type.kind === 'composite' && type.wrapper ? `(${quoteElem(arr)})` : arr;
  }
  if (isDbObject(v)) {
    const attrs = type.kind === 'composite' && !type.wrapper ? type.attrs : [];
    return `(${Object.keys(v.attributes || {}).map((a, i) => {
      const x = pgLiteral(v[a], (attrs[i] || {}).type);
      return x === null ? '' : quoteElem(x);
    }).join(',')})`;
  }
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

function publicTable(t) {
  if (!t || !t.chunks) return t;
  const { chunks, ...rest } = t;
  return rest;
}

/** Settings → Skip constraint types, as a set: fkeys pkeys ukeys indexes checks. */
function skipList(settings) {
  return new Set(String((settings && settings.ora2pg.SKIP) || '').toLowerCase().split(/[\s;,]+/).map((s) => (s === 'indices' ? 'indexes' : s)).filter(Boolean));
}

/**
 * true when a statement of the constraint / index / foreign key files is of a type the project skips.
 * Done here because ora2pg crashes on its own SKIP directive. NOT NULL is a column property: never skipped.
 */
function skipStatement(stmt, skip) {
  if (!skip.size) return false;
  const s = stmt.replace(/\s+/g, ' ');
  if (/\bFOREIGN KEY\b/i.test(s)) return skip.has('fkeys');
  if (/\bPRIMARY KEY\b/i.test(s)) return skip.has('pkeys');
  if (/^ALTER TABLE .* ADD (CONSTRAINT \S+ )?UNIQUE\b/i.test(s) || /^CREATE UNIQUE INDEX\b/i.test(s)) return skip.has('ukeys');
  if (/^ALTER TABLE .* ADD (CONSTRAINT \S+ )?CHECK\b/i.test(s)) return skip.has('checks');
  if (/^CREATE (INDEX|INDEX CONCURRENTLY)\b/i.test(s)) return skip.has('indexes');
  return false;
}

/**
 * Preserve case: ora2pg quotes the column names ("QTY") but leaves the expressions of calculated
 * columns as Oracle wrote them (QTY*UNIT_PRICE), which PostgreSQL folds to lower case and then
 * cannot find. Quotes the table's own column names inside GENERATED ALWAYS AS (...).
 */
function quoteGeneratedColumns(text) {
  let cols = new Set();
  return text.split('\n').map((line) => {
    if (/^\s*CREATE\s+(UNLOGGED\s+)?TABLE\b/i.test(line)) cols = new Set();
    const col = /^\s*"([^"]+)"\s+\S/.exec(line);
    if (col) cols.add(col[1]);
    const at = line.search(/GENERATED\s+ALWAYS\s+AS\s*\(/i);
    if (at < 0) return line;
    const open = line.indexOf('(', at);
    let depth = 0;
    let end = open;
    for (; end < line.length; end += 1) {
      if (line[end] === '(') depth += 1;
      else if (line[end] === ')' && --depth === 0) break;
    }
    // Words outside '...' and "..." that are this table's columns get quoted.
    const expr = line.slice(open, end + 1).replace(/'(?:[^']|'')*'|"[^"]*"|[A-Za-z_][A-Za-z0-9_$#]*/g, (m) => (cols.has(m) ? `"${m}"` : m));
    return line.slice(0, open) + expr + line.slice(end + 1);
  }).join('\n');
}

/** Decimal string from Oracle TO_CHAR / PostgreSQL ::text in one canonical form ('.50' -> '0.5'). */
/**
 * Fingerprint of everything that shapes the tables and the data files: names, type mapping, booleans,
 * LOB storage, target schema, column renames. A run is only resumed, and an export file only
 * re-imported, while this is unchanged.
 */
const isStalled = (err) => /stopped as hung/.test(err.message || '');

function decisionsHash(settings, meta) {
  return require('crypto').createHash('sha1').update(JSON.stringify({
    o: settings.ora2pg, x: settings.extraDirectives, l: settings.lob, t: settings.targetSchema, r: meta.columnRenames || [],
  })).digest('hex').slice(0, 12);
}

function normDecimal(v) {
  if (v === null || v === undefined) return null;
  let s = String(v).trim();
  const neg = s.startsWith('-');
  if (neg || s.startsWith('+')) s = s.slice(1);
  if (s.startsWith('.')) s = `0${s}`;
  if (s.includes('.')) s = s.replace(/0+$/, '').replace(/\.$/, '');
  s = s.replace(/^0+(?=\d)/, '');
  return (neg && s !== '0' ? '-' : '') + s;
}

/** Splits "a varchar(255), b numeric(10,2)" at the commas outside parentheses. */
function splitTopLevel(list) {
  const parts = [];
  let depth = 0;
  let cur = '';
  for (const ch of list) {
    if (ch === '(') depth += 1;
    if (ch === ')') depth -= 1;
    if (ch === ',' && depth === 0) { parts.push(cur.trim()); cur = ''; } else cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

/**
 * Oracle type evolution in PostgreSQL syntax:
 *   ALTER TYPE t MODIFY ATTRIBUTE (a varchar(255), b ...) [CASCADE]  ->  ALTER TYPE t ALTER ATTRIBUTE a TYPE varchar(255), ...
 *   ALTER TYPE t ADD ATTRIBUTE (a int)                               ->  ALTER TYPE t ADD ATTRIBUTE a int
 *   ALTER TYPE t DROP ATTRIBUTE (a, b)                               ->  ALTER TYPE t DROP ATTRIBUTE a, DROP ATTRIBUTE b
 * Oracle-only options (INVALIDATE, INCLUDING TABLE DATA, ...) are dropped; CASCADE is kept.
 */
function pgTypeSql(text) {
  return text
    .replace(/^\s*\\set\s+ON_ERROR_STOP\s+ON\s*$/gim, '')
    .replace(/ALTER\s+TYPE\s+([\w$#."]+)\s+(MODIFY|ADD|DROP)\s+ATTRIBUTE\s*(\(([\s\S]*?)\)|([^;]*?))\s*((?:CASCADE|INVALIDATE|INCLUDING|NOT|TABLE|DATA|FORCE|CONVERT|TO|SUBSTITUTABLE|\s)*)\s*;/gi,
      (all, type, op, _p, inParens, bare, opts) => {
        const items = splitTopLevel(inParens !== undefined ? inParens : bare).filter(Boolean);
        if (!items.length) return all;
        const cascade = /\bCASCADE\b/i.test(opts || '') ? ' CASCADE' : '';
        const parts = items.map((item) => {
          const [, name, rest] = /^("[^"]+"|\S+)\s*([\s\S]*)$/.exec(item);
          if (/^MODIFY$/i.test(op)) return `ALTER ATTRIBUTE ${name} TYPE ${rest.trim()}${cascade}`;
          if (/^ADD$/i.test(op)) return `ADD ATTRIBUTE ${name} ${rest.trim()}${cascade}`;
          return `DROP ATTRIBUTE ${name}${cascade}`;
        });
        return `ALTER TYPE ${type} ${parts.join(', ')};`;
      });
}

function firstError(text) {
  if (!text) return '';
  const lines = String(text).split('\n').map((l) => l.trim()).filter(Boolean);
  return (lines.find((l) => /ERROR|FATAL|ORA-\d{5}/.test(l)) || lines[0] || '').slice(0, 500);
}

/**
 * The project's status after a run: the run's own status, except that a COMPLETED run of a few
 * tables does not hide a table that failed in an earlier run into the same target schema and was
 * not loaded since (the Projects page would show the project as done while that table is wrong).
 */
async function overallStatus(projectName, state) {
  if (state.status !== 'COMPLETED') return state.status;
  const latest = new Map(); // table → status of its newest run
  for (const r of await listRuns(projectName)) { // newest first
    const s = r.runId === state.runId ? state : await readRunState(projectName, r.runId);
    if (!s || s.targetSchema !== state.targetSchema || !TERMINAL.has(s.status)) continue;
    for (const t of Object.values(s.tables || {})) if (!latest.has(t.name)) latest.set(t.name, t.status);
  }
  return [...latest.values()].includes('failed') ? 'COMPLETED_WITH_ERRORS' : state.status;
}

// ---------- public API ----------

/**
 * Classifies the selected tables from the snapshot (as v1 did: object, LOB, huge, normal).
 */
function buildTables(selected, snapshot, options) {
  const meta = new Map((snapshot.tableMetadata || []).map((t) => [t.name, t]));
  const lob = new Set((snapshot.lobTables || (snapshot.blobColumns || []).map((b) => b.tableName)) || []);
  const objects = new Set((snapshot.objectTables || []).map((o) => o.tableName || o));
  const tables = {};
  for (const name of selected) {
    // Oracle's materialized view log tables are internal (older snapshots still listed them).
    if (/^(MLOG|RUPD)\$/.test(name)) continue;
    const m = meta.get(name) || {};
    const estRows = Number(m.rowCount) || 0;
    const kind = objects.has(name) ? 'object' : lob.has(name) ? 'lob' : estRows >= options.hugeTableRows ? 'huge' : 'normal';
    tables[name] = { name, kind, estRows, sizeMb: Number(m.sizeMb) || 0, status: 'pending', attempts: 0, rowsDone: 0, rate: 0 };
  }
  return tables;
}

function normalizeOptions(o = {}) {
  const n = (v, d, min, max) => {
    const x = Number(v);
    return Number.isFinite(x) ? Math.min(max, Math.max(min, Math.round(x))) : d;
  };
  return {
    loadMode: ['direct', 'file', 'export'].includes(o.loadMode) ? o.loadMode : CONSTANTS.LOAD_MODE,
    parallelTables: n(o.parallelTables, CONSTANTS.PARALLEL_TABLES, 1, 32),
    hugeTableRows: n(o.hugeTableRows, CONSTANTS.HUGE_TABLE_ROWS, 1000, 1e12),
    oracleCopies: n(o.oracleCopies, CONSTANTS.ORACLE_COPIES, 1, 32),
    chunkRows: o.chunkRows === 0 || o.chunkRows === '0' ? 0 : n(o.chunkRows, CONSTANTS.CHUNK_ROWS, 100000, 1e10),
    pgJobs: n(o.pgJobs, CONSTANTS.PG_JOBS, 1, 32),
    dataLimit: n(o.dataLimit, CONSTANTS.DATA_LIMIT, 100, 1000000),
    blobLimit: n(o.blobLimit, CONSTANTS.BLOB_LIMIT, 1, 100000),
    maxAttempts: n(o.maxAttempts, CONSTANTS.MAX_ATTEMPTS, 1, 10),
    ddlParallel: n(o.ddlParallel, CONSTANTS.DDL_PARALLEL, 1, 32),
    maintenanceWorkMem: /^\d+(kB|MB|GB)$/.test(o.maintenanceWorkMem || '') ? o.maintenanceWorkMem : CONSTANTS.MAINTENANCE_WORK_MEM,
    verifyRowCounts: o.verifyRowCounts === undefined ? CONSTANTS.VERIFY_ROW_COUNTS : !!o.verifyRowCounts,
    chunkMb: n(o.chunkMb, CONSTANTS.CHUNK_MB, 64, 1e7),
    stallMinutes: o.stallMinutes === 0 || o.stallMinutes === '0' ? 0 : n(o.stallMinutes, CONSTANTS.STALL_MINUTES, 1, 1440),
    verifyData: ['all', 'off'].includes(o.verifyData) ? o.verifyData : CONSTANTS.VERIFY_DATA,
    snapshot: ['on', 'off'].includes(o.snapshot) ? o.snapshot : CONSTANTS.SNAPSHOT,
    bulkLoad: ['standard', 'unlogged'].includes(o.bulkLoad) ? o.bulkLoad : CONSTANTS.BULK_LOAD,
    autoTune: ['on', 'off'].includes(o.autoTune) ? o.autoTune : CONSTANTS.AUTO_TUNE,
    maxReaders: o.maxReaders === undefined || o.maxReaders === '' ? 0 : n(o.maxReaders, 0, 0, 64),
  };
}

/** Refuses a run when this project already runs one, or the server already runs DMA_MAX_RUNS. */
function checkCanStart(projectName) {
  if (RUNS_ELSEWHERE) throw Object.assign(new Error('Migrations run in the migration worker on this server (DMA_WORKER=on).'), { status: 500 });
  if (active.has(projectName)) throw Object.assign(new Error('A migration is already running for this project.'), { status: 409 });
  const other = runLock.heldByOther(projectName);
  if (other) throw Object.assign(new Error(`A migration of this project is already running in another DMA process (run ${other.runId}).`), { status: 409 });
  if (active.size >= CONSTANTS.MAX_RUNS) {
    throw Object.assign(new Error(`This server is already running ${active.size} migration${active.size > 1 ? 's' : ''} (${[...active.keys()].join(', ')}), its limit. `
      + 'Start this one when one of them ends: running more at once would slow all of them down.'), { status: 409 });
  }
}

function launch(projectName, state) {
  runLock.acquire(projectName, state.runId);
  const run = new Run(projectName, state);
  active.set(projectName, run);
  run.save(true);
  // The job keeps the project context for cache / pool lookups deep in the call stack.
  runWithProject(projectName, () => run.execute()).catch((err) => logger.error(`Run crashed: ${err.stack}`));
  return run;
}

async function startRun(projectName, { tables, options, allTablesSelected, codePackageId, createDbLinks, startedBy, notifyEmails }) {
  checkCanStart(projectName);
  await leftoversGone; // after a crash: the old processes must be gone before tables are loaded again
  checkCanStart(projectName);
  const meta = await store.readMeta(projectName);
  const schema = meta && meta.selectedSchema;
  if (!schema) throw Object.assign(new Error('Select a schema first.'), { status: 400 });
  const snapshot = await store.readSnapshot(projectName, schema);
  if (!snapshot) throw Object.assign(new Error('Take the schema snapshot first.'), { status: 400 });

  const settings = settingsSvc.resolve(meta);
  const opts = normalizeOptions({ ...settings.engine, ...(options || {}) });
  if (codePackageId && !(await code.readPackage(projectName, codePackageId))) {
    throw Object.assign(new Error('The selected converted package does not exist.'), { status: 400 });
  }
  const runId = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
  const state = {
    runId,
    projectName,
    schema,
    targetSchema: settings.targetSchema || schema.toLowerCase(),
    preserveCase: !!settings.ora2pg.PRESERVE_CASE,
    decisionsHash: decisionsHash(settings, meta),
    codePackageId: codePackageId || null,
    // DMA-079: create the saved DB links in the code phase even without a converted package.
    createDbLinks: !!createDbLinks,
    status: 'QUEUED',
    attempt: 1,
    createdAt: nowIso(),
    startedBy: startedBy || null,
    notifyEmails: notifyEmails || [], // "Notify me when it ends" (Migrate page)
    startedAt: null,
    finishedAt: null,
    options: opts,
    allTablesSelected: !!allTablesSelected,
    phases: PHASES.map((p) => ({ key: p.key, label: p.label, status: 'pending', progress: 0 })),
    tables: buildTables(tables, snapshot, opts),
    // DMA-077: what this run used (decisions, snapshot, DMA version), for Run details and Compare runs.
    used: usedAtStart({ settings, meta, dmaVersion: DMA_VERSION }),
    events: [],
    error: null,
  };
  await store.updateMeta(projectName, (m) => ({ ...m, migrationStatus: 'RUNNING', currentMigrationId: runId, lastMigrationDate: state.createdAt }));
  return launch(projectName, state).summary();
}

async function readRunState(projectName, runId) {
  const run = active.get(projectName);
  if (run && run.state.runId === runId) return run.state;
  return store.readJson(path.join(runDirOf(projectName, runId), 'state.json'));
}

async function resumeRun(projectName, runId, { tables: onlyTables, options, codePackageId, auto = false } = {}) {
  checkCanStart(projectName);
  await leftoversGone; // after a crash: the old processes must be gone before tables are loaded again
  checkCanStart(projectName);
  const state = await readRunState(projectName, runId);
  if (!state) throw Object.assign(new Error('Run not found.'), { status: 404 });
  if (!TERMINAL.has(state.status)) throw Object.assign(new Error(`Run is ${state.status}.`), { status: 409 });

  const meta = await store.readMeta(projectName);
  const current = decisionsHash(settingsSvc.resolve(meta), meta);
  if (state.decisionsHash && state.decisionsHash !== current) {
    throw Object.assign(new Error('The migration decisions (names, type mapping, booleans, LOBs, target schema or column renames) changed since this run started. Its tables and files follow the old ones: start a new run, which rebuilds the tables with the new mapping.'), { status: 409 });
  }
  state.attempt = (state.attempt || 1) + 1;
  state.finishedAt = null;
  state.error = null;
  state.interruptedBy = null;
  state.autoResumeGaveUp = false;
  if (auto) {
    state.autoResumes = (state.autoResumes || 0) + 1;
    state.autoResumedAt = nowIso();
  } else {
    state.autoResumedAt = null;
  }
  if (options) state.options = normalizeOptions({ ...state.options, ...options });
  if (codePackageId !== undefined) state.codePackageId = codePackageId || null;
  for (const t of Object.values(state.tables)) {
    const retry = onlyTables ? onlyTables.includes(t.name) : t.status !== 'done';
    if (retry) {
      Object.assign(t, { status: 'pending', attempts: 0, error: null, rate: 0 });
      // Chunks already loaded stay loaded; the rest is reloaded.
      (t.chunks || []).forEach((c) => { if (c.status !== 'done') Object.assign(c, { status: 'pending', rate: 0 }); });
    }
  }
  for (const p of state.phases) {
    if (!(KEEP_ON_RESUME.has(p.key) && p.status === 'done')) Object.assign(p, { status: 'pending', progress: 0, warnings: undefined, detail: null });
  }
  return launch(projectName, state).summary();
}

function cancelRun(projectName, runId) {
  const run = active.get(projectName);
  if (!run || run.state.runId !== runId) return false;
  run.cancel();
  return true;
}

async function listRuns(projectName) {
  const dir = store.runsDir(projectName);
  if (!fs.existsSync(dir)) return [];
  const ids = (await fsp.readdir(dir)).sort().reverse();
  const runs = [];
  for (const id of ids) {
    const s = await readRunState(projectName, id);
    if (!s) continue;
    const run = new Run(projectName, s);
    const { events: _e, ...summary } = run.summary();
    runs.push(summary);
  }
  return runs;
}

/** Full state of the running run (tables without their chunk lists), or null. */
function activeRunSummary(projectName) {
  const run = active.get(projectName);
  return run ? browserState(run.state) : null;
}

/** Summaries (no tables, no log lines) of the runs running in this process. */
function activeRuns() {
  return [...active.values()].map((r) => {
    const { events: _e, ...s } = r.summary();
    return s;
  });
}

function browserState(state) {
  if (!state) return state;
  return { ...state, tables: Object.fromEntries(Object.entries(state.tables).map(([k, t]) => [k, publicTable(t)])) };
}

/** Stops ora2pg / psql process groups left over from a crashed server (checked by command name). */
function stopLeftoverProcesses(pids) {
  const stopped = [];
  if (process.platform === 'win32') return stopped;
  const { execFileSync } = require('child_process');
  for (const pid of pids) {
    try {
      const cmd = execFileSync('ps', ['-o', 'command=', '-p', String(pid)], { encoding: 'utf8' }).trim();
      if (!/ora2pg|psql|docker/.test(cmd)) continue;
      process.kill(-pid, 'SIGTERM');
      stopped.push(pid);
      logger.warn(`Stopped leftover process group ${pid} (${cmd.slice(0, 80)})`);
    } catch { /* not running any more */ }
  }
  return stopped;
}

const groupAlive = (pid) => { try { process.kill(-pid, 0); return true; } catch { return false; } };

/**
 * Waits until the leftover ora2pg / psql process groups of a crashed server are really gone, so a
 * resumed run never loads a table while an old process still writes into it. After `ms` they are
 * killed outright.
 */
async function waitForExit(pids, ms = 60000) {
  const until = Date.now() + ms;
  let alive = pids.filter(groupAlive);
  while (alive.length && Date.now() < until) {
    await new Promise((r) => setTimeout(r, 1000));
    alive = alive.filter(groupAlive);
  }
  for (const pid of alive) {
    try { process.kill(-pid, 'SIGKILL'); logger.warn(`Leftover process group ${pid} did not stop: killed`); } catch { /* gone */ }
  }
  if (alive.length) await new Promise((r) => setTimeout(r, 2000));
}

// Starts and resumes wait for this after a crash (set by recoverInterruptedRuns).
let leftoversGone = Promise.resolve();

/** At start-up: runs that were RUNNING when the server stopped are marked INTERRUPTED. */
async function recoverInterruptedRuns() {
  // With the worker on, its runs are its own: the API must never mark them INTERRUPTED or stop their processes.
  if (RUNS_ELSEWHERE) return;
  const projects = await store.listProjects();
  const leftovers = [];
  for (const p of projects) {
    const dir = store.runsDir(p.projectName);
    if (!fs.existsSync(dir)) continue;
    for (const id of await fsp.readdir(dir)) {
      const file = path.join(dir, id, 'state.json');
      const s = await store.readJson(file);
      if (s && !TERMINAL.has(s.status)) {
        // Still running in another process (e.g. the API, while the worker is switched on): leave it alone.
        if (runLock.heldByOther(p.projectName)) continue;
        leftovers.push(...stopLeftoverProcesses(s.pids || []));
        s.pids = [];
        for (const t of Object.values(s.tables)) {
          if (t.status === 'running') Object.assign(t, { status: 'pending', rate: 0, waiting: false });
          (t.chunks || []).forEach((c) => { if (c.status === 'running' || c.status === 'queued') Object.assign(c, { status: 'pending', rate: 0 }); });
        }
        for (const ph of s.phases) if (ph.status === 'running') ph.status = 'pending';
        s.status = 'INTERRUPTED';
        s.interruptedBy = 'server';
        s.error = guards.autoResumeSettings().on
          ? 'The server stopped while this run was in progress. It resumes by itself in a moment; you can also press Resume.'
          : 'The server stopped while this run was in progress. Press Resume to continue where it stopped.';
        s.finishedAt = nowIso();
        await store.writeJsonAtomic(file, s);
        await store.updateMeta(p.projectName, (m) => ({ ...m, migrationStatus: 'INTERRUPTED' }));
        logger.warn(`Run ${p.projectName}/${id} marked INTERRUPTED`);
      }
    }
  }
  if (leftovers.length) leftoversGone = waitForExit(leftovers);
  scheduleAutoResume();
}

/** Runs the server stopped, to resume by themselves (decision in runGuards.autoResumeDecision). */
async function autoResumeCandidates(now = new Date()) {
  const settings = guards.autoResumeSettings();
  const out = [];
  for (const p of await store.listProjects()) {
    const dir = store.runsDir(p.projectName);
    if (!fs.existsSync(dir)) continue;
    for (const id of await fsp.readdir(dir)) {
      const file = path.join(dir, id, 'state.json');
      const s = await store.readJson(file);
      if (!s || s.status !== 'INTERRUPTED' || s.interruptedBy !== 'server') continue;
      const d = guards.autoResumeDecision(s, now, settings);
      if (d.resume) out.push({ projectName: p.projectName, runId: s.runId || id });
      else if (d.limit && !s.autoResumeGaveUp) await giveUpAutoResume(p.projectName, s.runId || id, d.reason);
    }
  }
  return out;
}

/** Automatic resume not done: the reason goes on the run (and it is not tried again). */
async function giveUpAutoResume(projectName, runId, reason) {
  const file = path.join(runDirOf(projectName, runId), 'state.json');
  const s = await store.readJson(file);
  if (!s || s.status === 'RUNNING' || s.status === 'QUEUED') return;
  s.interruptedBy = null;
  s.autoResumeGaveUp = true;
  s.error = `Not resumed automatically: ${reason}. Check the run's errors, then press Resume. (DMA-ENG-202)`;
  await store.writeJsonAtomic(file, s);
  logger.warn(`Run ${projectName}/${runId}: automatic resume stopped (${reason})`);
}

/** Resumes one run; when the server's run limit or a lock is in the way, tries again every minute (30 times). */
async function tryAutoResume(projectName, runId, tries = 0) {
  try {
    await resumeRun(projectName, runId, { auto: true });
    logger.info(`Run ${projectName}/${runId} resumed automatically after a server restart`);
  } catch (err) {
    const busy = err.status === 409 && /already running|its limit|another DMA process/i.test(err.message);
    if (busy && tries < 30) {
      setTimeout(() => { tryAutoResume(projectName, runId, tries + 1); }, 60000).unref();
      return;
    }
    await giveUpAutoResume(projectName, runId, String(err.message || err).replace(/\.$/, '')).catch(() => {});
  }
}

function scheduleAutoResume() {
  const settings = guards.autoResumeSettings();
  if (!settings.on) return;
  setTimeout(async () => {
    try {
      for (const r of await autoResumeCandidates()) await tryAutoResume(r.projectName, r.runId);
    } catch (err) {
      logger.error(`Automatic resume: ${err.message}`);
    }
  }, settings.delaySeconds * 1000).unref();
}

function runLogPath(projectName, runId, kind, table) {
  const base = path.join(runDirOf(projectName, runId), 'logs');
  if (kind === 'table') return path.join(base, 'tables', `${String(table).replace(/[^A-Za-z0-9_$#.-]/g, '_')}.log`);
  return path.join(base, `${kind}.log`);
}

function shutdown() {
  for (const run of active.values()) {
    run.shutdownRequested = true;
    run.cancelRequested = true;
    for (const child of run.children) killProcessTree(child);
  }
}

module.exports = {
  pgLiteral,
  gttDefinition,
  waitForExit, // exported for tests
  PHASES,
  normalizeOptions,
  startRun,
  resumeRun,
  cancelRun,
  listRuns,
  readRunState,
  activeRunSummary,
  activeRuns,
  publicTable,
  browserState,
  recoverInterruptedRuns,
  runLogPath,
  runDirOf,
  shutdown,
  pgTypeSql,
  quoteGeneratedColumns,
  skipStatement,
};
