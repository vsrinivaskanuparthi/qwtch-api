import { Box, Chip, Stack, Switch, FormControlLabel, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import { useState } from 'react';
import { StatusChip } from './ui';
import { fmtDate } from '../format';

/**
 * Run details (one run) and Compare runs (two runs), DMA-077. The lines come from the server
 * (services/runCompare.js), so both views always show the same information.
 */
export type RunDetailsRow = { key: string; label: string; values: string[]; diff: boolean };
export type RunDetailsData = {
  runs: { runId: string; status: string; schema: string; startedAt: string }[];
  sections: { title: string; rows: RunDetailsRow[] }[];
  tables: { name: string; values: ({ status: string; rows: number; seconds: number | null; attempts: number } | null)[]; diff: boolean }[];
};

const dateKeys = new Set(['startedAt', 'finishedAt', 'snapshotAt']);
const cellText = (key: string, v: string) => (dateKeys.has(key) && /^\d{4}-\d\d-\d\dT/.test(v) ? fmtDate(v) : v);
const secs = (s: number | null) => (s === null ? '—' : s < 60 ? `${s} s` : s < 3600 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${Math.floor(s / 3600)} h ${Math.round((s % 3600) / 60)} min`);

/** The sections as compact tables; with two runs, a column per run and differences marked. */
export function RunDetailsView({ data }: { data: RunDetailsData }) {
  const two = data.runs.length > 1;
  const [onlyDiff, setOnlyDiff] = useState(two);
  const diffCount = data.sections.reduce((a, s) => a + s.rows.filter((r) => r.diff).length, 0) + data.tables.filter((t) => t.diff).length;
  const head = (
    <TableHead>
      <TableRow>
        <TableCell sx={{ width: two ? '34%' : '45%' }} />
        {data.runs.map((r) => <TableCell key={r.runId} className="mono" sx={{ fontWeight: 700 }}>{two ? r.runId : 'Value'}</TableCell>)}
      </TableRow>
    </TableHead>
  );
  return (
    <Stack spacing={2.5}>
      {two && (
        <Stack direction="row" spacing={2} alignItems="center">
          <Chip size="small" color={diffCount ? 'warning' : 'success'} label={diffCount ? `${diffCount} differences` : 'No differences'} data-testid="compare-diff-count" />
          <FormControlLabel control={<Switch size="small" checked={onlyDiff} onChange={(e) => setOnlyDiff(e.target.checked)} />} label="Show only differences" />
        </Stack>
      )}
      {data.sections.map((s) => {
        const rows = onlyDiff ? s.rows.filter((r) => r.diff) : s.rows;
        if (!rows.length) return null;
        return (
          <Box key={s.title}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 0.5 }}>{s.title}</Typography>
            <Table size="small" aria-label={s.title} sx={{ tableLayout: 'fixed' }}>
              {two && head}
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.key} data-testid={`detail-${r.key}`} sx={r.diff ? { bgcolor: '#FFF8E6' } : undefined}>
                    <TableCell sx={{ color: 'text.secondary', width: two ? '34%' : '45%' }}>{r.label}</TableCell>
                    {r.values.map((v, i) => (
                      <TableCell key={i} sx={{ fontWeight: r.diff ? 700 : 400, overflowWrap: 'anywhere' }}>
                        {r.key === 'status' ? <StatusChip status={v} /> : cellText(r.key, v)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
        );
      })}
      {two && (
        <Box>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 0.5 }}>Tables</Typography>
          <Table size="small" aria-label="Tables">
            {head}
            <TableBody>
              {(onlyDiff ? data.tables.filter((t) => t.diff) : data.tables).map((t) => (
                <TableRow key={t.name} data-testid={`table-${t.name}`} sx={t.diff ? { bgcolor: '#FFF8E6' } : undefined}>
                  <TableCell className="mono">{t.name}</TableCell>
                  {t.values.map((v, i) => (
                    <TableCell key={i}>
                      {v ? <Stack direction="row" spacing={1} alignItems="center"><StatusChip status={v.status} /><Typography variant="body2">{v.rows.toLocaleString('en-US')} rows · {secs(v.seconds)}{v.attempts > 1 ? ` · ${v.attempts} tries` : ''}</Typography></Stack>
                        : <Typography variant="body2" color="text.secondary">not in this run</Typography>}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}
      {two && onlyDiff && diffCount === 0 && <Typography variant="body2" color="text.secondary">The two runs used the same settings and loaded the same tables.</Typography>}
    </Stack>
  );
}
