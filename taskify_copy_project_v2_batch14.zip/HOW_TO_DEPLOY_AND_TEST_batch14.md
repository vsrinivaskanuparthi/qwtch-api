# DMA v2: batch 14, copy project, run details, CPU/RAM guard, global temporary tables

**No `.env` change needed. No new npm package. `server.js` is not changed.** This zip replaces any earlier batch 14 zip. It does not contain the code objects work (planned separately).

Deploy batch 13 first: this batch builds on it.

## What's new

| # | Item | Where | What users see |
|---|---|---|---|
| 1 | **Copy project** (DMA-057) | **All projects** → copy icon on a project card | "Copy project for another schema": pick the schema, a name is suggested, "Copy the settings too" is on. The new project opens at Schema & snapshot. Same Oracle and PostgreSQL connections, so several schemas can be migrated, even at the same time |
| 2 | **Run details** (DMA-077) | **Live monitor** list → the small ⓘ icon at the end of a run's row → a popup | What the run used: tables, options, migration decisions, PostgreSQL schema, snapshot time, global temporary tables, versions (DMA, ora2pg, PostgreSQL) and time per phase. Nothing is shown unless someone clicks the icon; the run page itself is unchanged |
| 3 | **Compare runs** (DMA-077) | **Live monitor** list → tick 2 runs → "Compare the 2 runs" | Side by side, differences marked in yellow, "Show only differences" on by default, plus each table's result in both runs |
| 4 | **CPU and RAM guard** (DMA-075) | Every run, every phase | When the server is overloaded, DMA starts no new work (table, part of a big table, index, key) until it recovers; running work continues. A yellow notice on the Live monitor while it waits; afterwards "DMA waited N times (…) to protect it" |
| 5 | **Global temporary tables** (DMA-085) | Every run, automatically | Oracle global temporary tables now exist in PostgreSQL (structure, defaults, NOT NULL, keys, "delete rows at commit" or "keep rows until session end"). See below for the two ways |
| 6 | **Simpler run page** | **Live monitor** → a run | "Where did the time go?" is now **off at first**. Normal users never see it (as before); an admin who wants it switches it on: Account → My preferences → "Where did the time go?". Settings (with its Advanced part) stays admins only, as before |

**Copy project, what is copied:** connections, schema list and, if ticked, the settings (decisions, run defaults, notifications, access roles). **Not copied:** snapshot, runs, column renames, DB link mappings, code packages (they belong to the old schema). A target schema set by hand in Settings is cleared, so the copy never loads into the same PostgreSQL schema.

**Runs started before batch 14** show "not recorded" for their decisions and versions in Run details; everything else works.

### CPU and RAM guard, the limits

- Busy = CPU at 95 % or more in two measurements in a row (every 5 seconds), or available memory under 1 GB (or 5 % of the RAM, if more).
- After 10 minutes of waiting the next step starts anyway (one at a time), so a run never hangs.
- Auto-tune keeps its own CPU limit (85 %) for the data load, as before.
- Optional, in the worker's environment only if you want other limits: `DMA_GUARD_CPU_MAX`, `DMA_GUARD_MIN_FREE_MB`, `DMA_GUARD_MAX_WAIT_SECONDS`, `DMA_GUARD_SAMPLE_SECONDS`.

### Global temporary tables, the two ways

PostgreSQL has no global temporary tables. DMA chooses by itself:

| | With the **pgtt** extension (recommended) | Without pgtt |
|---|---|---|
| What is created | Real global temporary tables (kept by pgtt in schema `pgtt_schema`) | A template of each table in schema `<target>_gtt` and the helper `<target>_gtt.dma_gtt_use('table')` |
| Each session sees only its own rows | Yes | Yes |
| Application code | **No change** | Calls `SELECT <target>_gtt.dma_gtt_use('tmp_calc');` once per session before using the table. The GenAI conversion instructions already say so |
| Live monitor says | "Global temporary tables: N ready with the pgtt extension…" | "Global temporary tables: N ready as templates in schema …" |

**DBA steps for pgtt** (once per PostgreSQL server / database; DMA cannot do them itself):

1. Install the pgtt package for your PostgreSQL version from the PGDG repository (on RHEL its name looks like `pgtt_16`; the DBA checks with `dnf search pgtt`). **The PostgreSQL server must run the same minor version the package was built for**: after installing, restart PostgreSQL in a maintenance window.
2. In the target database: `CREATE EXTENSION pgtt;`
3. Let normal users load it: copy the library into the plugins folder: `mkdir -p $(pg_config --pkglibdir)/plugins && cp $(pg_config --pkglibdir)/pgtt.so $(pg_config --pkglibdir)/plugins/`
4. `GRANT USAGE, CREATE ON SCHEMA pgtt_schema TO <DMA user>;` and `GRANT USAGE ON SCHEMA pgtt_schema TO <application roles>;`
5. For the application's sessions: `ALTER DATABASE <db> SET session_preload_libraries = '$libdir/plugins/pgtt';` and add `pgtt_schema` to the application's `search_path` (e.g. `ALTER ROLE <app user> SET search_path = <schema>, pgtt_schema, public;`). New sessions only.

Without these steps everything still works with the templates. If pgtt is installed later, the next run creates the real ones (the templates stay; you can drop schema `<target>_gtt` once the code no longer calls `dma_gtt_use`). To force templates even with pgtt: `DMA_GTT_PGTT=off` in the worker's environment.

**If a key or index of a global temporary table cannot be created**, the Live monitor says which one; the table itself is still created.

## Files

| | Files |
|---|---|
| `ora2pgservice/` new | `services/resourceGuard.js`, `services/runCompare.js` |
| `ora2pgservice/` changed | `services/migrate.js`, `services/preferences.js`, `services/sqlRunner.js`, `services/analysis.js`, `services/code.js`, `controllers/projectController.js`, `controllers/runController.js`, `routes/projectRoutes.js` |
| `ora2pgservice/` tests | new `tests/unit/batch14.test.js`, `tests/e2e/batch14.e2e.test.js` |
| `ora2pgui/` new | `src/components/RunDetails.tsx`, `src/pages/RunComparePage.tsx` |
| `ora2pgui/` changed | `src/App.tsx`, `src/prefs.ts`, `src/pages/ProjectsPage.tsx`, `src/pages/RunsPage.tsx`, `src/pages/RunPage.tsx` |
| `ora2pgui/` tests | new `tests/unit/batch14.test.tsx`, `tests/e2e/batch14.spec.ts`; changed `tests/e2e/flow.spec.ts` |

## Deploy

1. Before copying: keep a copy of your current `ora2pgservice` and `ora2pgui` folders (way back in two minutes).
2. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
3. In `ora2pgservice`, run `npm test`. It should end with **Tests: 143 passed**.
4. In `ora2pgui`, run `npm test` (should end with **58 passed**), then `npm run build`, then copy `index.html` and the build to nginx as usual.
5. On RHEL, **when no migration runs**:
   ```bash
   pm2 restart ora2pg-service-prod
   ```
   ```bash
   pm2 restart ora2pg-worker-prod
   ```
6. Press Ctrl+F5 in the browser.

## Test on RHEL

- [ ] **Copy project:** All projects → copy icon on E780 → pick another schema → Copy project. The copy opens at Schema & snapshot; **Take snapshot** works (same connections). Settings show the same run defaults, target schema empty.
- [ ] **Run details:** Live monitor list → click ⓘ on any new run → the popup shows options, decisions, versions, time per phase → Close.
- [ ] **Simpler run page:** open a new run: no "Where did the time go?" section. (Admin: My preferences → switch it on → it appears.)
- [ ] **Compare runs:** Live monitor list → tick two runs → Compare the 2 runs: differences marked.
- [ ] **Guard:** nothing to do on a healthy server; the run page shows no notice. (Optional: on a test server, start the worker with `DMA_GUARD_MIN_FREE_MB=999999` for one run: the yellow notice appears, and after 10 minutes the run continues on its own; remove the setting afterwards.)
- [ ] **Global temporary tables** (if the schema has any): the Live monitor says "Global temporary tables: N ready …". In SQL Workbench (PostgreSQL): without pgtt `SELECT * FROM <target>_gtt.<table>;` (empty template); with pgtt `SELECT * FROM pgtt_schema.pg_global_temp_tables;`.

## Tested on the Mac (real databases)

Test data (`dev-tools/testdb/08_batch14.sql` and TMP_CALC): a global temporary table that keeps its rows until the session ends (primary key, default) and one that deletes them at commit.

| Proof | Result |
|---|---|
| Copy project | Copy for ACMM_REMOTE created; its own snapshot taken through the copied connections; settings copied, hand-set target schema cleared; wrong name / unknown schema / existing name refused |
| Run details / compare | Two runs with a different "tries per table" and "keep microseconds": both marked as differences; a table only in the second run shown as such |
| Guard | Worker told memory was short for the first 15 s: "Server memory is short… no new work" at 12:12:40, "back to normal" at 12:12:55, the first table started only then; run COMPLETED, "waited 2 times, 15 s" |
| GTT with pgtt | Both tables in pgtt_schema, primary key on the definition; two real sessions: each sees only its own rows, the same key allowed in both, rows deleted at commit for TMP_CALC, kept for the other |
| GTT without pgtt | Templates in e2e_b14_gtt and dma_gtt_use(): same session results as with pgtt; the template itself stays empty |
| Run details popup | Live monitor list → ⓘ on a run → popup with options, decisions, versions, time per phase → Close: back on the list; the run page has no Run details section |
| Simpler run page | "Where did the time go?" off for a new user; an admin who switches it on keeps it |

**Tests on the final code:**

| Suite | Result |
|---|---|
| ora2pgservice unit tests (`npm test`) | 143 passed |
| ora2pgservice API tests against the real Oracle and PostgreSQL | 81 passed, 4 skipped (need a special test server set-up) |
| ora2pgui unit tests (`npm test`) | 58 passed |
| ora2pgui browser tests (Playwright, real API) | 35 passed |
| ora2pgui build | OK |
