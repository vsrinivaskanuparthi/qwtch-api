const express = require("express");
const projectController = require('../controllers/projectController');
const oracleController = require('../controllers/oracleController');
const pgController = require('../controllers/pgController');
const runController = require('../controllers/runController');
const settingsController = require('../controllers/settingsController');
const codeController = require('../controllers/codeController');
const analysisController = require('../controllers/analysisController');
const { loadProject } = require('../middleware/project');
const { isAdmin, requireAdmin } = require('../utils/roles');
const store = require('../services/projectStore');
const {
  validateSetupProjectRequest,
  validateCreateRequest,
  validatePgRequest,
  validateSchemaSelectRequest,
} = require('../middleware/validation');

const { safeRouter, errorResponder } = require('../utils/asyncRoute');

// Every handler is wrapped: a failure always gets a clear answer (see utils/asyncRoute.js).
const router = safeRouter(express.Router());

// Who is signed in, and whether they are a DMA admin (Settings, advanced options, detailed analysis).
router.get("/whoami", (req, res) => res.json({ user: store.userOf(req), admin: isAdmin(req) }));

// The bell in the header: running runs and runs that ended in the last 14 days, all projects.
router.get("/notifications", async (req, res) => {
  try {
    res.json({ items: await require('../services/recentRuns').recentRuns() });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// This server's CPU and memory now (Live monitor).
router.get("/server-usage", async (req, res) => {
  try {
    res.json(await require('../services/serverUsage').serverUsage());
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// The signed-in user's own display preferences (account menu → My preferences).
router.get("/preferences", async (req, res) => {
  try {
    res.json({ preferences: await require('../services/preferences').getPreferences(store.userOf(req)) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
router.put("/preferences", async (req, res) => {
  try {
    res.json({ preferences: await require('../services/preferences').savePreferences(store.userOf(req), req.body && req.body.preferences) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- Projects ----
router.get("/projects", projectController.getMyProjects);
router.post("/projects", validateSetupProjectRequest, projectController.projectSetup);

// Everything below works on one project: /api/projects/:projectName/...
const p = safeRouter(express.Router({ mergeParams: true }));
router.use("/projects/:projectName", loadProject, p);

p.get("/", projectController.getProject);
p.patch("/", projectController.updateProject);
p.delete("/", projectController.deleteProject);              // removes the project folder (all ora2pg files, runs, logs)
p.post("/rename", requireAdmin, projectController.renameProject);
p.post("/copy", projectController.copyProject);            // DMA-057: same connections, another schema
p.get("/events", projectController.projectEvents);          // live updates (Server-Sent Events)
p.post("/columns", requireAdmin, projectController.dbColUpdate);          // reserved-word column renames

// Source (Oracle)
p.post("/oracle/connect", validateCreateRequest, oracleController.create);
p.post("/oracle/disconnect", oracleController.disconnect);
p.get("/oracle/schemas", oracleController.listSchemas);
p.post("/schema", validateSchemaSelectRequest, oracleController.selectSchema);
p.post("/snapshot", oracleController.startSnapshot);
p.get("/snapshot", oracleController.getSnapshot);
p.get("/prerequisites", oracleController.analyzePrerequisites);

// Target (PostgreSQL)
p.post("/postgres/connect", validatePgRequest, pgController.connectPg);
p.post("/postgres/disconnect", pgController.disconnectPg);
p.get("/postgres/checks", pgController.targetChecks);
p.get("/validation", pgController.executePg);

// Project settings (ora2pg options, LOB storage, engine defaults)
p.get("/settings", settingsController.getSettings);
p.put("/settings", requireAdmin, settingsController.saveSettings);
p.get("/settings/preview", settingsController.previewConfig);
p.post("/settings/notifications/test", settingsController.testNotification);
// Notifications (the bell): open to every user of the project, unlike the rest of Settings.
p.get("/notifications", settingsController.getNotifications);
p.put("/notifications", settingsController.saveNotifications);

// Code objects: GenAI export zip, converted package upload / apply, DB link mapping
p.get("/code", codeController.overview);
p.post("/code/exports", codeController.startExport);
p.post("/code/check", codeController.startCheck);                       // DMA-086: DMA first, GenAI only for what fails
p.post("/code/check/:id/apply", codeController.applyCheck);
p.get("/code/check/:id/genai.zip", codeController.downloadCheckZip);
p.get("/code/exports/:id/download", codeController.downloadExport);
// Uploaded in pieces of < 1 MB, so proxies with default body limits (nginx: 1 MB) need no change.
p.post("/code/packages/part", express.raw({ type: () => true, limit: '2mb' }), codeController.uploadPart);
p.post("/code/packages", express.raw({ type: ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'], limit: '500mb' }), codeController.uploadPackage);
p.get("/code/packages/:id", codeController.getPackage);
p.delete("/code/packages/:id", codeController.deletePackage);
p.post("/code/packages/:id/apply", codeController.applyPackage);
p.put("/code/dblinks", codeController.saveDbLinks);
p.post("/code/dblinks/test", codeController.testDbLink);
p.post("/code/dblinks/create", codeController.createDbLinks);
p.post("/code/dblinks/:name/remove", codeController.removeDbLink);

// SQL Workbench: queries on the project's PostgreSQL (read-only unless an admin confirms a change)
// and Oracle (SELECT only); every query is kept in the project's SQL history.
const sqlWorkbench = require('../services/sqlWorkbench');
p.post("/sql", async (req, res) => {
  try {
    const { target, sql, allowWrite, maxRows, timeoutSec } = req.body || {};
    res.json(await sqlWorkbench.run(req.projectName, req.project, { target, sql, allowWrite, maxRows, timeoutSec }, { user: store.userOf(req), admin: isAdmin(req) }));
  } catch (err) {
    res.status(err.status && err.status < 500 ? err.status : 400).json({ message: err.message, statement: err.statement || null, position: err.position || null, hint: err.hint || null, done: err.done || 0 });
  }
});
p.get("/sql/history", async (req, res) => {
  try {
    res.json({ items: await sqlWorkbench.history(req.projectName, { user: store.userOf(req), admin: isAdmin(req) }) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
p.get("/sql/objects", async (req, res) => {
  try {
    res.json(await sqlWorkbench.objects(req.projectName, req.project, req.query.target === 'oracle' ? 'oracle' : 'postgres'));
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Migration analysis report (ora2pg SHOW_REPORT + complexity checks)
p.get("/analysis", analysisController.overview);
p.post("/analysis", analysisController.start);
p.get("/analysis/:id", analysisController.getReport);
p.get("/analysis/:id/download/:kind", analysisController.download);

// Migration runs
p.get("/runs", runController.listRuns);
p.get("/sizing", runController.sizingInfo);              // migration server: cores, RAM, staging disk vs needs
p.post("/runs/preflight", runController.preflightRun);  // capacity checks for the planned run
p.post("/runs", runController.startRun);
p.get("/runs/compare", runController.compareRuns);       // DMA-077: ?a=<runId>&b=<runId>
p.get("/runs/:runId/details", runController.runDetails); // DMA-077: what the run used
p.get("/runs/:runId", runController.getRun);
p.post("/runs/:runId/resume", runController.resumeRun);
p.post("/runs/:runId/cancel", runController.cancelRun);
p.get("/runs/:runId/logs/:kind", runController.downloadLog);

// One answer for every failure: message, DMA error code and a reference written to the log.
router.use(errorResponder);

module.exports = router;
