'use strict';

/**
 * DMA-086 "Convert with DMA first": the parts that need no database.
 *   fixSql      the mechanical fixes DMA makes to ora2pg's code
 *   leftovers   Oracle code ora2pg left in the converted text
 *   readObjects ora2pg's export folders → one object each
 *   classify    the status of each object, dependencies and packages
 * The real check against Oracle and PostgreSQL: tests/e2e/codeAuto.e2e.test.js.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

process.env.MIGRATION_STAGING_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-code-'));
jest.mock('../../utils/logger', () => ({ info: jest.fn(), warn: jest.fn(), error: jest.fn(), debug: jest.fn() }));
const { fixSql, leftovers, readObjects, classify, cleanText } = require('../../services/codeAuto');

afterAll(() => fs.rmSync(process.env.MIGRATION_STAGING_DIR, { recursive: true, force: true }));

describe('fixSql: the mechanical fixes', () => {
  test('reserved-word columns ora2pg wrote in upper case become lower case (names are lower case)', () => {
    const r = fixSql('select coalesce(sum(r."VALUE"), 0) from customized_rank r where "OFFSET" > 0');
    expect(r.sql).toBe('select coalesce(sum(r."value"), 0) from customized_rank r where "offset" > 0');
    expect(r.fixes).toEqual(['reserved-word column in lower case']);
  });

  test('with "Preserve case" on, upper-case names are right and kept', () => {
    expect(fixSql('select "VALUE" from "STATION"', { preserveCase: true })).toEqual({ sql: 'select "VALUE" from "STATION"', fixes: [] });
  });

  test('table@LINK becomes the DB link\'s schema, only for a mapped link', () => {
    const r = fixSql('select * from customer_src@acmm_link r join other@unknown_link o on 1=1', { links: { ACMM_LINK: 'link_acmm_link' } });
    expect(r.sql).toBe('select * from link_acmm_link.customer_src r join other@unknown_link o on 1=1');
    expect(r.fixes).toEqual(['table@LINK → DB link schema']);
  });

  test('an INSTEAD OF trigger gets FOR EACH ROW; one that has it is unchanged', () => {
    const r = fixSql('CREATE TRIGGER t\n\tINSTEAD OF UPDATE ON station_v \tEXECUTE PROCEDURE f();');
    expect(r.sql).toMatch(/INSTEAD OF UPDATE ON station_v FOR EACH ROW EXECUTE PROCEDURE f\(\)/);
    expect(fixSql('CREATE TRIGGER t INSTEAD OF UPDATE ON v FOR EACH ROW EXECUTE PROCEDURE f();').fixes).toEqual([]);
  });

  test('nothing to fix: unchanged', () => {
    expect(fixSql('select a from b')).toEqual({ sql: 'select a from b', fixes: [] });
  });
});

describe('leftovers: Oracle code ora2pg could not convert', () => {
  test.each([
    ['select * bulk collect into l from t', 'BULK COLLECT'],
    ['forall i in 1 .. l.count update t set a = 1', 'FORALL'],
    ['JOIN cte c ON (c.prior plan_id = parent_plan_id)', 'CONNECT BY / PRIOR'],
    ['COMPOUND UPDATE OF status ON orders', 'compound trigger'],
    ['x := dbms_lob.getlength(c);', 'DBMS_ / UTL_ package'],
    ['type t_ids is table of numeric index by integer;', 'PL/SQL collection type'],
    ['PERFORM * FROM dblink(v_conn, v_q) AS p (ret boolean);', 'autonomous transaction (dblink)'],
    ['select * from t@remote', 'table@LINK'],
  ])('%s → %s', (sql, label) => {
    expect(leftovers(sql)).toContain(label);
  });

  test('clean PostgreSQL code has none', () => {
    expect(leftovers("CREATE FUNCTION f() RETURNS numeric AS $body$ BEGIN RETURN 1; END; $body$ LANGUAGE plpgsql")).toEqual([]);
  });
});

describe('readObjects: ora2pg\'s export as objects', () => {
  const src = path.join(process.env.MIGRATION_STAGING_DIR, 'src');
  const write = (rel, text) => { fs.mkdirSync(path.dirname(path.join(src, rel)), { recursive: true }); fs.writeFileSync(path.join(src, rel), text); };
  beforeAll(() => {
    write('views/views.sql', 'SET search_path = app,public;\nCREATE OR REPLACE VIEW v_a (x) AS select 1;\nCREATE OR REPLACE VIEW v_b (y) AS select x from v_a;\n');
    write('mviews/mviews.sql', 'CREATE MATERIALIZED VIEW mv_a AS\nselect 1 x;\nCREATE INDEX ix1 ON mv_a (x);\nCREATE MATERIALIZED VIEW mv_b AS\nselect 2 y;\n');
    write('functions/F1_functions.sql', 'SET search_path = app,public;\nCREATE OR REPLACE FUNCTION f1 () RETURNS int AS $body$ BEGIN RETURN 1; END; $body$ LANGUAGE plpgsql;\n');
    write('functions/functions.sql', '\\i /x/F1_functions.sql\n');
    write('packages/packages.sql', 'DROP SCHEMA IF EXISTS pkg CASCADE;\nCREATE SCHEMA IF NOT EXISTS pkg;\n');
    write('packages/pkg/run_packages.sql', 'SET search_path = app,pkg,public;\nCREATE OR REPLACE PROCEDURE pkg.run () AS $body$ BEGIN NULL; END; $body$ LANGUAGE plpgsql;\n');
    write('triggers/TRG_A_triggers.sql', 'DROP TRIGGER IF EXISTS trg_a ON t CASCADE;\nCREATE TRIGGER trg_a BEFORE INSERT ON t FOR EACH ROW EXECUTE PROCEDURE f1();\n');
  });

  test('one object per view, materialized view (with its index), routine, package routine and trigger', () => {
    const objs = readObjects(src);
    expect(objs.map((o) => `${o.kind}:${o.name}:${o.oracleName}`)).toEqual([
      'view:v_a:V_A', 'view:v_b:V_B', 'materialized view:mv_a:MV_A', 'materialized view:mv_b:MV_B',
      'function:f1:F1', 'package routine:pkg.run:PKG', 'trigger:trg_a:TRG_A',
    ]);
    expect(objs.find((o) => o.name === 'mv_a').sql).toMatch(/CREATE INDEX ix1/);
    expect(objs.find((o) => o.name === 'pkg.run').pkg).toBe('pkg');
    expect(objs.every((o) => !/SET search_path|\\i |DROP SCHEMA/.test(o.sql))).toBe(true);
  });

  test('the first object of a file comes after ora2pg\'s header comments: it is kept', () => {
    write('views/views.sql', '-- Generated by Ora2Pg\n-- Copyright\n\nSET search_path = app,public;\n\nCREATE OR REPLACE VIEW first_v (x) AS select 1\n    FROM dual_t;\n\nCREATE OR REPLACE VIEW second_v (y) AS select 2;\n');
    expect(readObjects(src).filter((o) => o.kind === 'view').map((o) => o.name)).toEqual(['first_v', 'second_v']);
  });

  test('cleanText never keeps a DROP SCHEMA', () => {
    expect(cleanText('DROP SCHEMA IF EXISTS pkg CASCADE;\nCREATE SCHEMA pkg;')).toBe('CREATE SCHEMA pkg;');
  });
});

describe('classify: statuses, dependencies and packages', () => {
  const o = (x) => ({ kind: 'view', leftovers: [], created: true, ...x });
  const ctx = {
    oracleTables: new Set(['orders', 'station']),
    deps: new Map([['V_TOP', new Set(['V_BASE'])], ['F_CALL', new Set(['F_BAD'])], ['V_SYN', new Set(['REMOTE_SYN'])]]),
    synonyms: new Set(['REMOTE_SYN']),
  };

  test('a view with the same number of rows as Oracle is ready; a different count needs GenAI', () => {
    const [a, b] = classify([o({ name: 'v1', oracleName: 'V1', pgRows: 5, oraRows: 5 }), o({ name: 'v2', oracleName: 'V2', pgRows: 4, oraRows: 5 })], ctx);
    expect(a).toMatchObject({ status: 'ready', reason: expect.stringMatching(/Same number of rows .*\(5\)/) });
    expect(b).toMatchObject({ status: 'genai', reason: 'Different result: Oracle 5 rows, PostgreSQL 4' });
  });

  test('functions, procedures and triggers that are created are ready but not compared', () => {
    expect(classify([o({ kind: 'function', name: 'f', oracleName: 'F' })], ctx)[0]).toMatchObject({ status: 'ready_unproven', reason: expect.stringMatching(/not compared with Oracle/) });
  });

  test('created but with Oracle code left in it: GenAI', () => {
    expect(classify([o({ kind: 'procedure', name: 'p', oracleName: 'P', leftovers: ['BULK COLLECT'] })], ctx)[0]).toMatchObject({ status: 'genai', reason: expect.stringMatching(/BULK COLLECT/) });
  });

  test('a missing table of the schema: waits for the table, not GenAI', () => {
    expect(classify([o({ name: 'v', oracleName: 'V', created: false, error: 'relation "orders" does not exist' })], ctx)[0]).toMatchObject({ status: 'needs_table', reason: expect.stringMatching(/Table orders is not migrated yet/) });
  });

  test('a DB link: waits for the link to be created or mapped', () => {
    expect(classify([o({ name: 'v', oracleName: 'V', created: false, error: 'relation "link_acmm_link.customer_src" does not exist' })], ctx)[0].status).toBe('needs_link');
    expect(classify([o({ name: 'v', oracleName: 'V', created: false, error: 'syntax error at or near "@"', leftovers: ['table@LINK'] })], ctx)[0].status).toBe('needs_link');
  });

  test('a remote synonym ora2pg does not convert: GenAI, with the synonym named', () => {
    expect(classify([o({ name: 'v_syn', oracleName: 'V_SYN', created: false, error: 'relation "remote_syn" does not exist' })], ctx)[0]).toMatchObject({ status: 'genai', reason: 'Uses synonym REMOTE_SYN, which ora2pg does not convert' });
  });

  test('refused by PostgreSQL: GenAI with the error', () => {
    expect(classify([o({ kind: 'trigger', name: 't', oracleName: 'T', created: false, error: 'syntax error at or near "COMPOUND"' })], ctx)[0]).toMatchObject({ status: 'genai', reason: 'PostgreSQL refused it: syntax error at or near "COMPOUND"' });
  });

  test('dependencies: an object that uses one needing GenAI goes with it, even if it was created', () => {
    const objs = classify([
      o({ kind: 'function', name: 'f_bad', oracleName: 'F_BAD', leftovers: ['FORALL'] }),
      o({ kind: 'function', name: 'f_call', oracleName: 'F_CALL' }),
      o({ name: 'v_base', oracleName: 'V_BASE', created: false, error: 'syntax error' }),
      o({ name: 'v_top', oracleName: 'V_TOP', pgRows: 1, oraRows: 1 }),
    ], ctx);
    expect(objs.find((x) => x.name === 'f_call')).toMatchObject({ status: 'genai', dependsOn: 'f_bad', reason: expect.stringMatching(/Uses f_bad, which needs GenAI/) });
    expect(objs.find((x) => x.name === 'v_top')).toMatchObject({ status: 'genai', dependsOn: 'v_base' });
  });

  test('packages go as a whole when one routine needs GenAI', () => {
    const objs = classify([
      o({ kind: 'package routine', name: 'pkg.good', oracleName: 'PKG', pkg: 'pkg' }),
      o({ kind: 'package routine', name: 'pkg.bad', oracleName: 'PKG', pkg: 'pkg', created: false, error: 'syntax error at or near "is"' }),
      o({ kind: 'package routine', name: 'other.ok', oracleName: 'OTHER', pkg: 'other' }),
    ], ctx);
    expect(objs.find((x) => x.name === 'pkg.good')).toMatchObject({ status: 'genai', reason: expect.stringMatching(/Part of package pkg: pkg.bad needs GenAI/) });
    expect(objs.find((x) => x.name === 'other.ok').status).toBe('ready_unproven');
  });

  test('refused because another object of the list is missing: it uses that one and goes with it', () => {
    const objs = classify([
      o({ kind: 'materialized view', name: 'mv_base', oracleName: 'MV_BASE', created: false, error: 'syntax error', leftovers: ['ROWNUM'] }),
      o({ kind: 'materialized view', name: 'mv_top', oracleName: 'MV_TOP', created: false, error: 'relation "mv_base" does not exist' }),
    ], ctx);
    expect(objs[1]).toMatchObject({ status: 'genai', dependsOn: 'mv_base', reason: 'Uses mv_base, which needs GenAI: they go together' });
  });

  test('Oracle code left in it wins over a missing table: GenAI, not "waiting for the table"', () => {
    expect(classify([o({ kind: 'trigger', name: 't', oracleName: 'T', created: false, error: 'relation "orders" does not exist', leftovers: ['compound trigger'] })], ctx)[0])
      .toMatchObject({ status: 'genai', reason: 'ora2pg left Oracle code in it: compound trigger' });
  });

  test('an object already in PostgreSQL is kept, never replaced', () => {
    expect(classify([o({ name: 'v', oracleName: 'V', existsAlready: true, created: false })], ctx)[0]).toMatchObject({ status: 'exists', reason: expect.stringMatching(/keeps it and does not replace it/) });
  });
});
