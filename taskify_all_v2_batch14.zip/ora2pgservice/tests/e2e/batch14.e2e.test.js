'use strict';

/**
 * End-to-end, batch 14, on the running API and worker:
 *   DMA-057 Copy project: a copy for another schema uses the same connections (its snapshot works),
 *           takes over the settings but not the target schema, snapshot or runs; wrong input refused
 *   DMA-077 Run details and Compare runs: two real runs with a different option and decision
 *   DMA-085 global temporary tables (dev-tools/testdb: TMP_CALC deletes rows at commit,
 *           B14_GTT_SESSION keeps them, with a primary key and a default): created by every run,
 *           with pgtt when the target allows it, else as templates + dma_gtt_use(); checked with two
 *           real sessions (each sees only its own rows, keys and ON COMMIT behave as in Oracle)
 *   DMA-075 CPU / memory guard: only with DMA_E2E_GUARD=1, when the worker was started with
 *           DMA_GUARD_TEST_LOW_MEMORY_SECONDS (memory reported short for the first seconds): the run
 *           waits, says so, continues by itself and completes
 * Migrates into a scratch schema (DMA_E2E_B14_SCHEMA, default e2e_b14); settings are put back.
 */
const { Client } = require('pg');
const { API, P, call, apiUp, getSettings, saveSettings, migrate, loaded } = require('./helpers');

const TARGET = process.env.DMA_E2E_B14_SCHEMA || 'e2e_b14';
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
const COPY = `E2E_COPY_${Date.now()}`;
const maybe = process.env.DMA_E2E_PG_URL ? describe : describe.skip;
jest.setTimeout(20 * 60 * 1000);

maybe('Batch 14', () => {
  let pg;
  let saved;
  let source;

  beforeAll(async () => {
    await apiUp();
    saved = await getSettings();
    source = (await call('GET', P)).data.project;
    pg = new Client({ connectionString: process.env.DMA_E2E_PG_URL });
    await pg.connect();
  });

  afterAll(async () => {
    if (saved) await saveSettings(saved);
    await call('DELETE', `${API}/api/projects/${COPY}`, { confirm: COPY }).catch(() => {});
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`).catch(() => {});
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}_gtt" CASCADE`).catch(() => {});
      await pg.end();
    }
  });

  describe('DMA-057 Copy project', () => {
    const other = () => (source.schemas || []).find((s) => s !== source.selectedSchema && /REMOTE/.test(s)) || (source.schemas || []).find((s) => s !== source.selectedSchema);

    test('wrong input is refused and nothing is created', async () => {
      expect((await call('POST', `${P}/copy`, { newName: 'has space', schema: other() })).status).toBe(400);
      expect((await call('POST', `${P}/copy`, { newName: COPY })).data.message).toMatch(/Choose the Oracle schema/);
      expect((await call('POST', `${P}/copy`, { newName: COPY, schema: 'NO_SUCH_SCHEMA' })).data.message).toMatch(/not in this database/);
      expect((await call('POST', `${P}/copy`, { newName: PROJECT, schema: other() })).status).toBe(409);
      expect((await call('GET', `${API}/api/projects/${COPY}`)).status).toBe(404);
    });

    test('a copy for another schema: same connections, settings copied, own target schema, nothing of the old schema', async () => {
      await saveSettings({ ...saved, targetSchema: 'shared_target', engine: { ...saved.engine, parallelTables: 3 } });
      const r = await call('POST', `${P}/copy`, { newName: COPY, schema: other(), copySettings: true });
      expect(r.status).toBe(201);
      expect(r.data.message).toMatch(/was not copied: .* loads into/);
      const copy = (await call('GET', `${API}/api/projects/${COPY}`)).data.project;
      expect(copy).toMatchObject({ projectName: COPY, selectedSchema: other(), copiedFrom: PROJECT, migrationStatus: 'READY', currentMigrationId: null });
      expect(copy.oracle).toMatchObject({ userUrl: source.oracle.userUrl, userUsername: source.oracle.userUsername });
      expect(copy.postgres).toMatchObject({ hostip: source.postgres.hostip, dbname: source.postgres.dbname });
      expect(copy.oracle.password).toBeUndefined(); // never sent to the browser
      expect(copy.snapshotAt).toBeUndefined();
      const s = (await call('GET', `${API}/api/projects/${COPY}/settings`)).data.settings;
      expect(s.engine.parallelTables).toBe(3);
      expect(s.targetSchema).toBe('');
      expect((await call('GET', `${API}/api/projects/${COPY}/runs`)).data.runs).toEqual([]);
      expect((await call('POST', `${P}/copy`, { newName: COPY, schema: other() })).status).toBe(409);
    });

    test('the copy\'s connections work: its own snapshot of the other schema', async () => {
      const start = await call('POST', `${API}/api/projects/${COPY}/snapshot`, {});
      expect([200, 202]).toContain(start.status);
      let snap = null;
      for (let i = 0; i < 90 && !snap; i += 1) {
        await new Promise((res) => setTimeout(res, 2000));
        const g = await call('GET', `${API}/api/projects/${COPY}/snapshot`);
        if (g.status === 200 && g.data.tableMetadata) snap = g.data;
      }
      expect(snap.schemaName).toBe(other());
      expect(snap.tableMetadata.length).toBeGreaterThan(0);
    });

    test('settings can also stay at their defaults', async () => {
      const name = `${COPY}_D`;
      try {
        expect((await call('POST', `${P}/copy`, { newName: name, schema: other(), copySettings: false })).status).toBe(201);
        expect((await call('GET', `${API}/api/projects/${name}/settings`)).data.settings.engine.parallelTables).not.toBe(3);
      } finally {
        await call('DELETE', `${API}/api/projects/${name}`, { confirm: name });
      }
    });
  });

  describe('runs: DMA-085 global temporary tables, DMA-077 details and compare', () => {
    let first;
    let second;

    beforeAll(async () => {
      await saveSettings({ ...saved, targetSchema: TARGET, engine: { ...saved.engine, snapshot: 'off', maxAttempts: 3 } });
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}_gtt" CASCADE`);
      first = await migrate(pg, TARGET, ['PLANT']);
      await saveSettings({ ...saved, targetSchema: TARGET, engine: { ...saved.engine, snapshot: 'off', maxAttempts: 2 }, ora2pg: { ...saved.ora2pg, ENABLE_MICROSECOND: false } });
      second = await migrate(pg, TARGET, ['PLANT', 'CALENDAR_EXCEPTION']);
    });

    test('both runs complete', () => {
      for (const r of [first, second]) {
        expect(r.status).toBe('COMPLETED');
        loaded(r, 'PLANT');
      }
    });

    test('DMA-085: every run creates the global temporary tables, and says how', () => {
      expect(first.gtt.tables.map((t) => t.name).sort()).toEqual(['b14_gtt_session', 'tmp_calc']);
      expect(first.gtt.failed).toEqual([]);
      expect(first.gtt.tables.find((t) => t.name === 'b14_gtt_session').onCommit).toBe('PRESERVE');
      expect(first.gtt.tables.find((t) => t.name === 'tmp_calc').onCommit).toBe('DELETE');
      expect(first.events.map((e) => e.message).join('\n')).toMatch(/Global temporary tables: 2 ready/);
      expect(second.gtt.created + second.gtt.existing).toBe(2);
    });

    test('DMA-085: two sessions each see only their own rows; key, default and ON COMMIT as in Oracle', async () => {
      const mode = first.gtt.mode;
      const sessions = [new Client({ connectionString: process.env.DMA_E2E_PG_URL }), new Client({ connectionString: process.env.DMA_E2E_PG_URL })];
      await Promise.all(sessions.map((c) => c.connect()));
      try {
        for (const c of sessions) {
          if (mode === 'pgtt') {
            await c.query("LOAD '$libdir/plugins/pgtt'").catch(() => c.query("LOAD 'pgtt'"));
            await c.query(`SET search_path = "${TARGET}", pgtt_schema, public`);
          } else {
            await c.query(`SET search_path = "${TARGET}", public`);
            await c.query(`SELECT "${TARGET}_gtt".dma_gtt_use('b14_gtt_session')`);
            await c.query(`SELECT "${TARGET}_gtt".dma_gtt_use('tmp_calc')`);
          }
        }
        const [a, b] = sessions;
        await a.query("INSERT INTO b14_gtt_session (session_key, note) VALUES ('k1', 'session A')");
        expect((await a.query('SELECT step FROM b14_gtt_session')).rows).toEqual([{ step: 1 }]); // the default
        await expect(a.query("INSERT INTO b14_gtt_session (session_key) VALUES ('k1')")).rejects.toThrow(/duplicate key/); // the primary key
        expect(Number((await b.query('SELECT count(*) FROM b14_gtt_session')).rows[0].count)).toBe(0); // A's rows are A's only
        await b.query("INSERT INTO b14_gtt_session (session_key) VALUES ('k1')"); // the same key in another session is fine
        await a.query('BEGIN');
        await a.query('INSERT INTO tmp_calc VALUES (1, 2)');
        expect(Number((await a.query('SELECT count(*) FROM tmp_calc')).rows[0].count)).toBe(1);
        await a.query('COMMIT');
        expect(Number((await a.query('SELECT count(*) FROM tmp_calc')).rows[0].count)).toBe(0); // ON COMMIT DELETE ROWS
        expect(Number((await a.query('SELECT count(*) FROM b14_gtt_session')).rows[0].count)).toBe(1); // ON COMMIT PRESERVE ROWS
      } finally {
        await Promise.all(sessions.map((c) => c.end()));
      }
    });

    test('DMA-077: Run details show what the run used', async () => {
      const d = (await call('GET', `${P}/runs/${second.runId}/details`)).data;
      const row = (key) => d.sections.flatMap((s) => s.rows).find((r) => r.key === key);
      expect(d.runs).toEqual([expect.objectContaining({ runId: second.runId, status: 'COMPLETED' })]);
      expect(row('targetSchema').values).toEqual([TARGET]);
      expect(row('tables').values[0]).toMatch(/^2 of 2 done/);
      expect(row('opt.maxAttempts').values).toEqual(['2']);
      expect(row('dec.ENABLE_MICROSECOND').values).toEqual(['off']);
      expect(row('dmaVersion').values[0]).toMatch(/^\d+\.\d+\.\d+$/);
      expect(row('ora2pgVersion').values[0]).toMatch(/^\d+\.\d+$/);
      expect(Number(row('pgMajor').values[0])).toBeGreaterThanOrEqual(12);
      expect(row('gtt').values[0]).toMatch(/^2 ready/);
    });

    test('DMA-077: Compare runs marks what differs between the two runs', async () => {
      const d = (await call('GET', `${P}/runs/compare?a=${first.runId}&b=${second.runId}`)).data;
      const row = (key) => d.sections.flatMap((s) => s.rows).find((r) => r.key === key);
      expect(d.runs.map((r) => r.runId)).toEqual([first.runId, second.runId]);
      expect(row('opt.maxAttempts')).toMatchObject({ values: ['3', '2'], diff: true });
      expect(row('dec.ENABLE_MICROSECOND')).toMatchObject({ values: ['on', 'off'], diff: true });
      expect(row('targetSchema').diff).toBe(false);
      expect(d.tables.find((t) => t.name === 'CALENDAR_EXCEPTION')).toMatchObject({ values: [null, expect.objectContaining({ status: 'done' })], diff: true });
      expect(d.tables.find((t) => t.name === 'PLANT').values.every((v) => v && v.status === 'done')).toBe(true);
    });

    test('DMA-077: wrong compare requests are answered clearly', async () => {
      expect((await call('GET', `${P}/runs/compare?a=${first.runId}&b=${first.runId}`)).status).toBe(400);
      expect((await call('GET', `${P}/runs/compare?a=${first.runId}&b=19990101-000000`)).status).toBe(404);
      expect((await call('GET', `${P}/runs/19990101-000000/details`)).status).toBe(404);
    });

    test('DMA-075: a normal run reports a healthy server and never waited', () => {
      expect(first.guard).toMatchObject({ status: 'ok' });
      if (process.env.DMA_E2E_GUARD !== '1') expect(first.guard.pauses).toBe(0);
    });
  });

  (process.env.DMA_E2E_GUARD === '1' ? test : test.skip)('DMA-075: memory short at the start: the run waits, says so, continues and completes', async () => {
    await saveSettings({ ...saved, targetSchema: TARGET, engine: { ...saved.engine, snapshot: 'off' } });
    const r = await migrate(pg, TARGET, ['PLANT', 'CALENDAR_EXCEPTION']);
    expect(r.status).toBe('COMPLETED');
    const said = r.events.map((e) => e.message).join('\n');
    expect(said).toMatch(/Server memory is short .*DMA starts no new work/);
    expect(said).toMatch(/Server load back to normal/);
    expect(r.guard.pauses).toBeGreaterThanOrEqual(1);
    expect(r.guard.pausedSeconds).toBeGreaterThan(0);
    // Nothing started while the memory was short: the first table began after the recovery.
    const back = r.events.find((e) => /back to normal/.test(e.message)).at;
    const firstLoad = r.events.find((e) => /^Loading table/.test(e.message)).at;
    expect(new Date(firstLoad) >= new Date(back)).toBe(true);
  });
});
