'use strict';

/**
 * End-to-end: "Convert with DMA first" (DMA-086) on the test schema's real code objects.
 * Some tables are migrated into a scratch target (DMA_E2E_CODE_SCHEMA, default e2e_codeauto); ORDERS_BIG
 * is left out on purpose. Then:
 *   - the check changes nothing in PostgreSQL, and gives each object the right status and reason:
 *     views proven with Oracle's row count, a view waiting for ORDERS_BIG, views waiting for the DB
 *     link, a remote synonym, a materialized view that depends on another, a whole package to GenAI,
 *     a compound trigger, a trigger DMA fixed (INSTEAD OF … FOR EACH ROW)
 *   - "Create the ready objects" creates exactly those; a trigger created by DMA really works
 *   - the GenAI zip holds only the objects that need GenAI, with the reasons and the package schema
 *   - a second check keeps what is already in PostgreSQL, never replaces it
 * The project's settings are put back at the end. Needs DMA_E2E_PG_URL.
 */
const { Client } = require('pg');
const AdmZip = require('adm-zip');
const { API, P, call, apiUp, getSettings, saveSettings, migrate, loaded } = require('./helpers');

const TARGET = process.env.DMA_E2E_CODE_SCHEMA || 'e2e_codeauto';
const TABLES = ['STATION', 'PLANT', 'SPARE_PART', 'CALENDAR_EXCEPTION', 'CUSTOMIZED_RANK', 'PLAN_PE'];
const maybe = process.env.DMA_E2E_PG_URL ? describe : describe.skip;
jest.setTimeout(20 * 60 * 1000);

async function runCheck() {
  const start = await call('POST', `${P}/code/check`, {});
  if (start.status !== 202) throw new Error(`Check not started: ${JSON.stringify(start.data)}`);
  for (;;) {
    await new Promise((r) => setTimeout(r, 3000));
    const { data } = await call('GET', `${P}/code`);
    if (!data.checkJob || data.checkJob.status !== 'RUNNING') {
      if (data.checkJob && data.checkJob.status === 'FAILED') throw new Error(data.checkJob.error);
      if (data.check && data.check.id === start.data.id) return data.check;
    }
  }
}

maybe('Code objects: DMA first, GenAI only for what fails', () => {
  let pg;
  let saved;
  let check;
  const one = async (sql, params) => Object.values((await pg.query(sql, params)).rows[0] || {})[0];
  const codeCount = async () => Number(await one(
    `SELECT (SELECT count(*) FROM pg_class WHERE relnamespace = $1::regnamespace AND relkind IN ('v', 'm'))
          + (SELECT count(*) FROM pg_proc WHERE pronamespace = $1::regnamespace)`, [TARGET]));
  const obj = (name) => check.objects.find((o) => o.name === name);

  beforeAll(async () => {
    await apiUp();
    saved = await getSettings();
    pg = new Client({ connectionString: process.env.DMA_E2E_PG_URL });
    await pg.connect();
    await saveSettings({ ...saved, targetSchema: TARGET, engine: { ...saved.engine, snapshot: 'off' } });
    const run = await migrate(pg, TARGET, TABLES);
    for (const t of TABLES) loaded(run, t);
  });

  afterAll(async () => {
    if (saved) await saveSettings(saved);
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`).catch(() => {});
      await pg.query('DROP SCHEMA IF EXISTS pb18_planning CASCADE').catch(() => {});
      await pg.end();
    }
  });

  test('the check changes nothing in PostgreSQL', async () => {
    expect(await codeCount()).toBe(0);
    check = await runCheck();
    expect(await codeCount()).toBe(0);
    expect(Number(await one(`SELECT count(*) FROM pg_namespace WHERE nspname = 'pb18_planning'`))).toBe(0);
    expect(check).toMatchObject({ target: TARGET, schema: expect.any(String) });
    expect(check.objects.length).toBeGreaterThanOrEqual(19);
  });

  test('views and a materialized view: proven with Oracle\'s row count', () => {
    for (const n of ['station_v', 'station_fast_mv']) expect(obj(n)).toMatchObject({ status: 'ready', reason: expect.stringMatching(/Same number of rows as in Oracle/) });
  });

  test('a view on a table not migrated yet waits for the table (not GenAI)', () => {
    expect(obj('v_order_status')).toMatchObject({ status: 'needs_table', reason: expect.stringMatching(/orders_big is not migrated yet/) });
  });

  test('views on a DB link wait for the link; a remote synonym and what depends on it go to GenAI', () => {
    expect(obj('operator').status).toBe('needs_link');
    // customer also reads CUSTOMER_MASTER, which this test does not migrate: the table is named first.
    expect(['needs_table', 'needs_link']).toContain(obj('customer').status);
    expect(obj('comac')).toMatchObject({ status: 'genai', reason: expect.stringMatching(/synonym SS10_THIRD/) });
    expect(obj('third_mv2')).toMatchObject({ status: 'genai', dependsOn: 'third_mv' });
  });

  test('a package goes to GenAI as a whole; Oracle code ora2pg left is named', () => {
    const pkg = check.objects.filter((o) => o.name.startsWith('pb18_planning.'));
    expect(pkg.length).toBe(5);
    expect(pkg.every((o) => o.status === 'genai')).toBe(true);
    expect(obj('pb18_planning.plan_tree').reason).toMatch(/CONNECT BY/);
    expect(obj('pb18_planning.recalc_station').reason).toMatch(/BULK COLLECT/);
    expect(obj('trg_orders_compound')).toMatchObject({ status: 'genai', reason: expect.stringMatching(/compound trigger/) });
  });

  test('functions, a procedure and triggers that PostgreSQL accepts are ready (not compared); DMA fixed one', () => {
    for (const n of ['annual_order_total', 'pb18_func_pcalweek_exception', 'adjust_stock', 'trg_plan_pe_bi']) expect(obj(n).status).toBe('ready_unproven');
    expect(obj('trg_station_v_io')).toMatchObject({ status: 'ready_unproven', fixes: ['INSTEAD OF trigger: FOR EACH ROW'] });
  });

  test('the GenAI zip: only what needs GenAI, with the reasons and the package schema', async () => {
    const res = await fetch(`${API}/api/projects/${process.env.DMA_E2E_PROJECT || 'E2E_TEST'}/code/check/${check.id}/genai.zip`);
    expect(res.status).toBe(200);
    const zip = new AdmZip(Buffer.from(await res.arrayBuffer()));
    const names = zip.getEntries().map((e) => e.entryName).sort();
    expect(names).toEqual(expect.arrayContaining(['DMA_CHECK.md', 'CONVERSION_GUIDE.md', 'manifest.json', 'views/comac.sql', 'mviews/third_mv2.sql', 'packages/pb18_planning.sql', 'triggers/TRG_ORDERS_COMPOUND_triggers.sql']));
    expect(names.some((n) => /station_v|annual_order_total|ADJUST_STOCK|customer\.sql/i.test(n))).toBe(false);
    const md = zip.readAsText('DMA_CHECK.md');
    expect(md).toMatch(/\| comac \| view \| Uses synonym SS10_THIRD/);
    expect(md).toMatch(/Already in PostgreSQL, converted by DMA[\s\S]*- station_v \(view\)/);
    expect(zip.readAsText('packages/pb18_planning.sql')).toMatch(/CREATE SCHEMA IF NOT EXISTS "pb18_planning"/);
  });

  test('"Create the ready objects" creates exactly those, and a trigger created by DMA works', async () => {
    const r = await call('POST', `${P}/code/check/${check.id}/apply`, {});
    expect(r.status).toBe(200);
    const ready = check.objects.filter((o) => o.status === 'ready' || o.status === 'ready_unproven').length;
    expect(r.data.applied).toMatchObject({ created: ready, failed: [] });
    expect(r.data.objects.filter((o) => o.status === 'created').length).toBe(ready);
    expect(Number(await one(`SELECT count(*) FROM "${TARGET}".station_v`))).toBeGreaterThan(0);
    // The INSTEAD OF trigger DMA fixed: an update through the view changes the table.
    await pg.query('BEGIN');
    try {
      const id = await one(`SELECT min(station_id) FROM "${TARGET}".station`);
      await pg.query(`UPDATE "${TARGET}".station_v SET station_name = 'changed by test' WHERE station_id = $1`, [id]);
      expect(await one(`SELECT station_name FROM "${TARGET}".station WHERE station_id = $1`, [id])).toBe('changed by test');
    } finally {
      await pg.query('ROLLBACK');
    }
    expect(Number(await one(`SELECT count(*) FROM pg_namespace WHERE nspname = 'pb18_planning'`))).toBe(0); // the package went to GenAI
  });

  test('a second check keeps what is already in PostgreSQL, never replaces it', async () => {
    const again = await runCheck();
    expect(again.objects.find((o) => o.name === 'station_v')).toMatchObject({ status: 'exists', reason: expect.stringMatching(/does not replace it/) });
    expect(again.objects.filter((o) => o.status === 'ready' || o.status === 'ready_unproven')).toEqual([]);
  });

  test('functions DMA creates find their tables whatever the caller\'s search_path is', async () => {
    const cfg = await one(`SELECT array_to_string(proconfig, ',') FROM pg_proc WHERE pronamespace = $1::regnamespace AND proname = 'adjust_stock'`, [TARGET]);
    expect(cfg).toMatch(new RegExp(`search_path=.*${TARGET}`));
  });

  test('wrong requests are answered clearly', async () => {
    expect((await call('POST', `${P}/code/check/19990101-000000/apply`, {})).status).toBe(404);
    expect((await call('GET', `${P}/code/check/19990101-000000/genai.zip`)).status).toBe(404);
  });
});

maybe('Code objects converted by DMA as part of the migration', () => {
  const TARGET2 = `${TARGET}_run`;
  let pg;
  let saved;
  let run;
  const start = async (body) => {
    await pg.query(`DROP SCHEMA IF EXISTS "${TARGET2}" CASCADE`);
    const r = await call('POST', `${P}/runs`, body);
    if (r.status !== 202) throw new Error(`Run not started: ${JSON.stringify(r.data)}`);
    for (;;) {
      await new Promise((res) => setTimeout(res, 3000));
      const { data } = await call('GET', `${P}/runs/${r.data.runId}`);
      if (['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED'].includes(data.status)) return data;
    }
  };

  beforeAll(async () => {
    await apiUp();
    saved = await getSettings();
    pg = new Client({ connectionString: process.env.DMA_E2E_PG_URL });
    await pg.connect();
    await saveSettings({ ...saved, targetSchema: TARGET2, engine: { ...saved.engine, snapshot: 'off' } });
    run = await start({ tables: TABLES, createCode: true });
  });

  afterAll(async () => {
    if (saved) await saveSettings(saved);
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET2}" CASCADE`).catch(() => {});
      await pg.end();
    }
  });

  test('with the tick box: the run completes and creates the code objects DMA converted, and says so', async () => {
    expect(run.status).toBe('COMPLETED');
    expect(run.createCode).toBe(true);
    expect(run.codeAuto).toMatchObject({ checkId: expect.stringMatching(/^\d{8}-\d{6}$/), created: 7, createFailed: 0, genai: expect.any(Number), waiting: expect.any(Number) });
    expect(run.codeAuto.genai).toBeGreaterThan(0);
    expect(run.events.map((e) => e.message).join('\n')).toMatch(/Code objects: 7 created by DMA, \d+ need GenAI/);
    const views = (await pg.query(`SELECT relname FROM pg_class WHERE relnamespace = $1::regnamespace AND relkind IN ('v', 'm') ORDER BY 1`, [TARGET2])).rows.map((r) => r.relname);
    expect(views).toEqual(['station_fast_mv', 'station_v']);
    expect(run.phases.find((p) => p.key === 'code').status).toBe('done');
  });

  test('Run details show it', async () => {
    const d = (await call('GET', `${P}/runs/${run.runId}/details`)).data;
    const row = d.sections.flatMap((s) => s.rows).find((r) => r.key === 'codeAuto');
    expect(row.values[0]).toMatch(/^7 created, \d+ for GenAI/);
  });

  test('without the tick box (the API\'s default): no code objects, the code step is skipped', async () => {
    const plain = await start({ tables: ['PLANT'] });
    expect(plain.status).toBe('COMPLETED');
    expect(plain.codeAuto).toBeUndefined();
    expect(plain.phases.find((p) => p.key === 'code').status).toBe('skipped');
  });
});
