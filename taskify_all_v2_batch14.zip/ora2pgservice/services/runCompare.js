'use strict';

/**
 * Run details and run comparison (DMA-077): what a run used (tables, options, decisions, target
 * schema, snapshot, versions) and how two runs differ. Pure functions over saved run states, so the
 * Run page (one run) and the Compare page (two runs) show the same lines.
 *
 *   describeRuns([stateA])         → { runs, sections, tables }   (Run details)
 *   describeRuns([stateA, stateB]) → the same with two values per line and `diff` set where they differ
 *
 * sections: [{ title, rows: [{ key, label, values: [a, b?], diff }] }]
 * tables:   [{ name, values: [{ status, rows, seconds, attempts } | null, …], diff }]
 * Runs started before this version did not record their settings: those lines say "not recorded".
 */

const NOT_RECORDED = 'not recorded';

const OPTION_LABELS = {
  loadMode: 'Load mode',
  parallelTables: 'Tables at a time',
  hugeTableRows: 'Huge table from (rows)',
  oracleCopies: 'Oracle readers per huge table',
  pgJobs: 'PostgreSQL writers per huge table',
  chunkRows: 'Rows per part',
  chunkMb: 'MB per part',
  maxAttempts: 'Tries per table',
  ddlParallel: 'Indexes / keys at a time',
  maintenanceWorkMem: 'Memory per index build',
  verifyRowCounts: 'Row counts checked',
  verifyData: 'Column checksums',
  snapshot: 'Consistent read (Oracle snapshot)',
  bulkLoad: 'Fast load mode',
  autoTune: 'Auto-tune speed',
  maxReaders: 'Most readers (auto-tune)',
  dataLimit: 'Rows per batch',
  blobLimit: 'Rows per batch with LOBs',
  stallMinutes: 'Stall warning after (min)',
};

const DECISION_LABELS = {
  PRESERVE_CASE: 'Preserve case of names',
  USE_RESERVED_WORDS: 'Keep reserved-word names',
  PG_NUMERIC_TYPE: 'Decimals as floating point',
  PG_INTEGER_TYPE: 'Whole numbers as integers',
  DEFAULT_NUMERIC: 'Type for NUMBER without precision',
  ENABLE_MICROSECOND: 'Keep microseconds',
  DATA_TYPE: 'Data type overrides',
  MODIFY_TYPE: 'Column type overrides',
  REPLACE_AS_BOOLEAN: 'Columns to boolean',
  NULL_EQUAL_EMPTY: 'Empty strings as NULL',
  DISABLE_COMMENT: 'Skip comments',
  EXPORT_INVALID: 'Export invalid code',
  SKIP: 'Skip constraint types',
  CLIENT_ENCODING: 'Client encoding',
  NLS_LANG: 'Oracle NLS_LANG',
};

const PHASE_LABELS = {
  prepare: 'Prepare', ddl: 'Export definitions', tables: 'Create tables', data: 'Load data', indexes: 'Indexes & constraints',
  fkeys: 'Foreign keys', sequences: 'Sequence values', code: 'Code objects & DB links', finalize: 'Analyze & finalize',
};

const ms = (a, b) => (a && b ? Math.max(0, new Date(b) - new Date(a)) : null);
const show = (v) => {
  if (v === undefined || v === null || v === '') return '—';
  if (v === true) return 'on';
  if (v === false) return 'off';
  return String(v);
};
const seconds = (x) => (x === null ? '—' : x < 60000 ? `${Math.round(x / 1000)} s` : x < 3600000 ? `${Math.floor(x / 60000)} min ${Math.round((x % 60000) / 1000)} s` : `${Math.floor(x / 3600000)} h ${Math.round((x % 3600000) / 60000)} min`);

function totals(s) {
  const list = Object.values(s.tables || {});
  return {
    tables: list.length,
    done: list.filter((t) => t.status === 'done').length,
    failed: list.filter((t) => t.status === 'failed').length,
    rows: list.reduce((a, t) => a + (t.status === 'done' ? Math.max(t.rowsDone || 0, t.pgRows || 0) : 0), 0),
    sizeMb: Math.round(list.reduce((a, t) => a + (t.sizeMb || 0), 0)),
  };
}

function sectionsFor(s) {
  const u = s.used || null;
  const t = totals(s);
  const phase = (k) => (s.phases || []).find((p) => p.key === k) || {};
  const run = [
    ['status', 'Status', s.status],
    ['startedAt', 'Started', s.startedAt || s.createdAt],
    ['finishedAt', 'Finished', s.finishedAt],
    ['duration', 'Duration', seconds(ms(s.startedAt, s.finishedAt))],
    ['startedBy', 'Started by', s.startedBy ? s.startedBy.id : null],
    ['attempt', 'Resumed', s.attempt > 1 ? `${s.attempt - 1}×` : 'no'],
    ['tables', 'Tables', `${t.done} of ${t.tables} done${t.failed ? `, ${t.failed} failed` : ''}${s.allTablesSelected ? ' (all tables)' : ''}`],
    ['rows', 'Rows loaded', t.rows.toLocaleString('en-US')],
    ['sizeMb', 'Data size (MB)', t.sizeMb.toLocaleString('en-US')],
  ];
  const where = [
    ['schema', 'Oracle schema', s.schema],
    ['targetSchema', 'PostgreSQL schema', s.targetSchema],
    ['snapshotAt', 'Schema snapshot taken', u ? u.snapshotAt : NOT_RECORDED],
    ['codePackageId', 'Converted code package', s.codePackageId || 'none'],
    ['createDbLinks', 'Create the saved DB links', s.createDbLinks],
    ['createCode', 'DMA converts the code objects it can', s.createCode],
    ['codeAuto', 'Code objects by DMA', s.codeAuto ? (s.codeAuto.error ? `not checked: ${s.codeAuto.error}` : `${s.codeAuto.created} created, ${s.codeAuto.genai} for GenAI, ${s.codeAuto.waiting} waiting, ${s.codeAuto.kept} kept`) : 'none'],
    ['gtt', 'Global temporary tables', s.gtt ? `${(s.gtt.tables || []).filter((x) => x.ok).length} ready (${s.gtt.mode === 'pgtt' ? 'pgtt extension' : `templates in ${s.gtt.schema}`})${s.gtt.failed && s.gtt.failed.length ? `, ${s.gtt.failed.length} failed` : ''}` : 'none'],
  ];
  const versions = [
    ['dmaVersion', 'DMA', u ? u.dmaVersion : NOT_RECORDED],
    ['ora2pgVersion', 'ora2pg', s.ora2pgVersion || (s.ora2pgMajor ? `${s.ora2pgMajor}` : NOT_RECORDED)],
    ['pgMajor', 'PostgreSQL', s.pgMajor || NOT_RECORDED],
  ];
  const options = Object.keys(OPTION_LABELS).map((k) => [`opt.${k}`, OPTION_LABELS[k], (s.options || {})[k]]);
  const dec = u && u.settings ? u.settings : null;
  const decisions = [
    ...Object.keys(DECISION_LABELS).map((k) => [`dec.${k}`, DECISION_LABELS[k], dec ? (dec.ora2pg || {})[k] : NOT_RECORDED]),
    ['dec.blobAs', 'BLOB storage', dec ? (dec.lob || {}).blobAs : NOT_RECORDED],
    ['dec.extraDirectives', 'Extra ora2pg directives', dec ? (dec.extraDirectives || '').trim() || 'none' : NOT_RECORDED],
    ['dec.readRoles', 'Read access roles', dec ? (dec.access || {}).readRoles : NOT_RECORDED],
    ['dec.writeRoles', 'Write access roles', dec ? (dec.access || {}).writeRoles : NOT_RECORDED],
  ];
  const phases = Object.keys(PHASE_LABELS).map((k) => [`phase.${k}`, PHASE_LABELS[k], phase(k).status === 'skipped' ? 'skipped' : seconds(ms(phase(k).startedAt, phase(k).finishedAt))]);
  return [
    { title: 'Run', rows: run },
    { title: 'Source and target', rows: where },
    { title: 'Versions', rows: versions },
    { title: 'Run options', rows: options },
    { title: 'Migration decisions', rows: decisions },
    { title: 'Time per phase', rows: phases },
  ];
}

function describeRuns(states) {
  const list = states.filter(Boolean);
  const per = list.map(sectionsFor);
  const sections = per[0].map((sec, i) => ({
    title: sec.title,
    rows: sec.rows.map(([key, label], j) => {
      const values = per.map((p) => show(p[i].rows[j][2]));
      // Start/finish times and run ids always differ: they are not "differences".
      const diff = values.length > 1 && !['startedAt', 'finishedAt'].includes(key) && values.some((v) => v !== values[0]);
      return { key, label, values, diff };
    }),
  }));
  const names = [...new Set(list.flatMap((s) => Object.keys(s.tables || {})))].sort();
  const tables = names.map((name) => {
    const values = list.map((s) => {
      const t = (s.tables || {})[name];
      if (!t) return null;
      return { status: t.status, rows: t.status === 'done' ? Math.max(t.rowsDone || 0, t.pgRows || 0) : (t.rowsDone || 0), seconds: ms(t.startedAt, t.finishedAt) === null ? null : Math.round(ms(t.startedAt, t.finishedAt) / 1000), attempts: t.attempts || 0 };
    });
    const diff = values.length > 1 && (values.some((v) => !v) || values.some((v) => v.status !== values[0].status || v.rows !== values[0].rows));
    return { name, values, diff };
  });
  return {
    runs: list.map((s) => ({ runId: s.runId, status: s.status, schema: s.schema, startedAt: s.startedAt || s.createdAt })),
    sections,
    tables,
  };
}

/** What a run records at its start about the settings it used (saved in its state). */
function usedAtStart({ settings, meta, dmaVersion }) {
  return {
    dmaVersion,
    snapshotAt: (meta && meta.snapshotAt) || null,
    settings: {
      ora2pg: { ...(settings.ora2pg || {}) },
      lob: { ...(settings.lob || {}) },
      extraDirectives: settings.extraDirectives || '',
      access: { readRoles: (settings.access || {}).readRoles || '', writeRoles: (settings.access || {}).writeRoles || '' },
    },
  };
}

module.exports = { describeRuns, usedAtStart, NOT_RECORDED };
