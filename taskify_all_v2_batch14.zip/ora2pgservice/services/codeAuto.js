'use strict';

/**
 * Code objects: DMA first, GenAI only for what DMA cannot do (DMA-086).
 *
 * "Check code objects" (startCheck):
 *   1. ora2pg converts every code object (the same export as the GenAI zip: one file per routine).
 *   2. DMA makes the mechanical fixes it knows (fixSql): reserved-word columns ora2pg writes in upper
 *      case ("OFFSET") while the tables have them in lower case; table@LINK → the DB link's schema;
 *      INSTEAD OF triggers without FOR EACH ROW.
 *   3. Every object is created in the target schema inside ONE transaction that is rolled back at
 *      the end (nothing is changed), in rounds: an object that needs another one is tried again once
 *      that one exists.
 *   4. Proof where possible: a view / materialized view must return as many rows as in Oracle.
 *      Functions, procedures and triggers can only be created here (calling them could change data):
 *      they are "ready, not compared with Oracle". Oracle code ora2pg left in them (CONNECT BY,
 *      BULK COLLECT, compound triggers…) sends them to GenAI.
 *   5. Dependencies (Oracle's DBA_DEPENDENCIES): an object that uses an object needing GenAI goes to
 *      GenAI with it; a package goes as a whole when one of its routines needs GenAI.
 * Statuses: ready (same result as Oracle) · ready_unproven · needs_table · needs_link · genai.
 *
 * "Create the ready objects" (applyReady): each one in its own transaction, in the order of step 3,
 * then the access grants of Settings. "Download for GenAI" (genaiZip): only the objects with status
 * genai, the conversion guide and DMA_CHECK.md (what DMA already created, why each object is in the
 * zip). The converted package is uploaded and applied as before; its objects replace DMA's.
 */
const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const AdmZip = require('adm-zip');
const logger = require('../utils/logger');
const { runWithProject } = require('../utils/context');
const { createRunLogger } = require('../errorHandling/error');
const pgClient = require('../utils/postgreClient');
const oracleClient = require('../utils/oracleClient');
const settingsSvc = require('./settings');
const store = require('./projectStore');
const events = require('./events');
const code = require('./code');

const jobs = new Map(); // project -> running check / apply state
const checksDir = (projectName) => path.join(code.codeDir(projectName), 'checks');
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
const qi = (n) => `"${String(n).replace(/"/g, '""')}"`;

const STATUS_LABEL = {
  ready: 'Ready: same result as Oracle',
  ready_unproven: 'Ready: created, not compared with Oracle',
  needs_table: 'Needs a table that is not migrated yet',
  needs_link: 'Needs a DB link to be created first',
  genai: 'Needs GenAI',
  created: 'Created by DMA',
  exists: 'Already in PostgreSQL (kept)',
  create_failed: 'Create failed',
};

/** Oracle code ora2pg could not convert, still present in the converted text. */
const LEFTOVERS = [
  [/\bbulk\s+collect\b/i, 'BULK COLLECT'],
  [/\bforall\b/i, 'FORALL'],
  [/\bconnect\s+by\b|\bprior\s+\w/i, 'CONNECT BY / PRIOR'],
  [/\bcompound\s+trigger\b|\bCOMPOUND\s+(INSERT|UPDATE|DELETE)\b/i, 'compound trigger'],
  [/\b(dbms|utl)_\w+\s*\./i, 'DBMS_ / UTL_ package'],
  [/\brownum\b/i, 'ROWNUM'],
  [/\bis\s+table\s+of\b|\btable\s+of\b[^;]*\bindex\s+by\b|\bvarray\s*\(/i, 'PL/SQL collection type'],
  [/\bdblink\s*\(/i, 'autonomous transaction (dblink)'],
  [/\b\w+@\w+/, 'table@LINK'],
  [/\bpragma\b/i, 'PRAGMA'],
  [/\bexecute\s+immediate\b/i, 'EXECUTE IMMEDIATE'],
];

function leftovers(sql) {
  const noStrings = sql.replace(/\$body\$[\s\S]*?\$body\$/gi, (m) => m.replace(/'[^']*'/g, "''"));
  return LEFTOVERS.filter(([re]) => re.test(noStrings)).map(([, label]) => label);
}

/**
 * The mechanical fixes DMA makes before trying an object. Returns { sql, fixes }.
 *   preserveCase: Settings "Preserve case" (then upper-case quoted names are right and kept)
 *   links: { LINKNAME: localSchema } of the DB links mapped on the Code objects page
 */
function fixSql(sql, { preserveCase = false, links = {} } = {}) {
  const fixes = new Set();
  let t = sql;
  if (!preserveCase) {
    t = t.replace(/"([A-Z][A-Z0-9_$#]*)"/g, (m, c) => {
      fixes.add('reserved-word column in lower case');
      return `"${c.toLowerCase()}"`;
    });
  }
  t = t.replace(/\b([A-Za-z_][\w$#]*)@([A-Za-z_][\w$#]*(?:\.[\w$#]+)*)/g, (m, tb, link) => {
    const local = links[link.toUpperCase()];
    if (!local) return m;
    fixes.add('table@LINK → DB link schema');
    return `${local}.${tb}`;
  });
  t = t.replace(/(INSTEAD\s+OF\s+[\s\S]*?\bON\s+[\w$#."]+)\s+(EXECUTE\s+(?:PROCEDURE|FUNCTION))/i, (m, a, b) => {
    if (/FOR\s+EACH\s+ROW/i.test(m)) return m;
    fixes.add('INSTEAD OF trigger: FOR EACH ROW');
    return `${a} FOR EACH ROW ${b}`;
  });
  return { sql: t, fixes: [...fixes] };
}

/** Lines of ora2pg files that are not part of the object: includes, session settings, DROP SCHEMA. */
function cleanText(text) {
  return text.split('\n')
    .filter((l) => !/^\s*(\\i\s|\\set\s|SET\s+search_path|SET\s+client_encoding|SET\s+check_function_bodies)/i.test(l))
    .filter((l) => !/^\s*DROP\s+SCHEMA\b/i.test(l))
    .join('\n').trim();
}

/** Statements of a file; comment lines in front of a statement (ora2pg's file header) are dropped. */
const splitStatements = (text) => text.split(/;\s*(?:\n|$)/).map((x) => x.replace(/^(\s*--[^\n]*(\n|$))+/, '').trim()).filter(Boolean);

/**
 * The exported files as objects: { key, kind, folder, file, name, oracleName, pkg, sql }.
 * Views and materialized views come one file per type; routines and triggers one file each.
 */
function readObjects(srcDir) {
  const out = [];
  const read = (rel) => (fs.existsSync(path.join(srcDir, rel)) ? fs.readFileSync(path.join(srcDir, rel), 'utf8') : '');
  for (const st of splitStatements(cleanText(read('views/views.sql')))) {
    const m = /^CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(?:[\w$#"]+\.)?("?)([\w$#]+)\1/i.exec(st);
    if (m) out.push({ kind: 'view', folder: 'views', file: `${m[2]}.sql`, name: m[2], oracleName: m[2].toUpperCase(), sql: `${st};` });
  }
  let mv = null;
  for (const st of splitStatements(cleanText(read('mviews/mviews.sql')))) {
    const m = /^CREATE\s+MATERIALIZED\s+VIEW\s+(?:[\w$#"]+\.)?("?)([\w$#]+)\1/i.exec(st);
    if (m) {
      mv = { kind: 'materialized view', folder: 'mviews', file: `${m[2]}.sql`, name: m[2], oracleName: m[2].toUpperCase(), sql: `${st};` };
      out.push(mv);
    } else if (mv) mv.sql += `\n${st};`;
  }
  const perFile = (folder, kind, suffix) => {
    const dir = path.join(srcDir, folder);
    if (!fs.existsSync(dir)) return;
    for (const rel of fs.readdirSync(dir, { recursive: true }).map(String).filter((f) => f.endsWith(`_${suffix}.sql`)).sort()) {
      const base = path.basename(rel).replace(new RegExp(`_${suffix}\\.sql$`), '');
      const pkg = folder === 'packages' && path.dirname(rel) !== '.' ? path.dirname(rel).split(path.sep)[0] : null;
      const sql = cleanText(fs.readFileSync(path.join(dir, rel), 'utf8'));
      if (!sql) continue;
      out.push({ kind, folder, file: rel, name: pkg ? `${pkg}.${base}` : base.toLowerCase(), oracleName: (pkg || base).toUpperCase(), pkg, sql });
    }
  };
  perFile('functions', 'function', 'functions');
  perFile('procedures', 'procedure', 'procedures');
  perFile('packages', 'package routine', 'packages');
  perFile('triggers', 'trigger', 'triggers');
  out.forEach((o, i) => { o.key = `${o.folder}/${o.file}#${i}`; });
  return out;
}

/** Oracle's dependencies between code objects of the schema: NAME → Set of names it uses. */
async function oracleDependencies(projectName, schema) {
  const conn = await oracleClient.getOracleConnection(projectName);
  try {
    const r = await conn.execute(
      `SELECT name, referenced_name, referenced_type FROM dba_dependencies
        WHERE owner = :o AND referenced_owner = :o AND name <> referenced_name
          AND type IN ('VIEW', 'MATERIALIZED VIEW', 'FUNCTION', 'PROCEDURE', 'PACKAGE', 'PACKAGE BODY', 'TRIGGER')
          AND referenced_type IN ('VIEW', 'MATERIALIZED VIEW', 'FUNCTION', 'PROCEDURE', 'PACKAGE', 'TRIGGER', 'SYNONYM')`, { o: schema });
    const deps = new Map();
    const synonyms = new Set();
    for (const [name, ref, type] of r.rows) {
      if (!deps.has(name)) deps.set(name, new Set());
      deps.get(name).add(ref);
      if (type === 'SYNONYM') synonyms.add(ref);
    }
    return { deps, synonyms };
  } finally {
    await conn.close().catch(() => {});
  }
}

/**
 * Final status of every object from the trial results (pure: unit-tested).
 * o: { kind, oracleName, pkg, created, error, pgRows, oraRows, compareError, leftovers }
 * ctx: { oracleTables: Set(lower), deps: Map, synonyms: Set }
 */
function classify(objects, { oracleTables = new Set(), deps = new Map(), synonyms = new Set() } = {}) {
  for (const o of objects) {
    // relation "[schema.]name" does not exist → [, schema, name]
    const missing = /relation "(?:([^".]+)\.)?([^".]+)" does not exist/.exec(o.error || '');
    const missingName = missing && missing[2];
    const missingFull = missing && (missing[1] ? `${missing[1]}.${missing[2]}` : missing[2]);
    o.missingName = missingName ? missingName.toLowerCase() : null;
    const usesSynonym = [...(deps.get(o.oracleName) || [])].find((r) => synonyms.has(r));
    if (o.existsAlready) {
      Object.assign(o, { status: 'exists', reason: 'Already in PostgreSQL (from an earlier package or created by hand): DMA keeps it and does not replace it' });
    } else if (o.created && o.leftovers.length) {
      Object.assign(o, { status: 'genai', reason: `ora2pg left Oracle code in it: ${o.leftovers.join(', ')}` });
    } else if (!o.created && o.leftovers.some((l) => l !== 'table@LINK')) {
      // Oracle code ora2pg left in it needs GenAI anyway, whatever else is missing.
      Object.assign(o, { status: 'genai', reason: `ora2pg left Oracle code in it: ${o.leftovers.filter((l) => l !== 'table@LINK').join(', ')}` });
    } else if (!o.created) {
      if (missing && /^link_/.test(missing[1] || '')) Object.assign(o, { status: 'needs_link', reason: `Create the DB link first (${missingFull} does not exist): Code objects → DB link mapping → Create now` });
      else if (o.leftovers.includes('table@LINK')) Object.assign(o, { status: 'needs_link', reason: 'Uses a DB link that is not mapped: map it on this page (DB link mapping), then check again' });
      else if (missing && oracleTables.has(missingName.toLowerCase())) Object.assign(o, { status: 'needs_table', reason: `Table ${missingName} is not migrated yet: migrate it, then check again` });
      else if (missing && usesSynonym) Object.assign(o, { status: 'genai', reason: `Uses synonym ${usesSynonym}, which ora2pg does not convert` });
      else Object.assign(o, { status: 'genai', reason: o.leftovers.length ? `ora2pg left Oracle code in it: ${o.leftovers.join(', ')}` : `PostgreSQL refused it: ${o.error}` });
    } else if (o.kind === 'view' || o.kind === 'materialized view') {
      if (o.pgRows !== undefined && o.oraRows !== undefined && o.pgRows === o.oraRows) Object.assign(o, { status: 'ready', reason: `Same number of rows as in Oracle (${o.oraRows.toLocaleString('en-US')})` });
      else if (o.pgRows !== undefined && o.oraRows !== undefined) Object.assign(o, { status: 'genai', reason: `Different result: Oracle ${o.oraRows.toLocaleString('en-US')} rows, PostgreSQL ${o.pgRows.toLocaleString('en-US')}` });
      else Object.assign(o, { status: 'ready_unproven', reason: `Created; result not compared with Oracle (${o.compareError || 'not counted'})` });
    } else {
      Object.assign(o, { status: 'ready_unproven', reason: 'Created; behaviour not compared with Oracle (calling it could change data): test it in the application' });
    }
  }
  // Dependencies: whatever uses an object that needs GenAI goes to GenAI too; packages go as a whole.
  const blocked = () => new Map(objects.filter((o) => o.status === 'genai').map((o) => [o.oracleName, o]));
  // An object PostgreSQL refused because another object of this list does not exist yet uses that one.
  const byName = new Map(objects.map((x) => [String(x.name).split('.').pop().toLowerCase(), x]));
  for (const o of objects) {
    const ref = o.missingName && byName.get(o.missingName);
    if (ref && ref !== o && o.status === 'genai' && !o.leftovers.length) {
      Object.assign(o, { reason: `Uses ${ref.name}, which ${ref.status === 'genai' ? 'needs GenAI: they go together' : `is not ready (${ref.reason})`}`, dependsOn: ref.name });
      if (ref.status === 'needs_table' || ref.status === 'needs_link') o.status = ref.status;
    }
  }
  for (let changed = true; changed;) {
    changed = false;
    const b = blocked();
    for (const o of objects.filter((x) => x.status === 'ready' || x.status === 'ready_unproven')) {
      const inPkg = o.pkg && objects.find((x) => x.pkg === o.pkg && x !== o && x.status === 'genai');
      const dep = [...(deps.get(o.oracleName) || [])].find((r) => b.has(r) && r !== o.oracleName);
      if (inPkg) Object.assign(o, { status: 'genai', reason: `Part of package ${o.pkg}: ${inPkg.name} needs GenAI, so the whole package goes together`, dependsOn: inPkg.name });
      else if (dep) Object.assign(o, { status: 'genai', reason: `Uses ${dep.toLowerCase()}, which needs GenAI: they go together`, dependsOn: dep.toLowerCase() });
      else continue;
      changed = true;
    }
  }
  return objects;
}

const summarize = (objects) => {
  const s = { total: objects.length };
  for (const o of objects) s[o.status] = (s[o.status] || 0) + 1;
  return s;
};

function status(projectName) {
  return jobs.get(projectName) || null;
}

async function latest(projectName) {
  const dir = checksDir(projectName);
  if (!fs.existsSync(dir)) return null;
  for (const id of (await fsp.readdir(dir)).sort().reverse()) {
    const r = await store.readJson(path.join(dir, id, 'result.json'));
    if (r) return r;
  }
  return null;
}

async function readCheck(projectName, id) {
  if (!/^\d{8}-\d{6}$/.test(String(id))) return null;
  return store.readJson(path.join(checksDir(projectName), id, 'result.json'));
}

const publicResult = (r) => r && ({ ...r, objects: r.objects.map(({ sql, ...o }) => ({ ...o, label: STATUS_LABEL[o.status] || o.status })) });

/**
 * The whole check, waited for: export, fixes, trial (rolled back), comparison with Oracle,
 * dependencies, statuses. Saved as code/checks/<id>/result.json. Used by the button on the Code
 * objects page (startCheck, in the background) and by the migration's code phase.
 *   progress(message, steps): optional, called as it goes
 */
async function checkNow(projectName, { progress = () => {}, steps, id: givenId } = {}) {
  const meta = await store.readMeta(projectName);
  const schema = meta && meta.selectedSchema;
  if (!schema) throw Object.assign(new Error('Select a schema first.'), { status: 400 });
  const oracle = store.oracleCredentials(meta);
  const pgCred = store.postgresCredentials(meta);
  if (!oracle || !pgCred) throw Object.assign(new Error('Connect Oracle and PostgreSQL first.'), { status: 400 });
  const settings = settingsSvc.resolve(meta);
  const target = settings.targetSchema || schema.toLowerCase();
  await pgClient.ensurePostgresPool(pgCred, projectName);
  const { rows } = await pgClient.pgQuery(`SELECT count(*)::int AS n FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relkind IN ('r', 'p')`, [target], projectName);
  if (!rows[0].n) throw Object.assign(new Error(`No tables in PostgreSQL schema ${target} yet: migrate the tables first, then check the code objects.`), { status: 400 });

  const id = givenId || stamp();
  const dir = path.join(checksDir(projectName), id);
  const stepList = steps || code.FOLDERS.map((f) => ({ folder: f.folder, label: f.label, status: 'pending', files: 0, objects: 0 }));
  const log = createRunLogger(dir);
  try {
    progress('Exporting with ora2pg', stepList);
    await code.exportSources({ projectName, meta, oracle, schema, settings, dir, log, steps: stepList, emit: () => progress('Exporting with ora2pg', stepList) });
    progress('Trying every object in PostgreSQL (rolled back)', stepList);
    const links = Object.fromEntries(Object.entries(meta.dbLinkMappings || {}).filter(([, m]) => m.mode !== 'skip' && m.localSchema).map(([k, m]) => [k.toUpperCase(), m.localSchema]));
    const objects = readObjects(path.join(dir, 'src')).map((o) => {
      const f = fixSql(o.sql, { preserveCase: !!settings.ora2pg.PRESERVE_CASE, links });
      return { ...o, sql: f.sql, fixes: f.fixes, leftovers: leftovers(f.sql) };
    });
    await oracleClient.ensureOraclePool(oracle, projectName);
    await trial(projectName, schema, target, objects, (msg) => progress(msg, stepList));
    const snapshot = await store.readSnapshot(projectName, schema);
    const oracleTables = new Set((snapshot && snapshot.tableMetadata ? snapshot.tableMetadata.map((t) => t.name.toLowerCase()) : []));
    const { deps, synonyms } = await oracleDependencies(projectName, schema).catch((err) => {
      log.error(`Oracle dependencies could not be read: ${err.message}`);
      return { deps: new Map(), synonyms: new Set() };
    });
    classify(objects, { oracleTables, deps, synonyms });
    const result = { id, schema, target, createdAt: new Date().toISOString(), summary: summarize(objects), objects };
    await fsp.mkdir(dir, { recursive: true });
    await store.writeJsonAtomic(path.join(dir, 'result.json'), result);
    log.success(`Code check: ${JSON.stringify(result.summary)}`);
    return result;
  } finally {
    log.close();
  }
}

/** Starts "Check code objects" in the background (progress as `codeCheck` events). */
async function startCheck(projectName) {
  if (jobs.has(projectName) && jobs.get(projectName).status === 'RUNNING') return jobs.get(projectName);
  const meta = await store.readMeta(projectName);
  if (!meta || !meta.selectedSchema) throw Object.assign(new Error('Select a schema first.'), { status: 400 });
  const settings = settingsSvc.resolve(meta);
  const target = settings.targetSchema || meta.selectedSchema.toLowerCase();
  const pgCred = store.postgresCredentials(meta);
  if (!pgCred || !store.oracleCredentials(meta)) throw Object.assign(new Error('Connect Oracle and PostgreSQL first.'), { status: 400 });
  await pgClient.ensurePostgresPool(pgCred, projectName);
  const { rows } = await pgClient.pgQuery(`SELECT count(*)::int AS n FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relkind IN ('r', 'p')`, [target], projectName);
  if (!rows[0].n) throw Object.assign(new Error(`No tables in PostgreSQL schema ${target} yet: migrate the tables first, then check the code objects.`), { status: 400 });
  const state = {
    id: stamp(), schema: meta.selectedSchema, target, status: 'RUNNING', startedAt: new Date().toISOString(), step: 'Exporting with ora2pg',
    steps: code.FOLDERS.map((f) => ({ folder: f.folder, label: f.label, status: 'pending', files: 0, objects: 0 })),
  };
  jobs.set(projectName, state);
  const emit = () => events.publish(projectName, 'codeCheck', state);
  emit();
  runWithProject(projectName, async () => {
    try {
      const result = await checkNow(projectName, { id: state.id, steps: state.steps, progress: (msg) => { state.step = msg; emit(); } });
      Object.assign(state, { id: result.id, status: 'COMPLETED', step: null, summary: result.summary, finishedAt: result.createdAt });
    } catch (err) {
      logger.error(`Code check failed: ${err.stack}`);
      Object.assign(state, { status: 'FAILED', error: err.message, step: null });
    } finally {
      emit();
      setTimeout(() => { if (jobs.get(projectName) === state) jobs.delete(projectName); }, 1000);
    }
  });
  return state;
}

/**
 * Creates every object in the target schema in one transaction that is ROLLED BACK at the end, in
 * rounds; counts the rows of the views created and compares them with Oracle. Sets on each object:
 * created, round, error, pgRows, oraRows, compareError.
 */
async function trial(projectName, schema, target, objects, progress) {
  const client = await pgClient.getPostgresConnection(projectName);
  try {
    await client.query('BEGIN');
    await client.query(`SET LOCAL search_path = ${qi(target)}, public`);
    await client.query("SET LOCAL statement_timeout = '300s'");
    await client.query("SET LOCAL lock_timeout = '10s'");
    for (const pkg of [...new Set(objects.map((o) => o.pkg).filter(Boolean))]) await client.query(`CREATE SCHEMA IF NOT EXISTS ${qi(pkg)}`);
    if (objects.some((o) => o.pkg)) await client.query(`SET LOCAL search_path = ${qi(target)}, ${[...new Set(objects.map((o) => o.pkg).filter(Boolean))].map(qi).join(', ')}, public`);
    // Objects already in PostgreSQL (an earlier GenAI package, a fix by hand) are kept, never replaced.
    for (const o of objects) o.existsAlready = await objectExists(client, o, target);
    for (let round = 1, more = true; more && round <= 6; round += 1) {
      more = false;
      for (const o of objects.filter((x) => !x.created && !x.existsAlready)) {
        await client.query('SAVEPOINT dma_obj');
        try {
          await client.query(o.sql);
          await client.query('RELEASE SAVEPOINT dma_obj');
          Object.assign(o, { created: true, round, error: null });
          more = true;
        } catch (err) {
          await client.query('ROLLBACK TO SAVEPOINT dma_obj');
          o.error = err.message.split('\n')[0];
        }
      }
      progress(`Trying every object in PostgreSQL (rolled back): round ${round}, ${objects.filter((x) => x.created).length} of ${objects.length} created`);
    }
    const views = objects.filter((o) => o.created && (o.kind === 'view' || o.kind === 'materialized view'));
    let n = 0;
    for (const o of views) {
      n += 1;
      progress(`Comparing with Oracle: ${o.name} (${n} of ${views.length})`);
      await client.query('SAVEPOINT dma_cnt');
      try {
        o.pgRows = Number((await client.query(`SELECT count(*) AS n FROM ${qi(o.name)}`)).rows[0].n);
        await client.query('RELEASE SAVEPOINT dma_cnt');
      } catch (err) {
        await client.query('ROLLBACK TO SAVEPOINT dma_cnt');
        o.compareError = `PostgreSQL: ${err.message.split('\n')[0]}`;
        continue;
      }
      const conn = await oracleClient.getOracleConnection(projectName);
      try {
        conn.callTimeout = 120000;
        o.oraRows = Number((await conn.execute(`SELECT COUNT(*) FROM ${qi(schema)}.${qi(o.oracleName)}`)).rows[0][0]);
      } catch (err) {
        o.compareError = `Oracle: ${err.message.split('\n')[0]}`;
        delete o.pgRows;
      } finally {
        await conn.close().catch(() => {});
      }
    }
  } finally {
    await client.query('ROLLBACK').catch(() => {});
    client.release();
  }
}

/** Whether this object (by kind and name) is already in the target (or its package schema). */
async function objectExists(client, o, target) {
  const base = String(o.name).split('.').pop().toLowerCase();
  const schema = o.pkg || target;
  if (o.kind === 'view' || o.kind === 'materialized view') {
    return (await client.query(`SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2 AND c.relkind IN ('v', 'm')`, [schema, base])).rowCount > 0;
  }
  if (o.kind === 'trigger') {
    return (await client.query(`SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND t.tgname = $2`, [target, base])).rowCount > 0;
  }
  return (await client.query(`SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = $1 AND p.proname = $2`, [schema, base])).rowCount > 0;
}

/**
 * Every function / procedure an object creates gets its own search_path (target, package schemas,
 * public): ora2pg's code names tables without their schema, which in Oracle always means the
 * owner's schema; pinned, it works whatever the caller's search_path is (also the safe practice for
 * SECURITY DEFINER routines, which ora2pg creates).
 */
async function pinSearchPath(client, sql, target, searchPath) {
  const re = /CREATE\s+(?:OR\s+REPLACE\s+)?(?:FUNCTION|PROCEDURE)\s+(?:("?)([\w$#]+)\1\.)?("?)([\w$#]+)\3\s*\(/gi;
  for (let m = re.exec(sql); m; m = re.exec(sql)) {
    const schema = m[2] ? (m[1] ? m[2] : m[2].toLowerCase()) : target;
    const name = m[3] ? m[4] : m[4].toLowerCase();
    const { rows } = await client.query(
      `SELECT p.oid::regprocedure::text AS sig FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = $1 AND p.proname = $2`, [schema, name]);
    for (const r of rows) await client.query(`ALTER ROUTINE ${r.sig} SET search_path = ${searchPath}`);
  }
}

/** "Create the ready objects": for real, one transaction each, in the order they were created in the check. */
async function applyReady(projectName, id) {
  const result = await readCheck(projectName, id);
  if (!result) throw Object.assign(new Error('Code check not found.'), { status: 404 });
  // Only a check still running blocks (a finished one stays in memory for a second, for the screen).
  if (jobs.has(projectName) && jobs.get(projectName).status === 'RUNNING') throw Object.assign(new Error('A code check is running: wait for it to finish.'), { status: 409 });
  const meta = await store.readMeta(projectName);
  const settings = settingsSvc.resolve(meta);
  await pgClient.ensurePostgresPool(store.postgresCredentials(meta), projectName);
  const todo = result.objects.filter((o) => o.status === 'ready' || o.status === 'ready_unproven').sort((a, b) => (a.round || 0) - (b.round || 0));
  const pkgs = [...new Set(todo.map((o) => o.pkg).filter(Boolean))];
  const client = await pgClient.getPostgresConnection(projectName);
  let created = 0;
  const failed = [];
  try {
    for (const pkg of pkgs) await client.query(`CREATE SCHEMA IF NOT EXISTS ${qi(pkg)}`);
    for (const o of todo) {
      try {
        await client.query('BEGIN');
        if (await objectExists(client, o, result.target)) {
          // Created meanwhile (a GenAI package, by hand): kept, never replaced.
          await client.query('ROLLBACK');
          Object.assign(o, { status: 'exists', reason: 'Already in PostgreSQL when DMA was about to create it: kept' });
          continue;
        }
        const path_ = [qi(result.target), ...pkgs.map(qi), 'public'].join(', ');
        await client.query(`SET LOCAL search_path = ${path_}`);
        await client.query(o.sql);
        await pinSearchPath(client, o.sql, result.target, path_);
        await client.query('COMMIT');
        Object.assign(o, { status: 'created', createdAt: new Date().toISOString() });
        created += 1;
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        Object.assign(o, { status: 'create_failed', reason: err.message.split('\n')[0] });
        failed.push({ name: o.name, error: o.reason });
      }
    }
    // Settings → access: the application roles get their rights on the new views and routines.
    for (const stmt of settingsSvc.accessSql(settings, result.target)) await client.query(stmt).catch(() => {});
  } finally {
    client.release();
  }
  result.summary = summarize(result.objects);
  result.applied = { at: new Date().toISOString(), created, failed };
  await store.writeJsonAtomic(path.join(checksDir(projectName), id, 'result.json'), result);
  events.publish(projectName, 'codeCheck', { id, status: 'APPLIED', summary: result.summary });
  logger.info(`Code check ${id}: ${created} objects created by DMA, ${failed.length} failed`);
  return publicResult(result);
}

/** The zip for the GenAI team: only the objects that need GenAI, with the reasons. */
async function genaiZip(projectName, id) {
  const result = await readCheck(projectName, id);
  if (!result) throw Object.assign(new Error('Code check not found.'), { status: 404 });
  const meta = await store.readMeta(projectName);
  const settings = settingsSvc.resolve(meta);
  const todo = result.objects.filter((o) => o.status === 'genai');
  const zip = new AdmZip();
  for (const o of todo) zip.addFile(path.posix.join(o.folder, o.file.split(path.sep).join('/')), Buffer.from(`${o.sql}\n`));
  // A package's schema, so the converted routines can be applied back (packages/<pkg>.sql).
  for (const pkg of [...new Set(todo.map((o) => o.pkg).filter(Boolean))]) zip.addFile(`packages/${pkg}.sql`, Buffer.from(`CREATE SCHEMA IF NOT EXISTS ${qi(pkg)};\n`));
  const done = result.objects.filter((o) => ['ready', 'ready_unproven', 'created'].includes(o.status));
  const waiting = result.objects.filter((o) => o.status === 'needs_table' || o.status === 'needs_link');
  const md = [
    `# ${result.schema}: objects DMA could not convert itself`,
    '',
    `DMA checked ${result.objects.length} code objects on ${result.createdAt.slice(0, 10)}. ${done.length} were converted by DMA (ora2pg) and do not need GenAI; ${todo.length} are in this zip.`,
    'Convert the files in this zip and send them back with the same folders. Objects that depend on each other are in the zip together.',
    '',
    '## In this zip (convert these)',
    '',
    '| Object | Type | Why |',
    '|---|---|---|',
    ...todo.map((o) => `| ${o.name} | ${o.kind} | ${o.reason.replace(/\|/g, '/')} |`),
    '',
    '## Already in PostgreSQL, converted by DMA (do not convert, you may use them)',
    '',
    ...(done.length ? done.map((o) => `- ${o.name} (${o.kind})`) : ['- none']),
    '',
    ...(waiting.length ? ['## Not in this zip yet (DMA checks them again once the table / DB link exists)', '', ...waiting.map((o) => `- ${o.name}: ${o.reason}`), ''] : []),
  ].join('\n');
  zip.addFile('DMA_CHECK.md', Buffer.from(md));
  zip.addFile('CONVERSION_GUIDE.md', Buffer.from(code.conversionGuide(result.schema, meta, settings)));
  zip.addFile('manifest.json', Buffer.from(JSON.stringify({ checkId: id, schema: result.schema, createdAt: new Date().toISOString(), objects: todo.map(({ name, kind, folder, file, reason }) => ({ name, kind, folder, file, reason })) }, null, 2)));
  return { name: `${result.schema}_for_genai_${id}.zip`, buffer: zip.toBuffer(), count: todo.length };
}

module.exports = { startCheck, checkNow, status, latest: async (p) => publicResult(await latest(p)), readCheck, applyReady, genaiZip, publicResult, fixSql, leftovers, readObjects, classify, cleanText, STATUS_LABEL };
