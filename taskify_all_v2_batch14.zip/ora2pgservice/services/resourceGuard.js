'use strict';

/**
 * CPU and memory guard (DMA-075): protects this server in every phase of a run, with or without
 * auto-tune. Every few seconds it measures the server's CPU and available memory:
 *   - memory short (less than DMA_GUARD_MIN_FREE_MB, default the larger of 1 GB and 5 % of the RAM)
 *   - or CPU at DMA_GUARD_CPU_MAX % (default 95) or more in two measurements in a row
 * → the server is "busy": no NEW work is started (a table, a part of a big table, an index, a key,
 * a foreign key…) until it is back to normal. Work already running continues and frees resources.
 * Each change is written to the run's events and to state.guard (shown on the Live monitor).
 * So a run can never hang: after DMA_GUARD_MAX_WAIT_SECONDS (default 600) of waiting, the next
 * piece of work starts anyway, one at a time, and the run says so.
 *
 * Test only: DMA_GUARD_TEST_LOW_MEMORY_SECONDS=N reports memory as short for the first N seconds of
 * a run (to prove the pause and the recovery end-to-end on a machine with plenty of memory).
 */
const os = require('os');
const { availableMemory, CpuMeter } = require('./serverUsage');

const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);

class ResourceGuard {
  /**
   * run: { event(level, message), state, save(immediate) } (a Run).
   * host: { cpuPct(), freeBytes(), totalBytes() } (replaced in tests). now: () => ms (tests).
   */
  constructor({ run, host, sampleMs, cpuMax, minFreeMb, maxWaitMs, testLowMemoryMs, now } = {}) {
    this.run = run;
    const cpu = new CpuMeter();
    this.host = host || { cpuPct: () => cpu.percent(), freeBytes: availableMemory, totalBytes: () => os.totalmem() };
    this.now = now || Date.now;
    this.sampleMs = sampleMs || num(process.env.DMA_GUARD_SAMPLE_SECONDS, 5) * 1000;
    this.cpuMax = cpuMax || Math.min(99, Math.max(50, num(process.env.DMA_GUARD_CPU_MAX, 95)));
    const total = this.host.totalBytes();
    this.minFree = (minFreeMb || num(process.env.DMA_GUARD_MIN_FREE_MB, Math.max(1024, Math.round((total / 1024 / 1024) * 0.05)))) * 1024 * 1024;
    this.maxWaitMs = maxWaitMs || num(process.env.DMA_GUARD_MAX_WAIT_SECONDS, 600) * 1000;
    this.testLowMemoryMs = testLowMemoryMs !== undefined ? testLowMemoryMs : num(process.env.DMA_GUARD_TEST_LOW_MEMORY_SECONDS, 0) * 1000;
    this.cpuHits = 0;
    this.status = 'ok';
    this.waiters = [];
    this.pauses = 0;
    this.pausedMs = 0;
    this.busySince = null;
    this.timer = null;
  }

  start() {
    this.startedAt = this.now();
    this.sample();
    this.timer = setInterval(() => this.sample(), this.sampleMs);
    if (this.timer.unref) this.timer.unref();
    return this;
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.status !== 'ok') this.pausedMs += this.now() - this.busySince;
    this.status = 'ok';
    this.publish();
    this.waiters.splice(0).forEach((w) => w.resolve());
  }

  /** One measurement: updates the status and wakes the waiting work when the server recovered. */
  sample() {
    const cpuPct = this.host.cpuPct();
    let free = this.host.freeBytes();
    if (this.testLowMemoryMs && this.now() - this.startedAt < this.testLowMemoryMs) free = 0;
    this.cpuPct = cpuPct;
    this.freeMb = Number.isFinite(free) ? Math.round(free / 1024 / 1024) : null;
    this.cpuHits = cpuPct !== null && cpuPct !== undefined && cpuPct >= this.cpuMax ? this.cpuHits + 1 : 0;
    const next = free < this.minFree ? 'memory' : this.cpuHits >= 2 ? 'cpu' : 'ok';
    if (next !== this.status) {
      if (next === 'ok') {
        this.pausedMs += this.now() - this.busySince;
        this.run.event('info', `Server load back to normal${this.cpuPct !== null && this.cpuPct !== undefined ? ` (CPU ${this.cpuPct} %` : ' ('}${this.freeMb !== null ? `, ${this.freeMb.toLocaleString('en-US')} MB memory free)` : ')'}: new work starts again`);
        this.busySince = null;
      } else {
        if (this.status === 'ok') this.busySince = this.now();
        this.run.event('error', next === 'memory'
          ? `Server memory is short (${this.freeMb.toLocaleString('en-US')} MB free, needs ${Math.round(this.minFree / 1024 / 1024).toLocaleString('en-US')} MB): DMA starts no new work until memory is free again. Work already running continues.`
          : `Server CPU is full (${cpuPct} %): DMA starts no new work until it drops. Work already running continues.`);
      }
      this.status = next;
      if (next === 'ok') this.waiters.splice(0).forEach((w) => w.resolve());
    }
    this.publish();
  }

  publish() {
    const s = this.run.state;
    s.guard = {
      status: this.status, cpuPct: this.cpuPct ?? null, freeMb: this.freeMb ?? null, cpuMax: this.cpuMax,
      minFreeMb: Math.round(this.minFree / 1024 / 1024), pauses: this.pauses, pausedSeconds: Math.round(this.pausedMs / 1000), at: new Date(this.now()).toISOString(),
    };
    if (this.run.save) this.run.save();
  }

  /**
   * Resolves when new work may start: at once while the server is fine; otherwise when it is back
   * to normal, or after the longest wait (the run then continues one piece at a time).
   */
  whenOk(what) {
    if (this.status === 'ok' || !this.timer) return Promise.resolve();
    this.pauses += 1;
    this.publish();
    return new Promise((resolve) => {
      const w = { resolve: () => { clearTimeout(w.t); resolve(); } };
      w.t = setTimeout(() => {
        const i = this.waiters.indexOf(w);
        if (i >= 0) this.waiters.splice(i, 1);
        this.run.event('error', `Server still busy after ${Math.round(this.maxWaitMs / 60000)} min: ${what || 'the next step'} starts anyway`);
        resolve();
      }, this.maxWaitMs);
      if (w.t.unref) w.t.unref();
      this.waiters.push(w);
    });
  }
}

module.exports = { ResourceGuard };
