# DMA v2: batch 14, copy project, run details, CPU/RAM guard, global temporary tables, code objects by DMA

**No `.env` change needed. No new npm package. `server.js` is not changed.** This zip replaces any earlier batch 14 zip.

Deploy batch 13 first: this batch builds on it.

## What's new

| # | Item | Where | What users see |
|---|---|---|---|
| 1 | **Copy project** (DMA-057) | **All projects** → copy icon on a project card | "Copy project for another schema": pick the schema, a name is suggested, "Copy the settings too" is on. The new project opens at Schema & snapshot. Same Oracle and PostgreSQL connections, so several schemas can be migrated, even at the same time |
| 2 | **Run details** (DMA-077) | **Live monitor** → open a run → "Run details" (closed by default) | What the run used: tables, options, migration decisions, PostgreSQL schema, snapshot time, global temporary tables, versions (DMA, ora2pg, PostgreSQL) and time per phase |
| 3 | **Compare runs** (DMA-077) | **Live monitor** list → tick 2 runs → "Compare the 2 runs" | Side by side, differences marked in yellow, "Show only differences" on by default, plus each table's result in both runs |
| 4 | **CPU and RAM guard** (DMA-075) | Every run, every phase | When the server is overloaded, DMA starts no new work (table, part of a big table, index, key) until it recovers; running work continues. A yellow notice on the Live monitor while it waits; afterwards "DMA waited N times (…) to protect it" |
| 5 | **Global temporary tables** (DMA-085) | Every run, automatically | Oracle global temporary tables now exist in PostgreSQL (structure, defaults, NOT NULL, keys, "delete rows at commit" or "keep rows until session end"). See below for the two ways |

| 6 | **Code objects: DMA first, GenAI only for what DMA cannot do** (DMA-086) | **Automatic in every migration** (nothing to click); **Code objects** page shows the result | After the data, DMA lets ora2pg convert every view, materialized view, function, procedure, package and trigger, **tries each one in PostgreSQL first** (in a transaction that is undone), compares views with Oracle, follows Oracle's dependencies, and **creates only the ones that work**. The Live monitor shows "N created by DMA, M need GenAI" with **Download the M for GenAI**: a zip with only those, each with its reason |
| 7 | **Run details in My preferences** | Account → My preferences → Live monitor | "Run details" can be shown or hidden per user (shown by default) |

**Copy project, what is copied:** connections, schema list and, if ticked, the settings (decisions, run defaults, notifications, access roles). **Not copied:** snapshot, runs, column renames, DB link mappings, code packages (they belong to the old schema). A target schema set by hand in Settings is cleared, so the copy never loads into the same PostgreSQL schema.

**Runs started before batch 14** show "not recorded" for their decisions and versions in Run details; everything else works.

### CPU and RAM guard, the limits

- Busy = CPU at 95 % or more in two measurements in a row (every 5 seconds), or available memory under 1 GB (or 5 % of the RAM, if more).
- After 10 minutes of waiting the next step starts anyway (one at a time), so a run never hangs.
- Auto-tune keeps its own CPU limit (85 %) for the data load, as before.
- Optional, in the worker's environment only if you want other limits: `DMA_GUARD_CPU_MAX`, `DMA_GUARD_MIN_FREE_MB`, `DMA_GUARD_MAX_WAIT_SECONDS`, `DMA_GUARD_SAMPLE_SECONDS`.

### Global temporary tables, the two ways

PostgreSQL has no global temporary tables. DMA chooses by itself:

| | With the **pgtt** extension (recommended) | Without pgtt |
|---|---|---|
| What is created | Real global temporary tables (kept by pgtt in schema `pgtt_schema`) | A template of each table in schema `<target>_gtt` and the helper `<target>_gtt.dma_gtt_use('table')` |
| Each session sees only its own rows | Yes | Yes |
| Application code | **No change** | Calls `SELECT <target>_gtt.dma_gtt_use('tmp_calc');` once per session before using the table. The GenAI conversion instructions already say so |
| Live monitor says | "Global temporary tables: N ready with the pgtt extension…" | "Global temporary tables: N ready as templates in schema …" |

**DBA steps for pgtt** (once per PostgreSQL server / database; DMA cannot do them itself):

1. Install the pgtt package for your PostgreSQL version from the PGDG repository (on RHEL its name looks like `pgtt_16`; the DBA checks with `dnf search pgtt`). **The PostgreSQL server must run the same minor version the package was built for**: after installing, restart PostgreSQL in a maintenance window.
2. In the target database: `CREATE EXTENSION pgtt;`
3. Let normal users load it: copy the library into the plugins folder: `mkdir -p $(pg_config --pkglibdir)/plugins && cp $(pg_config --pkglibdir)/pgtt.so $(pg_config --pkglibdir)/plugins/`
4. `GRANT USAGE, CREATE ON SCHEMA pgtt_schema TO <DMA user>;` and `GRANT USAGE ON SCHEMA pgtt_schema TO <application roles>;`
5. For the application's sessions: `ALTER DATABASE <db> SET session_preload_libraries = '$libdir/plugins/pgtt';` and add `pgtt_schema` to the application's `search_path` (e.g. `ALTER ROLE <app user> SET search_path = <schema>, pgtt_schema, public;`). New sessions only.

Without these steps everything still works with the templates. If pgtt is installed later, the next run creates the real ones (the templates stay; you can drop schema `<target>_gtt` once the code no longer calls `dma_gtt_use`). To force templates even with pgtt: `DMA_GTT_PGTT=off` in the worker's environment.

**If a key or index of a global temporary table cannot be created**, the Live monitor says which one; the table itself is still created.

### Code objects by DMA, how it decides

| Result | Meaning | What happens |
|---|---|---|
| Ready: same result as Oracle | a view / materialized view returns the same number of rows as in Oracle | created |
| Ready: created, not compared | a function, procedure or trigger PostgreSQL accepts and with no Oracle code left in it (calling it could change data, so it cannot be compared) | created; **test it in the application** |
| Needs a table / a DB link | it reads a table not migrated yet, or a DB link not created yet | not created; the next check or run creates it once the table / link exists |
| Needs GenAI | PostgreSQL refused it, or ora2pg left Oracle code in it (CONNECT BY, BULK COLLECT, compound trigger…), or it uses an object that needs GenAI, or a remote synonym | in the GenAI zip, with the reason |
| Already in PostgreSQL | created earlier (a GenAI package, by hand) | **kept, never replaced** |

- **Dependencies:** whatever uses an object that needs GenAI goes to GenAI with it; a package goes as a whole when one of its routines needs GenAI.
- **Fixed by DMA itself:** reserved-word columns ora2pg writes in upper case (`"OFFSET"`) while your tables have them in lower case; `table@LINK` → the DB link's schema; `INSTEAD OF` triggers without `FOR EACH ROW`.
- **Search path:** every function and procedure DMA creates gets `search_path = <target schema>, public` (ora2pg's code names tables without schema; this is how Oracle behaves, and the safe setting for `SECURITY DEFINER` routines).
- **Order in a run:** the GenAI package (if chosen) and the DB links first, then DMA's check: the package's objects are kept, and views on a DB link can be created.
- The GenAI zip's `DMA_CHECK.md` lists what DMA already created (the GenAI team does not convert those). A converted package uploaded later replaces DMA's version of the same object.
- A failure of this step never fails the run: the data is loaded; the Live monitor says what happened and you can check again on Code objects.

### Simpler screens (one-click goal)

- **Migrate:** "Start migration" starts at once. The question "Are your GenAI-converted code objects ready?" appears only when a converted package was uploaded (then there is a real choice). The tick boxes "Create the saved DB links" (batch 11) and "DMA converts the code objects it can" are gone from the dialog: both happen in every run. An admin can switch them off in **Settings → Run defaults**.
- **Code objects page:** one card, "Code objects in PostgreSQL": one line of counts (from Oracle), one line of results ("N in PostgreSQL · M need GenAI"), and only the actions a person may need: **Download the M for GenAI** and **Upload converted zip**. The object list, "Check again now" and "Export ALL code objects for GenAI instead" are folded under **Details**. The old three GenAI step cards are gone (the zip carries CONVERSION_GUIDE.md). Converted packages are folded; **DB links** appear only when the schema has some, and open by themselves only when a link still needs something.
- The menu and the step bar say "Code objects" (no longer "Code objects (GenAI)").
- **Guide → Errors explained:** each card shows the code and how serious it is on one line, the title on its own line (it was squeezed into a narrow column).

## Files

| | Files |
|---|---|
| `ora2pgservice/` new | `services/resourceGuard.js`, `services/runCompare.js`, `services/codeAuto.js` |
| `ora2pgservice/` changed | `services/migrate.js`, `services/sqlRunner.js`, `services/analysis.js`, `services/code.js`, `services/preferences.js`, `services/settings.js`, `controllers/projectController.js`, `controllers/runController.js`, `controllers/codeController.js`, `routes/projectRoutes.js` |
| `ora2pgservice/` tests | new `tests/unit/batch14.test.js`, `tests/unit/codeAuto.test.js`, `tests/e2e/batch14.e2e.test.js`, `tests/e2e/codeAuto.e2e.test.js` |
| `ora2pgui/` new | `src/components/RunDetails.tsx`, `src/components/CodeCheck.tsx`, `src/pages/RunComparePage.tsx` |
| `ora2pgui/` changed | `src/App.tsx`, `src/prefs.ts`, `src/components/PreferencesDialog.tsx`, `src/pages/ProjectsPage.tsx`, `src/pages/RunsPage.tsx`, `src/pages/RunPage.tsx`, `src/pages/MigratePage.tsx`, `src/pages/CodePage.tsx`, `src/pages/SettingsPage.tsx`, `src/pages/GuidePage.tsx`, `src/components/ProjectLayout.tsx` |
| `ora2pgui/` tests | new `tests/unit/batch14.test.tsx`, `tests/unit/codeCheck.test.tsx`, `tests/e2e/batch14.spec.ts`; changed `tests/e2e/dblinks.spec.ts` (the DB links choice moved to Settings), `tests/e2e/flow.spec.ts` (one-click start), `tests/e2e/pages.spec.ts` (page title) |

## Deploy

1. Before copying: keep a copy of your current `ora2pgservice` and `ora2pgui` folders (way back in two minutes).
2. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
3. In `ora2pgservice`, run `npm test`. It should end with **Tests: 172 passed**.
4. In `ora2pgui`, run `npm test` (should end with **65 passed**), then `npm run build`, then copy `index.html` and the build to nginx as usual.
5. On RHEL, **when no migration runs**:
   ```bash
   pm2 restart ora2pg-service-prod
   ```
   ```bash
   pm2 restart ora2pg-worker-prod
   ```
6. Press Ctrl+F5 in the browser.

## Test on RHEL

- [ ] **Copy project:** All projects → copy icon on E780 → pick another schema → Copy project. The copy opens at Schema & snapshot; **Take snapshot** works (same connections). Settings show the same run defaults, target schema empty.
- [ ] **Run details:** open any new run → Run details: options, decisions, versions, time per phase.
- [ ] **Compare runs:** Live monitor list → tick two runs → Compare the 2 runs: differences marked.
- [ ] **Guard:** nothing to do on a healthy server; the run page shows no notice. (Optional: on a test server, start the worker with `DMA_GUARD_MIN_FREE_MB=999999` for one run: the yellow notice appears, and after 10 minutes the run continues on its own; remove the setting afterwards.)
- [ ] **One click:** on Migrate, select tables and press **Start migration**: it starts at once (no dialog) when no converted package was uploaded.
- [ ] **Code objects by DMA:** migrate a few tables (nothing to tick). The Live monitor shows "Code objects converted by DMA: N created, M need GenAI". In SQL Workbench (PostgreSQL) the created views return rows. **Code objects** shows "N in PostgreSQL · M need GenAI"; **Details** lists every object with its reason; **Download the M for GenAI** gives a zip with only those and `DMA_CHECK.md`.
- [ ] **Code objects, nothing replaced:** Details → "Check again now": what DMA created shows "Already in PostgreSQL (kept)".
- [ ] **My preferences:** switch "Run details" off and on: the section disappears and comes back.
- [ ] **Global temporary tables** (if the schema has any): the Live monitor says "Global temporary tables: N ready …". In SQL Workbench (PostgreSQL): without pgtt `SELECT * FROM <target>_gtt.<table>;` (empty template); with pgtt `SELECT * FROM pgtt_schema.pg_global_temp_tables;`.

## Tested on the Mac (real databases)

Test data (`dev-tools/testdb/08_batch14.sql` and TMP_CALC): a global temporary table that keeps its rows until the session ends (primary key, default) and one that deletes them at commit.

| Proof | Result |
|---|---|
| Copy project | Copy for ACMM_REMOTE created; its own snapshot taken through the copied connections; settings copied, hand-set target schema cleared; wrong name / unknown schema / existing name refused |
| Run details / compare | Two runs with a different "tries per table" and "keep microseconds": both marked as differences; a table only in the second run shown as such |
| Guard | Worker told memory was short for the first 15 s: "Server memory is short… no new work" at 12:12:40, "back to normal" at 12:12:55, the first table started only then; run COMPLETED, "waited 2 times, 15 s" |
| GTT with pgtt | Both tables in pgtt_schema, primary key on the definition; two real sessions: each sees only its own rows, the same key allowed in both, rows deleted at commit for TMP_CALC, kept for the other |
| Code objects (19 in the test schema) | In a migration with the tick box: 7 created by DMA (2 views and a materialized view with the same row count as Oracle, 2 functions, a procedure, 2 triggers, one of them fixed by DMA), 2 waiting for the DB link, 9 to GenAI (CONNECT BY, BULK COLLECT, compound trigger, a remote synonym, a whole package, a view on another one). Nothing changed by the check itself; nothing replaced on a second check; the trigger DMA created works through the view |
| GTT without pgtt | Templates in e2e_b14_gtt and dma_gtt_use(): same session results as with pgtt; the template itself stays empty |

Tests on the final code:
- API unit **172** passed.
- API e2e full suite **95** passed, 0 failed (4 skipped: 3 need test setups not used here; the CPU/RAM guard test runs only with its special worker setting and passed when run that way). Includes batch 14's 11 tests, the 14 code-object tests (a real migration that created 7 code objects by itself), and all migration, object table and DB link (postgres_fdw and oracle_fdw) tests.
- UI Vitest **65** passed.
- UI Playwright **36** passed (1 skipped: "delete a package" needs an uploaded package). Includes a one-click migration from the screens: started at once, loaded, verified, code objects created.

