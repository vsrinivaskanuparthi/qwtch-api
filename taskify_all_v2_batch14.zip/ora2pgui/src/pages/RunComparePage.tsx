import { Alert, Button, LinearProgress } from '@mui/material';
import CompareArrowsRoundedIcon from '@mui/icons-material/CompareArrowsRounded';
import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { PageHeader, SectionCard } from '../components/ui';
import { RunDetailsData, RunDetailsView } from '../components/RunDetails';

/** Compare runs (DMA-077): two runs of the project side by side, differences marked. */
export default function RunComparePage() {
  const { name } = useProject();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const a = params.get('a') || '';
  const b = params.get('b') || '';
  const [data, setData] = useState<RunDetailsData | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    setData(null);
    setError(null);
    api<RunDetailsData>(`${projectPath(name)}/runs/compare?a=${encodeURIComponent(a)}&b=${encodeURIComponent(b)}`).then(setData).catch((e) => setError(e.message));
  }, [name, a, b]);
  return (
    <>
      <PageHeader overline="Step 7" title="Compare runs" icon={<CompareArrowsRoundedIcon />}
        subtitle="What each run used and loaded, side by side: tables, options, decisions, versions and time per phase."
        actions={<Button variant="outlined" onClick={() => navigate('..', { relative: 'path' })}>All runs</Button>} />
      <SectionCard>
        {error && <Alert severity="error">{error}</Alert>}
        {!data && !error && <LinearProgress />}
        {data && <RunDetailsView data={data} />}
      </SectionCard>
    </>
  );
}
