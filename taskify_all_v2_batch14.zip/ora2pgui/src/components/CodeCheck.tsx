import { Alert, Box, Button, CircularProgress, Collapse, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Stack, Typography } from '@mui/material';
import FactCheckRoundedIcon from '@mui/icons-material/FactCheckRounded';
import BuildCircleRoundedIcon from '@mui/icons-material/BuildCircleRounded';
import CloudDownloadRoundedIcon from '@mui/icons-material/CloudDownloadRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import { ReactNode, useState } from 'react';
import { api, apiUrl, projectPath } from '../api';
import DataTable from './DataTable';
import { SectionCard, Tag } from './ui';
import { fmtDate } from '../format';
import { brand } from '../theme';

/**
 * Code objects status (DMA-086): what DMA converted itself (during the migration, or a check from
 * here) and what needs GenAI. One short line and the two actions a person may need; the object list,
 * "Check again" and the full export are folded under Details.
 */
export type CheckObject = { key: string; kind: string; name: string; status: string; label: string; reason: string; fixes?: string[]; dependsOn?: string | null };
export type CheckResult = { id: string; schema: string; target: string; createdAt: string; summary: Record<string, number>; objects: CheckObject[]; applied?: { at: string; created: number; failed: { name: string; error: string }[] } };
export type CheckJob = { id: string; status: string; step?: string | null; error?: string } | null;

const COLOR: Record<string, string> = {
  ready: '#067647', ready_unproven: '#175CD3', created: '#067647', exists: '#475467',
  needs_table: '#B54708', needs_link: '#B54708', genai: '#B42318', create_failed: '#B42318',
};
const READY = ['ready', 'ready_unproven'];

type Props = {
  projectName: string; check: CheckResult | null; job: CheckJob; onChanged: () => void; canRun: boolean;
  /** Oracle's object counts, one line. */ countsLine?: string;
  /** e.g. the "Upload converted zip" button, next to "Download for GenAI". */ actions?: ReactNode;
  /** e.g. upload / apply messages. */ children?: ReactNode;
  /** e.g. "Export all code objects for GenAI", inside Details. */ detailsExtra?: ReactNode;
};

export default function CodeCheck({ projectName, check, job, onChanged, canRun, countsLine, actions, children, detailsExtra }: Props) {
  const [error, setError] = useState<string | null>(null);
  const [confirm, setConfirm] = useState(false);
  const [applying, setApplying] = useState(false);
  const [details, setDetails] = useState(false);
  const running = job?.status === 'RUNNING';
  const n = (s: string[]) => (check ? check.objects.filter((o) => s.includes(o.status)).length : 0);
  const ready = n(READY);
  const genai = n(['genai']);
  const done = n(['created', 'exists']);
  const waiting = n(['needs_table', 'needs_link']);

  const start = async () => {
    setError(null);
    try { await api(`${projectPath(projectName)}/code/check`, { body: {} }); onChanged(); } catch (e: any) { setError(e.message); }
  };
  const apply = async () => {
    setApplying(true);
    setError(null);
    try {
      await api(`${projectPath(projectName)}/code/check/${check!.id}/apply`, { body: {} });
      setConfirm(false);
      onChanged();
    } catch (e: any) {
      setConfirm(false);
      setError(e.message);
    } finally { setApplying(false); }
  };

  return (
    <SectionCard title={<Stack direction="row" spacing={1.25} alignItems="center"><BuildCircleRoundedIcon sx={{ color: brand.blue }} /><span>Code objects in PostgreSQL</span></Stack>}
      subtitle={countsLine}>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {running && <Alert severity="info" icon={<CircularProgress size={18} />} sx={{ mb: 2 }}>{job?.step || 'Checking…'}</Alert>}
      {job?.status === 'FAILED' && <Alert severity="error" sx={{ mb: 2 }}>The check failed: {job.error}</Alert>}

      <Stack spacing={2}>
        {!check ? (
          <Typography variant="body2" data-testid="check-summary">
            DMA converts the code objects itself after the data of each migration (ora2pg, tested in PostgreSQL first). <b>Nothing to do here before your first migration.</b> Only the objects DMA cannot convert go to GenAI; this page will list them.
          </Typography>
        ) : (
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap alignItems="center" data-testid="check-summary">
            {done > 0 && <Tag color={COLOR.created} label={`${done} in PostgreSQL`} />}
            {ready > 0 && <Tag color={COLOR.ready_unproven} label={`${ready} ready to create`} />}
            {waiting > 0 && <Tag color={COLOR.needs_table} label={`${waiting} waiting for a table or DB link`} />}
            {genai > 0 ? <Tag color={COLOR.genai} label={`${genai} need GenAI`} /> : <Tag color={COLOR.created} label="nothing for GenAI" />}
            <Typography variant="caption" color="text.secondary">checked {fmtDate(check.createdAt)}</Typography>
          </Stack>
        )}

        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} flexWrap="wrap" useFlexGap>
          {genai > 0 && (
            <Button variant="contained" startIcon={<CloudDownloadRoundedIcon />} component="a" href={apiUrl(`${projectPath(projectName)}/code/check/${check!.id}/genai.zip`)}>
              Download the {genai} for GenAI
            </Button>
          )}
          {ready > 0 && (
            <Button variant="contained" color="success" startIcon={<BuildCircleRoundedIcon />} disabled={running} onClick={() => setConfirm(true)}>
              Create the {ready} ready object{ready === 1 ? '' : 's'}
            </Button>
          )}
          {actions}
        </Stack>
        {children}

        <Box>
          <Button size="small" onClick={() => setDetails((d) => !d)} endIcon={<ExpandMoreRoundedIcon sx={{ transform: details ? 'rotate(180deg)' : 'none', transition: 'transform .2s' }} />} aria-expanded={details}>
            Details
          </Button>
          <Collapse in={details} unmountOnExit>
            <Stack spacing={2} sx={{ mt: 1.5 }}>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} alignItems={{ sm: 'center' }} flexWrap="wrap" useFlexGap>
                <Button variant="outlined" startIcon={running ? <CircularProgress size={16} /> : <FactCheckRoundedIcon />} disabled={running || !canRun} onClick={start}>
                  {running ? 'Checking…' : check ? 'Check again now' : 'Check now'}
                </Button>
                {detailsExtra}
                <Typography variant="caption" color="text.secondary" sx={{ flex: 1, minWidth: 220 }}>
                  A check changes nothing: every object is tried in a transaction that is undone. Views are compared with Oracle; objects already in PostgreSQL are kept, never replaced.
                </Typography>
              </Stack>
              {check && (
                <DataTable dense rows={check.objects} rowKey={(o) => o.key} pageSize={10} searchKeys={['name', 'kind', 'reason']}
                  initialSort={{ key: 'status', dir: 'asc' }}
                  columns={[
                    { key: 'name', label: 'Object', render: (o) => (
                      <Box>
                        <Typography className="mono" fontSize={13} sx={{ whiteSpace: 'nowrap' }}>{o.name}</Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>{o.kind}</Typography>
                      </Box>
                    ) },
                    { key: 'status', label: 'Result', sortValue: (o) => ['genai', 'create_failed', 'needs_table', 'needs_link', 'ready_unproven', 'ready', 'created', 'exists'].indexOf(o.status), render: (o) => <Tag color={COLOR[o.status] || brand.blue} label={o.label} /> },
                    { key: 'reason', label: 'Why', render: (o) => (
                      <Box sx={{ minWidth: 260 }}>
                        <Typography variant="body2">{o.reason}</Typography>
                        {!!o.fixes?.length && <Typography variant="caption" color="text.secondary">Fixed by DMA: {o.fixes.join(', ')}</Typography>}
                      </Box>
                    ) },
                  ]} />
              )}
            </Stack>
          </Collapse>
        </Box>
      </Stack>

      <Dialog open={confirm} onClose={() => setConfirm(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>Create {ready} objects in {check?.target}?</DialogTitle>
        <DialogContent>
          <DialogContentText component="div">
            DMA creates the objects it converted itself, each one on its own, in the order of their dependencies. Objects already in PostgreSQL are kept, never replaced. A converted GenAI package uploaded later replaces DMA's version of the same object.
            {n(['ready_unproven']) > 0 && <Box sx={{ mt: 1.5 }}><b>{n(['ready_unproven'])}</b> of them (functions, procedures, triggers) could not be compared with Oracle: test them in the application.</Box>}
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setConfirm(false)}>Cancel</Button>
          <Button variant="contained" color="success" onClick={apply} disabled={applying}>{applying ? 'Creating…' : `Create ${ready} objects`}</Button>
        </DialogActions>
      </Dialog>
    </SectionCard>
  );
}
