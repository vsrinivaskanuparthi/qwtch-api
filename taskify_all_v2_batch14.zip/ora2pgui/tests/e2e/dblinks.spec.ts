import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// DMA-079: DB links created on their own, without a converted GenAI package. Against the real API.
// Project E2E_TEST has DB link ACMM_LINK saved as oracle_fdw, and its PostgreSQL has no oracle_fdw:
// so "Create now" really runs and fails in plain words, without changing anything.

test('Code objects: "Create now" runs without a package and explains a failure in plain words', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/code`);
  test.skip((await page.getByText('No DB links in this schema').count()) > 0, 'no DB link in this schema');
  test.skip((await page.getByRole('heading', { name: 'DB links' }).count()) === 0, 'no DB link in this schema');
  const createNow = page.getByRole('button', { name: /^(Create now|Create again)$/ }).first();
  if ((await createNow.count()) === 0) await page.getByRole('heading', { name: 'DB links' }).click(); // folded when nothing needs work
  test.skip((await createNow.count()) === 0, 'no DB link mapped in this project');
  await expect(page.getByRole('button', { name: /Save and create (the link|all \d+ links) now/ })).toBeEnabled();
  await expect(page.getByText(/No converted package needed/)).toBeVisible();
  await createNow.click();
  await expect(page.getByRole('alert').filter({ hasText: /extension is not installed|Created:|Updated:|Wrong user|cannot reach/ }).first()).toBeVisible({ timeout: 60000 });
  await pageIsFine(page);
  expect(errors).toEqual([]);
});

test('Settings: "create the saved DB links" happens in every run, an admin can switch it off', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/settings`);
  await page.getByRole('tab', { name: /Run defaults/ }).click();
  await expect(page.getByRole('checkbox', { name: /After the data, create the saved DB links/ })).toBeChecked();
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
