import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// The main user path for one small table: Migrate → Live monitor → Validation.
test('migrate one table from the screens and see it verified', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/migrate`);
  await page.getByPlaceholder('Search').fill('PLANT');
  await page.getByRole('checkbox', { name: 'Select PLANT', exact: true }).check();
  await page.getByRole('button', { name: /^Start migration \(1\)$/ }).click();
  // One click: the run starts at once; the question about a converted package only comes when one was uploaded.
  const confirm = page.getByRole('button', { name: /^Start migration \(1 table\)$/ });
  if (await confirm.isVisible({ timeout: 3000 }).catch(() => false)) await confirm.click();

  await expect(page).toHaveURL(/\/runs\/\d{8}-\d{6}$/);
  await expect(page.getByText(/^Completed$/).first()).toBeVisible({ timeout: 4 * 60 * 1000 });
  await expect(page.locator('tbody').getByText('PLANT')).toBeVisible();

  await page.goto(`${P}/validation`);
  await page.getByPlaceholder('Search').first().fill('plant'); // the list may have more than one page
  const row = page.locator('tbody tr', { hasText: /^plant/ }).first();
  await expect(row).toContainText('verified at load');
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
