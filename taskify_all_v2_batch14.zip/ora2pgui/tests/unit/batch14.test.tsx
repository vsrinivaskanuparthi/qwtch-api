import { fireEvent, render, screen, within } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { beforeEach, describe, expect, test, vi } from 'vitest';
import { RunDetailsView, type RunDetailsData } from '../../src/components/RunDetails';
import { CopyProjectDialog } from '../../src/pages/ProjectsPage';

// Batch 14 screens: Run details / Compare runs (DMA-077) and Copy project (DMA-057).
const server = vi.hoisted(() => ({ calls: [] as { path: string; init: any }[], answer: null as any }));
vi.mock('../../src/api', async (orig) => {
  const real = await orig<typeof import('../../src/api')>();
  return {
    ...real,
    api: vi.fn(async (path: string, init: any = {}) => {
      server.calls.push({ path, init });
      if (server.answer instanceof Error) throw server.answer;
      return server.answer;
    }),
  };
});
beforeEach(() => { server.calls = []; server.answer = null; });

const two: RunDetailsData = {
  runs: [{ runId: '20261127-100000', status: 'COMPLETED', schema: 'APP', startedAt: '2026-11-27T10:00:00Z' }, { runId: '20261127-110000', status: 'COMPLETED_WITH_ERRORS', schema: 'APP', startedAt: '2026-11-27T11:00:00Z' }],
  sections: [
    { title: 'Run', rows: [{ key: 'status', label: 'Status', values: ['COMPLETED', 'COMPLETED_WITH_ERRORS'], diff: true }, { key: 'startedAt', label: 'Started', values: ['2026-11-27T10:00:00Z', '2026-11-27T11:00:00Z'], diff: false }] },
    { title: 'Run options', rows: [{ key: 'opt.parallelTables', label: 'Tables at a time', values: ['4', '8'], diff: true }, { key: 'opt.loadMode', label: 'Load mode', values: ['direct', 'direct'], diff: false }] },
  ],
  tables: [
    { name: 'ORDERS', values: [{ status: 'done', rows: 1000, seconds: 65, attempts: 1 }, { status: 'done', rows: 1000, seconds: 40, attempts: 1 }], diff: false },
    { name: 'ITEMS', values: [null, { status: 'failed', rows: 0, seconds: 3, attempts: 3 }], diff: true },
  ],
};

describe('DMA-077 Run details and Compare runs', () => {
  test('two runs: the number of differences, only the differing lines first, a column per run', () => {
    render(<RunDetailsView data={two} />);
    expect(screen.getByTestId('compare-diff-count')).toHaveTextContent('3 differences');
    expect(screen.getByTestId('detail-opt.parallelTables')).toHaveTextContent(/Tables at a time\s*4\s*8/);
    expect(screen.queryByTestId('detail-opt.loadMode')).not.toBeInTheDocument();
    expect(within(screen.getByTestId('table-ITEMS')).getByText('not in this run')).toBeInTheDocument();
    expect(screen.queryByTestId('table-ORDERS')).not.toBeInTheDocument();
    expect(screen.getAllByText('20261127-110000').length).toBeGreaterThan(0);
  });

  test('"Show only differences" off: every line, with the equal ones too', () => {
    render(<RunDetailsView data={two} />);
    fireEvent.click(screen.getByLabelText('Show only differences'));
    expect(screen.getByTestId('detail-opt.loadMode')).toHaveTextContent(/Load mode\s*direct\s*direct/);
    expect(within(screen.getByTestId('table-ORDERS')).getByText(/1,000 rows · 1 min 5 s/)).toBeInTheDocument();
  });

  test('one run: just its values, no difference marks', () => {
    const one: RunDetailsData = { runs: [two.runs[0]], sections: two.sections.map((s) => ({ ...s, rows: s.rows.map((r) => ({ ...r, values: [r.values[0]], diff: false })) })), tables: [] };
    render(<RunDetailsView data={one} />);
    expect(screen.queryByTestId('compare-diff-count')).not.toBeInTheDocument();
    expect(screen.getByTestId('detail-opt.loadMode')).toHaveTextContent('direct');
    expect(screen.getByTestId('detail-opt.parallelTables')).toHaveTextContent('4');
  });
});

describe('DMA-057 Copy project', () => {
  const project: any = { projectName: 'SALES', appName: 'Sales', appCode: 'SAL', selectedSchema: 'SALES_APP', schemas: ['SALES_APP', 'SALES_HIST', 'SALES_REF'], oracle: {}, postgres: {}, migrationStatus: 'READY', createdAt: '', lastMigrationDate: null, currentMigrationId: null };
  const renderDialog = () => render(
    <MemoryRouter initialEntries={['/projects']}>
      <Routes>
        <Route path="/projects" element={<CopyProjectDialog p={project} open onClose={() => {}} />} />
        <Route path="/projects/:name/schema" element={<div>schema page of the copy</div>} />
      </Routes>
    </MemoryRouter>,
  );

  test('suggests another schema and a name, then copies with the settings and opens the copy', async () => {
    server.answer = { project: { ...project, projectName: 'SALES_SALES_HIST' }, message: 'ok' };
    renderDialog();
    expect(screen.getByRole('combobox', { name: /Oracle schema/ })).toHaveTextContent('SALES_HIST');
    expect(screen.getByLabelText('New project name')).toHaveValue('SALES_SALES_HIST');
    fireEvent.click(screen.getByRole('button', { name: 'Copy project' }));
    expect(await screen.findByText('schema page of the copy')).toBeInTheDocument();
    expect(server.calls[0]).toEqual({ path: '/projects/SALES/copy', init: { body: { newName: 'SALES_SALES_HIST', schema: 'SALES_HIST', copySettings: true } } });
  });

  test('settings can be left out; a refusal from the server is shown and nothing changes page', async () => {
    server.answer = new Error('Project SALES_SALES_HIST already exists.');
    renderDialog();
    fireEvent.click(screen.getByLabelText(/Copy the settings too/));
    fireEvent.click(screen.getByRole('button', { name: 'Copy project' }));
    expect(await screen.findByText('Project SALES_SALES_HIST already exists.')).toBeInTheDocument();
    expect(server.calls[0].init.body.copySettings).toBe(false);
    expect(screen.queryByText('schema page of the copy')).not.toBeInTheDocument();
  });

  test('an invalid name disables the button', () => {
    renderDialog();
    fireEvent.change(screen.getByLabelText('New project name'), { target: { value: 'has space' } });
    expect(screen.getByRole('button', { name: 'Copy project' })).toBeDisabled();
  });
});
