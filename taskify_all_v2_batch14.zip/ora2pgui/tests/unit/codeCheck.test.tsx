import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { beforeEach, describe, expect, test, vi } from 'vitest';
import CodeCheck, { type CheckResult } from '../../src/components/CodeCheck';

// DMA-086 "Convert with DMA first" on the Code objects page. The API is replaced.
const server = vi.hoisted(() => ({ calls: [] as { path: string; init: any }[], answer: {} as any }));
vi.mock('../../src/api', async (orig) => {
  const real = await orig<typeof import('../../src/api')>();
  return {
    ...real,
    api: vi.fn(async (path: string, init: any = {}) => {
      server.calls.push({ path, init });
      if (server.answer instanceof Error) throw server.answer;
      return server.answer;
    }),
  };
});
beforeEach(() => { server.calls = []; server.answer = {}; });

const o = (name: string, kind: string, status: string, label: string, reason: string, extra = {}) => ({ key: name, name, kind, status, label, reason, ...extra });
const check: CheckResult = {
  id: '20261127-154718', schema: 'APP', target: 'app', createdAt: '2026-11-27T15:47:18Z',
  summary: { total: 5, ready: 1, ready_unproven: 1, genai: 2, needs_table: 1 },
  objects: [
    o('station_v', 'view', 'ready', 'Ready: same result as Oracle', 'Same number of rows as in Oracle (3,000)'),
    o('trg_station_v_io', 'trigger', 'ready_unproven', 'Ready: created, not compared with Oracle', 'Created; behaviour not compared', { fixes: ['INSTEAD OF trigger: FOR EACH ROW'] }),
    o('pkg.plan_tree', 'package routine', 'genai', 'Needs GenAI', 'ora2pg left Oracle code in it: CONNECT BY / PRIOR'),
    o('third_mv2', 'materialized view', 'genai', 'Needs GenAI', 'Uses third_mv, which needs GenAI: they go together', { dependsOn: 'third_mv' }),
    o('v_order_status', 'view', 'needs_table', 'Needs a table that is not migrated yet', 'Table orders_big is not migrated yet'),
  ],
};

describe('Code objects status card', () => {
  test('before the first migration: nothing to do, said plainly; no actions for GenAI', () => {
    render(<CodeCheck projectName="P1" check={null} job={null} onChanged={() => {}} canRun />);
    expect(screen.getByTestId('check-summary')).toHaveTextContent('Nothing to do here before your first migration');
    expect(screen.queryByRole('link', { name: /for GenAI/ })).not.toBeInTheDocument();
  });

  test('one line of counts and the actions a person may need, with their numbers', () => {
    render(<CodeCheck projectName="P1" check={check} job={null} onChanged={() => {}} canRun actions={<button type="button">Upload converted zip</button>} />);
    const sum = screen.getByTestId('check-summary');
    expect(sum).toHaveTextContent('2 ready to create');
    expect(sum).toHaveTextContent('1 waiting for a table or DB link');
    expect(sum).toHaveTextContent('2 need GenAI');
    expect(screen.getByRole('link', { name: /Download the 2 for GenAI/ })).toHaveAttribute('href', expect.stringMatching(/\/projects\/P1\/code\/check\/20261127-154718\/genai\.zip$/));
    expect(screen.getByRole('button', { name: 'Create the 2 ready objects' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Upload converted zip' })).toBeInTheDocument();
  });

  test('the object list and "Check again now" are folded under Details', () => {
    render(<CodeCheck projectName="P1" check={check} job={null} onChanged={() => {}} canRun />);
    expect(screen.queryByText('Uses third_mv, which needs GenAI: they go together')).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Details' }));
    expect(screen.getByText('Uses third_mv, which needs GenAI: they go together')).toBeInTheDocument();
    expect(screen.getByText('Fixed by DMA: INSTEAD OF trigger: FOR EACH ROW')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Check again now' })).toBeEnabled();
  });

  test('"Create" asks first, says what is kept and what is not compared, then calls the server', async () => {
    const onChanged = vi.fn();
    render(<CodeCheck projectName="P1" check={check} job={null} onChanged={onChanged} canRun />);
    fireEvent.click(screen.getByRole('button', { name: 'Create the 2 ready objects' }));
    const dialog = await screen.findByRole('dialog');
    expect(dialog).toHaveTextContent('Objects already in PostgreSQL are kept, never replaced');
    expect(dialog).toHaveTextContent('could not be compared with Oracle');
    fireEvent.click(within(dialog).getByRole('button', { name: 'Create 2 objects' }));
    await waitFor(() => expect(onChanged).toHaveBeenCalled());
    expect(server.calls[0].path).toBe('/projects/P1/code/check/20261127-154718/apply');
  });

  test('after a migration: everything in PostgreSQL, nothing for GenAI: no buttons to press', () => {
    const none = { ...check, objects: [o('x', 'view', 'created', 'Created by DMA', 'ok'), o('y', 'view', 'exists', 'Already in PostgreSQL (kept)', 'kept')] };
    render(<CodeCheck projectName="P1" check={none} job={null} onChanged={() => {}} canRun />);
    expect(screen.getByTestId('check-summary')).toHaveTextContent('2 in PostgreSQL');
    expect(screen.getByTestId('check-summary')).toHaveTextContent('nothing for GenAI');
    expect(screen.queryByRole('button', { name: /ready object/ })).not.toBeInTheDocument();
    expect(screen.queryByRole('link', { name: /for GenAI/ })).not.toBeInTheDocument();
  });

  test('while a check runs: its step is shown', () => {
    render(<CodeCheck projectName="P1" check={check} job={{ id: 'x', status: 'RUNNING', step: 'Comparing with Oracle: station_v (1 of 3)' }} onChanged={() => {}} canRun />);
    expect(screen.getByText('Comparing with Oracle: station_v (1 of 3)')).toBeInTheDocument();
  });

  test('a refused check is shown in plain words', async () => {
    server.answer = new Error('No tables in PostgreSQL schema app yet: migrate the tables first, then check the code objects.');
    render(<CodeCheck projectName="P1" check={null} job={null} onChanged={() => {}} canRun />);
    fireEvent.click(screen.getByRole('button', { name: 'Details' }));
    fireEvent.click(screen.getByRole('button', { name: 'Check now' }));
    expect(await screen.findByText(/migrate the tables first/)).toBeInTheDocument();
  });
});
